package de.gwvs.auswertungen.queries.service.impl;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import de.gwvs.auswertungen.commons.test.config.InfrastructureTestConfig;
import de.gwvs.auswertungen.queries.dao.BoundVariableDao;
import de.gwvs.auswertungen.queries.dao.QueryDao;
import de.gwvs.auswertungen.queries.dao.impl.BoundVariableDaoImpl;
import de.gwvs.auswertungen.queries.dao.impl.QueryDaoImpl;
import de.gwvs.auswertungen.queries.service.ParameterService;
import de.gwvs.auswertungen.queries.service.QueryService;

@Configuration
@Import( { InfrastructureTestConfig.class } )
public class ParameterServiceTestConfig {

	@Bean
	public ParameterService parameterService() {
		return new ParameterServiceImpl();
	}
	
	@Bean
	public QueryDao queryDao() {
		return new QueryDaoImpl();
	}
	
	@Bean
	public QueryService queryService() {
		return new QueryServiceImpl();
	}
	
	@Bean
	public BoundVariableDao boundVariableDao() {
		return new BoundVariableDaoImpl();
	}
}
