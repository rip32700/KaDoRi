/*
 * @(#)CommonsTestConfig.java	1.00 2013/01/25
 * 
 * @author Ronny Krammer
 * 
 * Copyright 2013 GWVS
 */
package de.gwvs.auswertungen.commons.test.config;

import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.jasypt.encryption.pbe.config.EnvironmentStringPBEConfig;
import org.jasypt.spring31.properties.EncryptablePropertyPlaceholderConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;

/**
 * Allgemeine {@link Configuration}
 * 
 * @author Ronny Krammer
 * @version 1.0
 * 
 */
@Configuration
public class CommonsTestConfig {

	/**
	 * Gibt eine {@link StandardPBEStringEncryptor} zur�ck
	 * 
	 * @return {@link StandardPBEStringEncryptor}
	 */
	@Bean
	public static EncryptablePropertyPlaceholderConfigurer propertyConfigurer() {
		EnvironmentStringPBEConfig pbeConfig = new EnvironmentStringPBEConfig();
		pbeConfig.setAlgorithm("PBEWithMD5AndDES");
		pbeConfig.setPassword("teamt0ss0tmeat");
		StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
		encryptor.setConfig(pbeConfig);
		EncryptablePropertyPlaceholderConfigurer placeholderConfigurer = new EncryptablePropertyPlaceholderConfigurer(encryptor);
		placeholderConfigurer.setLocation(new ClassPathResource("/test.properties"));
		return placeholderConfigurer;
	}
}
