package de.gwvs.auswertungen.queries.dao.impl;

import static org.junit.Assert.assertEquals;

import javax.inject.Inject;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import de.gwvs.auswertungen.queries.dao.BoundVariableDao;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = BoundVariableDaoTestConfig.class)
public class BoundVariableDaoTest {

	private final String variableName = "vertriebskz";
	
	@Inject
	private BoundVariableDao boundVariableDao;
	
	@Before
	public void setUp() {
	}
	
	@Test
	public void testGetBezeichnungByName() {
		assertEquals("VertriebsKZ", boundVariableDao.getBezeichnungByName(variableName));
	}
	
	@Test
	public void testGetTypeByName() {
		assertEquals("Werteliste", boundVariableDao.getTypeByName(variableName));
	}
}
