package de.gwvs.auswertungen.queries.dao.impl;

import static org.junit.Assert.assertNotNull;

import javax.inject.Inject;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import de.gwvs.auswertungen.queries.dao.QueryDao;
import de.gwvs.auswertungen.queries.domain.Query;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = QueryDaoTestConfig.class)
public class QueryDaoTest {

	private final String username = "prieger";
	private final Long queryId = 2L;
	
	@Inject
	private QueryDao queryDao;
	
	@Before
	public void setUp() {
	}
	
	@Test
	public void testFindQueryById() {
		assertNotNull(queryDao.findQueryById(queryId));
	}
	
	@Test
	public void testFindAllQueries() {
		assertNotNull(queryDao.findAllQueries());
	}
	
	@Test
	public void testFindAllFavs() {
		assertNotNull(queryDao.findAllFavoriteQueries(username));
	}
	
	@Test
	public void testFindFavIds() {
		assertNotNull(queryDao.findAllFavIds(username));
	}
	
	@Test
	public void testQueryExecution() {
		Query query = queryDao.findQueryById(queryId);
		assertNotNull(queryDao.executeQuery(query.getSql()));
	}
	
}
