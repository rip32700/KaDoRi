/*
 * @(#)InfrastructureTestConfig.java	1.00 2013/01/25
 * 
 * @author Ronny Krammer
 * 
 * Copyright 2013 GWVS
 */
package de.gwvs.auswertungen.commons.test.config;

import java.sql.SQLException;
//import java.util.UUID;

import javax.sql.DataSource;

import oracle.ucp.jdbc.PoolDataSource;
//import oracle.ucp.jdbc.PoolDataSourceFactory;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

//import de.gwvs.auswertungen.queries.dao.impl.QueryDaoImpl;
//import de.gwvs.auswertungen.queries.service.QueryService;
//import de.gwvs.auswertungen.queries.service.impl.QueryServiceImpl;

/**
 * {@link Configuration} f�r die Tests mit Datenbankunterst�tzung
 * 
 * @author Ronny Krammer
 * @version 1.0
 * 
 */
@Configuration
@EnableTransactionManagement
@Import({ CommonsTestConfig.class })
public class InfrastructureTestConfig {

	/**
	 * Passwort
	 */
	@Value("${database.password}")
	private String pd = "";

	/**
	 * Datenbank URL
	 */
	@Value("${database.datasource}")
	private String url = "";

	/**
	 * Username
	 */
	@Value("${database.username}")
	private String userName = "";

	/**
	 * Erzeugt die {@link PoolDataSource}
	 * 
	 * @return {@link DataSource}
	 * @throws SQLException SQLException
	 */
	@Bean
	public DataSource dataSource() throws SQLException {
		/*
		PoolDataSource dataSource = PoolDataSourceFactory.getPoolDataSource();
		dataSource.setURL(url);
		dataSource.setUser(userName);
		dataSource.setPassword(pd);
		dataSource.setConnectionFactoryClassName("oracle.jdbc.pool.OracleDataSource");
		dataSource.setConnectionPoolName("mandantDevelopJUnitPool" + UUID.randomUUID());
		dataSource.setConnectionWaitTimeout(10);
		dataSource.setMinPoolSize(0);
		dataSource.setMaxPoolSize(10);
		dataSource.setMaxStatements(10);
		dataSource.setInitialPoolSize(1);
		dataSource.setInactiveConnectionTimeout(3600);
		dataSource.setAbandonedConnectionTimeout(1800);
		dataSource.setValidateConnectionOnBorrow(true);
		dataSource.setSQLForValidateConnection("SELECT 1 FROM dual");
		return dataSource;
		*/
		
		DriverManagerDataSource ds = new DriverManagerDataSource();
		ds.setDriverClassName("oracle.jdbc.driver.OracleDriver");
		ds.setUrl("jdbc:oracle:thin:@telisdb5:1521:tel1");
		ds.setUsername("t20");
		ds.setPassword("ad01yoda");
		return ds;
	}
	
	@Bean
	public NamedParameterJdbcTemplate jdbcTemplate(DataSource dataSource) {
		return new NamedParameterJdbcTemplate(dataSource);
	}

	/**
	 * Erzeugt einen {@link DataSourceTransactionManager}
	 * 
	 * @return {@link PlatformTransactionManager}
	 * @throws SQLException SQLException
	 */
	@Bean
	public PlatformTransactionManager transactionManager() throws SQLException {
		return new DataSourceTransactionManager(dataSource());
	}

}
