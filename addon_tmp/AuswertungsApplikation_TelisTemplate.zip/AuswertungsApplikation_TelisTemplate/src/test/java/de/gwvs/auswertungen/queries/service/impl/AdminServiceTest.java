package de.gwvs.auswertungen.queries.service.impl;

import static org.junit.Assert.assertNotNull;

import javax.inject.Inject;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import de.gwvs.auswertungen.queries.service.AdminService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = AdminServiceTestConfig.class)
public class AdminServiceTest {
	
	@Inject
	private AdminService adminService;
	
	@Before
	public void setUp() {
	}
	
	@Test
	public void testGetQueryTitle() {
		assertNotNull(adminService.getAllQueryIds());
	}
}
