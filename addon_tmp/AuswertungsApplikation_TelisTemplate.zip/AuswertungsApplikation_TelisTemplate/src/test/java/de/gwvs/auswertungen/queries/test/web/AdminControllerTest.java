package de.gwvs.auswertungen.queries.test.web;

public class AdminControllerTest {

}
