package de.gwvs.auswertungen.queries.service.impl;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import de.gwvs.auswertungen.commons.test.config.InfrastructureTestConfig;
import de.gwvs.auswertungen.queries.dao.QueryDao;
import de.gwvs.auswertungen.queries.dao.impl.QueryDaoImpl;
import de.gwvs.auswertungen.queries.service.QueryService;

@Configuration
@Import( { InfrastructureTestConfig.class } )
public class QueryServiceTestConfig {

	@Bean
	public QueryService queryService() {
		return new QueryServiceImpl();
	}
	
	@Bean
	public QueryDao queryDao() {
		return new QueryDaoImpl();
	}
	
}
