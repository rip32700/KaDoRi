package de.gwvs.auswertungen.queries.service.impl;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertNotNull;

import javax.inject.Inject;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import de.gwvs.auswertungen.queries.service.QueryService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = QueryServiceTestConfig.class)
public class QueryServiceTest {

	private final String username = "prieger";
	private final Long queryId = 2L;
	
	@Inject
	private QueryService queryService;
	
	@Before
	public void setUp() {
	}
	
	@Test
	public void testGetQueries() {
		assertNotNull(queryService.getAllQueries());
	}
	
	@Test
	public void testGetFavs() {
		assertNotNull(queryService.getAllFavs(username));
	}
	
	@Test
	public void testGetQueryById() {
		assertNotNull(queryService.getQueryById(queryId));
	}
	
	@Test
	public void testGetBereicheList() {
		assertNotNull(queryService.getBereicheList(queryService.getAllQueries()));
	}
	
	@Test
	public void testGetErstelltList() {
		assertNotNull(queryService.getErstelltList(queryService.getAllQueries()));
	}
	
	@Test
	public void testAddRowToFav() {
		queryService.addRowToFav(queryId, username);
		assertFalse(queryService.addRowToFav(queryId, username));
		queryService.removeQueryFromFav(queryId, username);
		assertTrue(queryService.addRowToFav(queryId, username));
	}
	
	@Test
	public void testRemoveQueryFromFav() {
		queryService.removeQueryFromFav(queryId, username);
		assertFalse(queryService.removeQueryFromFav(queryId, username));
		queryService.addRowToFav(queryId, username);
		assertTrue(queryService.removeQueryFromFav(queryId, username));
	}
	
}
