package de.gwvs.auswertungen.queries.service.impl;

import static org.junit.Assert.assertNotNull;

import javax.inject.Inject;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import de.gwvs.auswertungen.queries.service.ProcessingService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = ProcessingServiceTestConfig.class)
public class ProcessingServiceTest {

	private final String username = "prieger";
	private final Long queryId = 2L;
	private String sql = "SELECT * FROM au_auswertungen";
	
	@Inject
	private ProcessingService processingService;
	
	@Before
	public void setUp() {
	}
	
	@Test
	public void testGetQueryTitle() {
		assertNotNull(processingService.getQueryTitle(queryId));
	}
	
	@Test
	public void testRegisterQueryAndStartAsync() {
		processingService.registerQuery(queryId, sql);
		assertNotNull(processingService.startAsync(queryId, username));
	}
}
