package de.gwvs.auswertungen.queries.service.impl;

import static org.junit.Assert.assertNotNull;

import java.util.List;

import javax.inject.Inject;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import de.gwvs.auswertungen.queries.domain.BoundVariable;
import de.gwvs.auswertungen.queries.service.ParameterService;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = ParameterServiceTestConfig.class)
public class ParameterServiceTest {

	private final String username = "prieger";
	private final Long queryId = 1L;
	
	@Inject
	private ParameterService parameterService;
	
	@Before
	public void setUp() {
	}
	
	@Test
	public void testGetBoundVariables() {
		assertNotNull(parameterService.getParametersOfAQuery(queryId));
	}
	
	@Test
	public void testResolveSqlStatement() {
		//List<BoundVariable> boundVars = parameterService.getParametersOfAQuery(queryId);
		//assertNotNull(parameterService.resolveSqlStatement(queryId, boundVars));
	}
}
