package de.gwvs.auswertungen.queries.test.web;

import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.hasItem;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.forwardedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import javax.inject.Inject;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import de.gwvs.auswertungen.queries.domain.Query;
import de.gwvs.auswertungen.queries.service.QueryService;

@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration(classes = {CommonsTestConfig.class, InfrastructureTestConfig.class, WebMvcConfig.class})
@WebAppConfiguration
public class QueryControllerTest {

    private MockMvc mockMvc;
    
	@Inject
	private WebApplicationContext webApplicationContext;
	
	@Inject
	private QueryService serviceMock;
	
    @Before
    public void setUp() {
    	mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
    }
    
    @SuppressWarnings("unchecked")
	@Test
	public void querySelectionShouldAddQueriesToModelAndRenderQuerySelectionView() throws Exception {
		/*Query firstQuery  = new Query(1L, "Test 1", "Test 1", "Test 1", "testuser1", LocalDate.now(), "Test 1", "Test 1");
		Query secondQuery = new Query(2L, "Test 2", "Test 2", "Test 2", "testuser2", LocalDate.now(), "Test 2", "Test 2");
		Query firstFav    = new Query(3L, "Fav 1", "Fav 1", "Fav 1", "fav testuser1", LocalDate.now(), "Fav 1", "Fav 1");
		List<String> bereichsList = Arrays.asList("Test 1", "Test 2", "Fav 1");
		List<String> erstelltList = Arrays.asList(LocalDate.now().toString());
		final String username = "prieger";
		
		when(serviceMock.getAllQueries(username)).thenReturn(Arrays.asList(firstQuery, secondQuery));
		when(serviceMock.getAllFavs(username)).thenReturn(Arrays.asList(firstFav));
		//when(serviceMock.getAllFavs()).thenReturn(null);
		when(serviceMock.getBereicheList(username)).thenReturn(bereichsList);
		when(serviceMock.getErstelltList(username)).thenReturn(erstelltList);
		
		mockMvc.perform(get("/"))
			   .andExpect(status().isOk())
			   .andExpect(view().name("query_selection"))
			   .andExpect(forwardedUrl("/WEB-INF/views/query_selection.jsp"))
			   .andExpect(model().attribute("queryList", hasSize(2)))
			   .andExpect(model().attribute("queryList", hasItem(
					   allOf(
							   hasProperty("queryId", is(1L)),
							   hasProperty("text", is("Test 1")),
							   hasProperty("art", is("Test 1")),
							   hasProperty("benutzer", is("testuser1")),
							   hasProperty("erstellt", is(LocalDate.now())),
							   hasProperty("bereich", is("Test 1")),
							   hasProperty("sql", is("Test 1")),
							   hasProperty("beschreibung", is("Test 1"))
							)
			    )))
			   .andExpect(model().attribute("queryList", hasItem(
					   allOf(
							   hasProperty("queryId", is(2L)),
							   hasProperty("text", is("Test 2")),
							   hasProperty("art", is("Test 2")),
							   hasProperty("benutzer", is("testuser2")),
							   hasProperty("erstellt", is(LocalDate.now())),
							   hasProperty("bereich", is("Test 2")),
							   hasProperty("sql", is("Test 2")),
							   hasProperty("beschreibung", is("Test 2"))
							)
			    )))
			   .andExpect(model().attribute("favList", hasSize(1)))
			   .andExpect(model().attribute("favList", hasItem(
					   allOf(
							   hasProperty("queryId", is(3L)),
							   hasProperty("text", is("Fav 1")),
							   hasProperty("art", is("Fav 1")),
							   hasProperty("benutzer", is("fav testuser1")),
							   hasProperty("erstellt", is(LocalDate.now())),
							   hasProperty("bereich", is("Fav 1")),
							   hasProperty("sql", is("Fav 1")),
							   hasProperty("beschreibung", is("Fav 1"))
							)
			    )))
			   .andExpect(model().attribute("bereicheList", hasSize(3)))
			   .andExpect(model().attribute("erstelltList", hasSize(1)));
		
		verify(serviceMock, times(1)).getAllQueries(username);
		verify(serviceMock, times(1)).getAllFavs(username);
		verify(serviceMock, times(1)).getBereicheList(username);
		verify(serviceMock, times(1)).getErstelltList(username);
		verifyNoMoreInteractions(serviceMock);*/
	}
}
