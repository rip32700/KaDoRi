package de.gwvs.auswertungen.queries.dao.impl;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import de.gwvs.auswertungen.commons.test.config.InfrastructureTestConfig;
import de.gwvs.auswertungen.queries.dao.BoundVariableDao;

@Configuration
@Import( { InfrastructureTestConfig.class } )
public class BoundVariableDaoTestConfig {

	@Bean
	public BoundVariableDao boundVariableDao() {
		return new BoundVariableDaoImpl();
	}
}
