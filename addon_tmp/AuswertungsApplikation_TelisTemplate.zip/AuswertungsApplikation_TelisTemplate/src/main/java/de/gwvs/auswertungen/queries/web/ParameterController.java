package de.gwvs.auswertungen.queries.web;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.util.WebUtils;

import de.gwvs.auswertungen.commons.security.domain.AuswertungenUser;
import de.gwvs.auswertungen.queries.domain.BoundParameter;
import de.gwvs.auswertungen.queries.domain.Parameter;
import de.gwvs.auswertungen.queries.domain.Query;
import de.gwvs.auswertungen.queries.service.ParameterService;
import de.gwvs.auswertungen.queries.web.validation.BoundParameterFormData;
import de.gwvs.auswertungen.queries.web.validation.BoundVariableValidator;

/**
 * Controller for parameter view
 * @author prieger
 * @version 1.0
 */
@Controller
@SessionAttributes("boundParameterFormData")
public class ParameterController {

	/**
	 * command string for form data in model
	 */
	private final String COMMAND = "boundParameterFormData";
	
	/**
	 * parameter service
	 */
	private ParameterService service;
	
	/**
	 * parameter validator
	 */
	private Validator validator;
	
	/**
	 * Constructor
	 * @param service parameter service
	 * @param validator parameter validator
	 */
	@Inject
	public ParameterController(final ParameterService service, final BoundVariableValidator validator) {
		this.service = service;
		this.validator = validator;
	}
	
	/**
	 * Extracts the bound variables of the selected query and prepares the parameter view 
	 * to insert them
	 * @param queryId ID of selected query (path variable)
	 * @param model model object
	 * @param request HTTP Servlet request
	 * @param user user details
	 * @return name of the parameter view
	 */
	@RequestMapping(value="/parameter/{queryId}", method=RequestMethod.GET)
	public String parameterSelection(@PathVariable(value="queryId") final Long queryId, final Model model, final HttpServletRequest request, @AuthenticationPrincipal final AuswertungenUser user) {
		List<BoundParameter> boundParas = extractBoundParametersFromQuery(queryId);
		model.addAttribute(COMMAND, new BoundParameterFormData(queryId, boundParas));
		return "parameter";
	}

	/**
	 * Validates the entered parameters and redirects to the processing
	 * controller if validation succeeded
	 * @param formData parameter form data object
	 * @param bindingResult binding result object for validation
	 * @param model model object
	 * @param request HTTP Servlet request
	 * @param user user details
	 * @return view name depending on validation
	 */
	@RequestMapping(value="/parameter/{queryId}", method=RequestMethod.POST)
	public String parameterSelected(@ModelAttribute(COMMAND) final BoundParameterFormData formData, final BindingResult bindingResult, final HttpServletRequest request, @AuthenticationPrincipal final AuswertungenUser user) {

		validator.validate(formData, bindingResult);
		
		// no errors -> process the insertions and delete form data object from session
		if(!bindingResult.hasErrors()) {
			// set the result query into the session for the processing controller
			Query query = getQueryFromParameterFormDataObject(formData);
			WebUtils.setSessionAttribute(request, "resultQuery", query);
			
			return "redirect:/processing";
		}
				
		// there were errors 
		return "parameter";
	}
	
	/**
	 * Transforms parameter form data object into the a query with resolved sql statement 
	 * @param formData parameter form data object
	 * @param username user details
	 * @return resolved query object
	 */
	private Query getQueryFromParameterFormDataObject(final BoundParameterFormData formData) {
		return service.resolveSqlStatement(formData.getQueryId(), formData.getBoundVariables());
	}
	
	private List<BoundParameter> extractBoundParametersFromQuery(final Long queryId) {
		final List<Parameter> parameters = service.getParametersOfAQuery(queryId);
		List<BoundParameter> boundParas = new ArrayList<>();
		for(Parameter para : parameters) {
			boundParas.add(new BoundParameter(para, ""));
		}
		return boundParas;
	}
	
}
