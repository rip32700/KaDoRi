/*
 * Copyright (C) 2007 GWVS mbH - All rights reserved.
 */
package de.gwvs.auswertungen.commons.web.interceptor;

import java.util.Calendar;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.util.Assert;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

/**
 * Eine Implementierung eines zeit basierenden Interceptors. Zwischen dem gesetzten Zeitraum wird die Anwendung auf eine Seite umgelegt.
 * 
 * @author Ronny Krammer
 * @version 1.0
 * 
 */
public class TimeBasedAccessInterceptor extends HandlerInterceptorAdapter {

	/**
	 * Volle Stunde, ab der die Umlenkung nicht berücksichtigt wird
	 */
	private int openingTime = 2;

	/**
	 * Volle Stunde, ab der die Umlenkung berücksichtigt wird
	 */
	private int closingTime = 24;

	/**
	 * Seite auf die umgelenkt wird
	 */
	private String outTimeLink = "";

	/**
	 * URLs, die nicht berücksichtigt werden
	 */
	private List<String> excludedLinks = null;

	/**
	 * Setzt die volle Stunde, ab der die Umlenkung nicht berücksichtigt wird
	 * 
	 * @param openingTime
	 */
	public void setOpeningTime(int openingTime) {
		this.openingTime = openingTime;
	}

	/**
	 * Setzt die volle Stunde, ab der die Umlenkung berücksichtigt wird
	 * 
	 * @param closingTime
	 */
	public void setClosingTime(int closingTime) {
		this.closingTime = closingTime;
	}

	/**
	 * Setzt die Seite, auf die umgelenkt wird
	 * 
	 * @param outTimeLink Seite auf die umgelenk wird
	 */
	public void setOutTimeLink(String outTimeLink) {
		this.outTimeLink = outTimeLink;
	}

	/**
	 * Setzt die URL, die nicht berücksichtigt wird
	 * 
	 * @param excludedLink URL, die nicht berücksichtigt wird
	 */
	@Resource(name = "excludedLinks")
	public void setExcludedLinks(List<String> excludedLinks) {
		Assert.notNull(excludedLinks, "The array of excludedLinks cannot be set to null");
		this.excludedLinks = excludedLinks;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.web.servlet.handler.HandlerInterceptorAdapter#preHandle
	 * (javax.servlet.http.HttpServletRequest,
	 * javax.servlet.http.HttpServletResponse, java.lang.Object)
	 */
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		Calendar cal = Calendar.getInstance();
		int hour = cal.get(Calendar.HOUR_OF_DAY);

		if ((openingTime <= hour) && (hour < closingTime)) {
			return true;
		} else {

			if (excludedLinks != null) {
				for (String url : excludedLinks) {
					if (url.contains("*")) {
						if (request.getRequestURI().contains(url.replace("*", ""))) {
							return true;
						}
					} else {
						if (request.getRequestURI().endsWith(url)) {
							return true;
						}
					}
				}
			}

			request.setAttribute("noMenu", true);
			RequestDispatcher dispatcher = request.getRequestDispatcher(outTimeLink);
			dispatcher.forward(request, response);

			return false;
		}
	}
}
