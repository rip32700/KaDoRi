/*
 * Copyright (C) 2015 GWVS mbH - All rights reserved.
 */
package de.gwvs.auswertungen.commons.web.config;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.inject.Inject;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.ldap.core.support.BaseLdapPathContextSource;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.event.LoggerListener;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.ldap.DefaultSpringSecurityContextSource;
import org.springframework.security.ldap.authentication.BindAuthenticator;
import org.springframework.security.ldap.search.FilterBasedLdapUserSearch;
import org.springframework.security.ldap.search.LdapUserSearch;
import org.springframework.security.ldap.userdetails.DefaultLdapAuthoritiesPopulator;
import org.springframework.security.web.access.ExceptionTranslationFilter;
import org.springframework.security.web.authentication.RememberMeServices;

import de.gwvs.auswertungen.commons.security.dao.AuthenticationDao;
import de.gwvs.auswertungen.commons.security.dao.jdbc.AuthenticationDaoJdbc;
import de.gwvs.auswertungen.commons.security.ldap.authentication.TosLdapAuthenticationProvider;
import de.gwvs.auswertungen.commons.security.permissions.QueryPermissionEvaluator;
import de.gwvs.auswertungen.commons.security.service.AuthenticationService;
import de.gwvs.auswertungen.commons.security.service.impl.AuthenticationServiceImpl;
import de.gwvs.auswertungen.commons.security.web.authentication.rememberme.RememberMeUserDetailsService;
import de.gwvs.auswertungen.commons.security.web.authentication.rememberme.TosBasedRememberMeService;
import de.gwvs.auswertungen.commons.web.filter.UserTrackingFilter;
import de.gwvs.commons.tos.security.postprocessor.DefaultRolesPrefixPostProcessor;

/**
 * Security {@link Configuration}
 * 
 * @author Ronny Krammer
 * @version 1.0
 * 
 */
@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SecurityConfig extends WebSecurityConfigurerAdapter {

	/* (non-Javadoc)
	 * @see org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter#configure(org.springframework.security.config.annotation.web.builders.HttpSecurity)
	 */
	@Override
	protected void configure(HttpSecurity http) throws Exception {
	//@formatter:off
		http.authorizeRequests().antMatchers("/login*", "/impressum").permitAll()
		.anyRequest().authenticated()
			.anyRequest().access("hasRole('ROLE_TOSAUSWERTUNGEN')")
			.and().anonymous().key(SecurityConfig.REMEMBERME_KEY)
			.and().rememberMe().key(SecurityConfig.REMEMBERME_KEY).rememberMeServices(rememberMeService())
			.and().sessionManagement().sessionFixation().migrateSession()
			.and().addFilterAfter(userTrackingFilter(), ExceptionTranslationFilter.class)
			.formLogin().loginPage(SecurityConfig.LOGIN_PAGE).defaultSuccessUrl(DEFAULT_TARGET_URL)
			.and().logout().deleteCookies("JSESSIONID").invalidateHttpSession(true)
			.and().exceptionHandling().accessDeniedPage(SecurityConfig.ACCESS_DENIED_URL)
			.and().csrf().disable();
		//@formatter:on
	}

	/* (non-Javadoc)
	 * @see org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter#configure(org.springframework.security.config.annotation.web.builders.WebSecurity)
	 */
	@Override
	public void configure(WebSecurity web) throws Exception {
		web.ignoring().antMatchers("/error.jsp", "/error/**", "/resources/**", "/scripts/**", "/status", "/styles/**", "/version", "/webjars/**");
	}

	/**
	 * Erzeugt die Liste mit erlaubten Berechtigungen
	 * 
	 * @return Liste mit erlaubten Berechtigungen
	 */
	@Bean(name = "allowedAuthorities")
	public List<String> allowedAuthorities() {
		return new ArrayList<String>(Arrays.asList("ROLE_TOSAUSWERTUNGEN"));
	}

	/**
	 * URL für einen unerlaubten Zugriff
	 */
	private static final String ACCESS_DENIED_URL = "/accessdenied";

	/**
	 * Zieladresse nach einem erfolgreichen Login
	 */
	private static final String DEFAULT_TARGET_URL = "/startseite";

	/**
	 * URL der Loginseite
	 */
	private static final String LOGIN_PAGE = "/login";

	/**
	 * Remember me Key
	 */
	private static final String REMEMBERME_KEY = "gwvsR0cks-skc0Rsvwg";

	/**
	 * Remember me Parameter
	 */
	private static final String REMEMBERME_PARAM = "_remember_me";

	/**
	 * Erzeugt einen {@link DefaultRolesPrefixPostProcessor}
	 * 
	 * @return {@link DefaultRolesPrefixPostProcessor}
	 */
	@Bean
	public static DefaultRolesPrefixPostProcessor defaultRolesPrefixPostProcessor() {
		return new DefaultRolesPrefixPostProcessor();
	}

	/**
	 * {@link DataSource}
	 */
	@Inject
	private DataSource dataSource = null;

	/**
	 * Basis für die Suche nach Gruppen
	 */
	@Value("${security.ldap.groupSearchBase}")
	private String groupSearchBase = "";

	/**
	 * LDAP Manager DN
	 */
	@Value("${security.ldap.managerDn}")
	private String managerDn = "";

	/**
	 * LDAP Manager Password
	 */
	@Value("${security.ldap.managerPassword}")
	private String managerPassword = "";

	/**
	 * URL der LDAP Providers
	 */
	@Value("${security.ldap.providerUrl}")
	private String providerUrl = "";

	/**
	 * Filter für die Suche
	 */
	@Value("${security.ldap.searchFilter}")
	private String searchFilter = "";

	/**
	 * DN Muster des Users
	 */
	@Value("${security.ldap.userDnPatterns}")
	private String userDnPattern = "";

	/**
	 * Erzeugt einen {@link AuthenticationDao}
	 * 
	 * @return {@link AuthenticationDao}
	 */
	@Bean
	public AuthenticationDao authenticationDao() {
		AuthenticationDaoJdbc authenticationDao = new AuthenticationDaoJdbc();
		authenticationDao.setDataSource(dataSource);
		return authenticationDao;
	}

	/**
	 * Erzeugt einen {@link TosLdapAuthenticationProvider}
	 * 
	 * @return {@link AuthenticationProvider}
	 */
	@Bean
	public AuthenticationProvider authenticationProvider() {
		BaseLdapPathContextSource contextSource = contextSource();

		String[] userDnPatterns = { userDnPattern };
		BindAuthenticator authenticator = new BindAuthenticator(contextSource);
		authenticator.setUserDnPatterns(userDnPatterns);
		authenticator.setUserSearch(ldapUserSearch());

		DefaultLdapAuthoritiesPopulator populator = new DefaultLdapAuthoritiesPopulator(contextSource, groupSearchBase);
		populator.setSearchSubtree(true);

		TosLdapAuthenticationProvider authenticationProvider = new TosLdapAuthenticationProvider(authenticator, populator);
		authenticationProvider.setAuthenticationService(authenticationService());
		return authenticationProvider;
	}

	/**
	 * Erzeugt einen {@link AuthenticationService}
	 * 
	 * @return {@link AuthenticationService}
	 */
	@Bean
	public AuthenticationService authenticationService() {
		AuthenticationServiceImpl authenticationService = new AuthenticationServiceImpl();
		authenticationService.setAuthenticationDao(authenticationDao());
		authenticationService.setAllowedAuthorities(allowedAuthorities());
		return authenticationService;
	}

	/**
	 * Setzt den AuthenticationProvider
	 * 
	 * @param auth {@link AuthenticationManagerBuilder}
	 * @throws Exception Exception
	 */
	@Inject
	public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
		auth.authenticationProvider(authenticationProvider()).eraseCredentials(false);
	}

	/**
	 * Erzeugt einen {@link DefaultSpringSecurityContextSource}
	 * 
	 * @return {@link BaseLdapPathContextSource}
	 */
	@Bean
	public BaseLdapPathContextSource contextSource() {
		DefaultSpringSecurityContextSource contextSource = new DefaultSpringSecurityContextSource(providerUrl);
		contextSource.setUserDn(managerDn);
		contextSource.setPassword(managerPassword);
		return contextSource;
	}

	/**
	 * Erzeugt ein {@link FilterBasedLdapUserSearch} Object
	 * 
	 * @return {@link LdapUserSearch}
	 */
	@Bean
	public LdapUserSearch ldapUserSearch() {
		FilterBasedLdapUserSearch userSearch = new FilterBasedLdapUserSearch("", searchFilter, contextSource());
		userSearch.setSearchSubtree(true);
		return userSearch;
	}

	/**
	 * Erzeugt einen {@link LoggerListener}
	 * 
	 * @return {@link LoggerListener}
	 */
	@Bean
	public LoggerListener loggerListener() {
		return new LoggerListener();
	}

	/**
	 * Erzeugt einen {@link TosBasedRememberMeService}
	 * 
	 * @return {@link RememberMeServices}
	 */
	@Bean
	public RememberMeServices rememberMeService() {
		TosBasedRememberMeService rememberMeService = new TosBasedRememberMeService(SecurityConfig.REMEMBERME_KEY, new RememberMeUserDetailsService());
		rememberMeService.setAlwaysRemember(false);
		rememberMeService.setParameter(SecurityConfig.REMEMBERME_PARAM);
		rememberMeService.setLdapAuthenticationProvider((TosLdapAuthenticationProvider) authenticationProvider());
		return rememberMeService;
	}

	/**
	 * Erzeugt einen {@link UserTrackingFilter}
	 * 
	 * @return {@link UserTrackingFilter}
	 */
	@Bean
	public UserTrackingFilter userTrackingFilter() {
		return new UserTrackingFilter();
	}
	
	@Bean
	public QueryPermissionEvaluator queryPermissionEvaluator() {
		QueryPermissionEvaluator evaluator = new QueryPermissionEvaluator();
		return evaluator;
	}

}
