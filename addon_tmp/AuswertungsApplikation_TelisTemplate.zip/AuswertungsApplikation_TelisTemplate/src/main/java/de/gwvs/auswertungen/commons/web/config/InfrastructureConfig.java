/*
 * Copyright (C) 2015 GWVS mbH - All rights reserved.
 */
package de.gwvs.auswertungen.commons.web.config;

import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import de.gwvs.auswertungen.queries.web.validation.BoundVariableValidator;
import de.gwvs.auswertungen.queries.web.validation.ParameterValidator;
import de.gwvs.auswertungen.queries.web.validation.QueryValidator;
import de.gwvs.commons.tos.jdbc.datasource.TestedDataSourceAdapter;
import oracle.ucp.jdbc.PoolDataSource;

/**
 * {@link Configuration} der Datenbankunterstützung
 * 
 * @author Ronny Krammer
 * @version 1.0
 * 
 */
@EnableTransactionManagement
@Configuration
public class InfrastructureConfig {

	/**
	 * Client Info
	 */
	private static final String CLIENT_INFO = "Auswertungen";
	
	/**
	 * JNDI Name der Datenbank
	 */
	@Value("${database.datasource}")
	private String dataSourceName = "";

	/**
	 * Erzeugt die {@link PoolDataSource}
	 * 
	 * @return {@link DataSource}
	 * @throws SQLException SQLException
	 */
	@Bean
	public DataSource dataSource() throws SQLException {
		/*
		final JndiDataSourceLookup dsLookup = new JndiDataSourceLookup();
		dsLookup.setResourceRef(true);
		DataSource targetDataSource = dsLookup.getDataSource(dataSourceName);
		TestedDataSourceAdapter dataSource = new TestedDataSourceAdapter();
		dataSource.setTargetDataSource(targetDataSource);
		dataSource.setClientInfo(true);
		dataSource.setClientInfoModule(CLIENT_INFO);
		return dataSource;
		 */
		
		DriverManagerDataSource ds = new DriverManagerDataSource();
		ds.setDriverClassName("oracle.jdbc.driver.OracleDriver");
		ds.setUrl("jdbc:oracle:thin:@telisdb5:1521:tel1");
		ds.setUsername("t20");
		ds.setPassword("ad01yoda");
		return ds;
	}
	
	@Bean
	public NamedParameterJdbcTemplate jdbcTemplate(DataSource dataSource) {
		return new NamedParameterJdbcTemplate(dataSource);
	}
	
	@Bean
	public BoundVariableValidator boundVariableValidator() {
		return new BoundVariableValidator();
	}
	
	@Bean
	public ParameterValidator parameterValidator() {
		return new ParameterValidator();
	}
	
	@Bean
	public QueryValidator queryValidator() {
		return new QueryValidator();
	}

	/**
	 * Erzeugt einen {@link DataSourceTransactionManager}
	 * 
	 * @return {@link PlatformTransactionManager}
	 * @throws SQLException SQLException
	 */
	@Bean
	public PlatformTransactionManager transactionManager() throws SQLException {
		return new DataSourceTransactionManager(dataSource());
	}

}
