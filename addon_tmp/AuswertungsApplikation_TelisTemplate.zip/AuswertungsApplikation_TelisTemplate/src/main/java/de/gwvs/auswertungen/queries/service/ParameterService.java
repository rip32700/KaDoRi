package de.gwvs.auswertungen.queries.service;

import java.util.List;

import de.gwvs.auswertungen.queries.domain.BoundParameter;
import de.gwvs.auswertungen.queries.domain.Parameter;
import de.gwvs.auswertungen.queries.domain.Query;

/**
 * interface for the parameter service
 * @author prieger
 * @version 1.0
 */
public interface ParameterService {

	Query resolveSqlStatement(final Long queryId, final List<BoundParameter> list);
	List<Parameter> getParametersOfAQuery(final Long queryId);
	
	Parameter getParameterById(final Long parameterId);
	List<Parameter> getAllParameters();
	List<String> getTypeList(List<Parameter> parameters);
	boolean updateParameter(Parameter parameter);
	List<Long> getAllIds();
	void insertParameter(Parameter parameter);
}
