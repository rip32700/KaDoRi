package de.gwvs.auswertungen.queries.web.validation;

import org.apache.commons.validator.routines.FloatValidator;
import org.apache.commons.validator.routines.IntegerValidator;
import org.apache.commons.validator.routines.LongValidator;
import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;

import de.gwvs.commons.tos.utils.DateUtils;

/**
 * Validation utility class to verify certain data types 
 * @author prieger
 * @version 1.0
 */
public final class ValidatorUtils {

	/**
	 * default constructor
	 */
	private ValidatorUtils() { 
	}

	/**
	 * Checks if a given long value is valid
	 * @param errors errors object
	 * @param value value that is to check
	 * @param field field name of the value
	 * @param errorCode error code 
	 * @param defaultMessage default message
	 * @param min minimum value
	 * @param max maximum value
	 * @param errorCodeRange error code range
	 * @param defaultMessageRange default message range
	 */
	public static void rejectIfNotValidLong(final Errors errors, final String value, final String field, final String errorCode, final String defaultMessage, final long min, final long max, final String errorCodeRange, final String defaultMessageRange) {
		if(StringUtils.hasText(value)) {
			LongValidator longValidator = LongValidator.getInstance();
			if(!longValidator.isValid(value)) {
				errors.rejectValue(field, errorCode, defaultMessage);
			} else if (!longValidator.isInRange(longValidator.validate(value), min, max)) {
				errors.rejectValue(field, errorCodeRange, defaultMessageRange);
			}
		}
	}

	/**
	 * Checks if a given string value is too long
	 * @param errors errors object
	 * @param value value that is to check
	 * @param field field name of the value
	 * @param errorCode error code 
	 * @param defaultMessage default message
	 * @param max maximum value
	 */
	public static void rejectIfStringTooLong(final Errors errors, final String value, final String field, final String errorCode, final String defaultMessage, final int max) {
		if(StringUtils.hasText(value) && value.length() > max) {
			errors.rejectValue(field, errorCode, defaultMessage);
		}
	}
	
	/**
	 * Checks if a given string value is too short
	 * @param errors errors object
	 * @param value value that is to check
	 * @param field field name of the value
	 * @param errorCode error code 
	 * @param defaultMessage default message
	 * @param min minimum value
	 */
	public static void rejectIfStringTooShort(final Errors errors, final String value, final String field, final String errorCode, final String defaultMessage, final int min) {
		if(StringUtils.hasText(value) && value.length() < min) {
			errors.rejectValue(field, errorCode, defaultMessage);
		}
	}
	
	/**
	 * Checks if a given string value's length is in a given range
	 * @param errors errors object
	 * @param value value that is to check
	 * @param field field name of the value
	 * @param errorCode error code 
	 * @param defaultMessage default message
	 * @param min minimum value
	 * @param max maximum value
	 */
	public static void rejectIfStringNotInRange(final Errors errors, final String value, final String field, final String errorCode, final String defaultMessage, final int min, final int max) {
		if(StringUtils.hasText(value) && (value.length() < min || value.length() > max)) {
			errors.rejectValue(field, errorCode, defaultMessage);
		}
	}

	/**
	 * Checks if a given date is valid and in the format of dd.MM.yyyy
	 * @param errors errors object
	 * @param value value that is to check
	 * @param field field name of the value
	 * @param errorCode error code 
	 * @param defaultMessage default message
	 */
	public static void rejectIfNotValidDate(final Errors errors, final String value, final String field, final String errorCode, final String defaultMessage) {
		if(StringUtils.hasText(value)) {
			String formatedDate = DateUtils.format(value.trim(), "dd.MM.yyyy");
			if (formatedDate.length() == 10) {
				if (!DateUtils.isValid(formatedDate, "dd.MM.yyyy", true)) {
					errors.rejectValue(field, errorCode, defaultMessage);
				}
			} else {
				errors.rejectValue(field, errorCode, defaultMessage);
			}

		}
	}

	/**
	 * Checks if a given integer value is valid
	 * @param errors errors object
	 * @param value value that is to check
	 * @param field field name of the value
	 * @param errorCode error code 
	 * @param defaultMessage default message
	 */
	public static void rejectIfNotValidInteger(final Errors errors, final String value, final String field, final String errorCode, final String defaultMessage) {
		if(StringUtils.hasText(value)) {
			IntegerValidator longValidator = IntegerValidator.getInstance();
			if(!longValidator.isValid(value)) {
				errors.rejectValue(field, errorCode, defaultMessage);
			}
		}
	}

	/**
	 * Checks if a given float value is valid
	 * @param errors errors object
	 * @param value value that is to check
	 * @param field field name of the value
	 * @param errorCode error code 
	 * @param defaultMessage default message
	 */
	public static void rejectIfNotValidFloat(final Errors errors, final String value, final String field, final String errorCode, final String defaultMessage) {
		if(StringUtils.hasText(value)) {
			FloatValidator longValidator = FloatValidator.getInstance();
			if(!longValidator.isValid(value)) {
				errors.rejectValue(field, errorCode, defaultMessage);
			}
		}
	}

	public static void rejectIfNotValidBooleanChar(Errors errors, String value, String field, String errorCode, String defaultMessage) {
		if(StringUtils.hasText(value)) {
			
			if(!("J".equals(value) || "N".equals(value))) {
				errors.rejectValue(field, errorCode, defaultMessage);
			}
		}
	}

}
