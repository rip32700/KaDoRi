package de.gwvs.auswertungen.queries.web;

import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;

import de.gwvs.auswertungen.commons.security.domain.AuswertungenUser;
import de.gwvs.auswertungen.queries.domain.Query;
import de.gwvs.auswertungen.queries.domain.ResultObject;
import de.gwvs.auswertungen.queries.excel.ExcelReportView;
import de.gwvs.auswertungen.queries.exceptions.ResourceNotFoundException;
import de.gwvs.auswertungen.queries.service.ProcessingService;

/**
 * Controller for Processing a Query
 * 
 * @author prieger
 * @version 1.0
 * 
 */
@Controller
public class ProcessingController {

	/**
	 * processing service
	 */
	private ProcessingService service;
	
	/**
	 * Constructor
	 * @param service processing service
	 */
	@Inject
	public ProcessingController(final ProcessingService service) {
		this.service = service;
	}
	
	/**
	 * Prepares the processing view and registers the current query 
	 * in the service
	 * @param model model object
	 * @param request HTTP Servlet request
	 * @param user user details
	 * @return processing view name
	 */
	@RequestMapping(value="/processing", method = RequestMethod.GET) 
	public String processing(final Model model, final HttpServletRequest request) {
		
		Query query = new Query();
		if(WebUtils.getSessionAttribute(request, "resultQuery") != null) {
			query = (Query) WebUtils.getSessionAttribute(request, "resultQuery");
		} else {
			throw new ResourceNotFoundException("Auswertung konnte bei Ausführung des Statements nicht gefunden werden.");
		}
		
		// put query into the map within the service, so that it can be grabbed 
		// during the async process later on
		service.registerQuery(query.getQueryId(), query.getSql());
		
		model.addAttribute("query", query);
		model.addAttribute("resultObject", new ResultObject());
		
		return "processing";
	}
	
	/**
	 * Kicks off the execution of the query selected by the user asynchronously and adds 
	 * a tracking instance into the database and returns result
	 * @param queryId ID of the query
	 * @param user user details
	 * @return list of list of strings: 1st inner list represents the column names,
	 * 									2nd inner list represents the rows
	 */
	@RequestMapping(value="/startAsync/{queryId}", method = RequestMethod.GET) 
	public @ResponseBody List<List<String>> startAsync(@PathVariable("queryId") final Long queryId, @AuthenticationPrincipal final AuswertungenUser user) {
		return service.startAsync(queryId, user.getUsername());
	}
	
	/**
	 * Exports the results of the selected query as an excel format which can be 
	 * either opened or saved
	 * @param resultObject result object with data
	 * @param model model object
	 * @param user user details
	 * @return excel view
	 */
	@RequestMapping(value = "/exportResultAsExcel", method = RequestMethod.POST)
    public ModelAndView downloadExcel(@ModelAttribute("resultObject") final ResultObject resultObject, final Model model, @AuthenticationPrincipal final AuswertungenUser user) {
		model.addAttribute("resultObject", resultObject);
		model.addAttribute("queryTitle", service.getQueryTitle(resultObject.getQueryId()));
		return new ModelAndView(new ExcelReportView(), "model", model);
    }
	
}
