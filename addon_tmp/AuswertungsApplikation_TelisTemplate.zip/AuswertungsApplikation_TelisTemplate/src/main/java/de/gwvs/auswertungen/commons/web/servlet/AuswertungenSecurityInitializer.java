/*
 * Copyright (C) 2015 GWVS mbH - All rights reserved.
 */
package de.gwvs.auswertungen.commons.web.servlet;

import org.springframework.core.annotation.Order;
import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;
import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

/**
 * Implements an {@link AbstractAnnotationConfigDispatcherServletInitializer}
 * 
 * @author Ronny Krammer
 * @version 1.0
 * 
 */
@Order(2)
public class AuswertungenSecurityInitializer extends AbstractSecurityWebApplicationInitializer {

	/* (non-Javadoc)
	 * @see org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer#enableHttpSessionEventPublisher()
	 */
	@Override
	protected boolean enableHttpSessionEventPublisher() {
		return true;
	}

	/* (non-Javadoc)
	 * @see org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer#isAsyncSecuritySupported()
	 */
	@Override
	protected boolean isAsyncSecuritySupported() {
		return false;
	}
}
