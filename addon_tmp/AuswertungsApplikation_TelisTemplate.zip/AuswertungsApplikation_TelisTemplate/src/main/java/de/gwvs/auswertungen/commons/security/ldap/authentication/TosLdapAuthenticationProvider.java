/*
 * Copyright (C) 2007 GWVS mbH - All rights reserved.
 */
package de.gwvs.auswertungen.commons.security.ldap.authentication;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.ldap.authentication.LdapAuthenticationProvider;
import org.springframework.security.ldap.authentication.LdapAuthenticator;
import org.springframework.security.ldap.userdetails.LdapAuthoritiesPopulator;
import org.springframework.util.Assert;

import de.gwvs.auswertungen.commons.security.domain.AuswertungenUser;
import de.gwvs.auswertungen.commons.security.service.AuthenticationService;

/**
 * Eine {@link org.springframework.security.providers.ldap.AuthenticationProvider} Implementierung. Als Provider wird ein LDAP Server verwendet. Zusätzlich werden noch fehlende Informationen aus der Datenbank geholt.
 * 
 * @author Ronny Krammer
 * @version 1.0
 * 
 */
public class TosLdapAuthenticationProvider extends LdapAuthenticationProvider {

	/**
	 * {@link AuthenticationService}
	 */
	private AuthenticationService authenticationService = null;

	public TosLdapAuthenticationProvider(LdapAuthenticator authenticator) {
		super(authenticator);
	}

	public TosLdapAuthenticationProvider(LdapAuthenticator authenticator, LdapAuthoritiesPopulator authoritiesPopulator) {
		super(authenticator, authoritiesPopulator);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.security.providers.ldap.LdapAuthenticationProvider
	 * #authenticate(org.springframework.security.Authentication)
	 */
	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {
		Assert.isInstanceOf(UsernamePasswordAuthenticationToken.class, authentication, messages.getMessage("AbstractUserDetailsAuthenticationProvider.onlySupports", "Only UsernamePasswordAuthenticationToken is supported"));

		UsernamePasswordAuthenticationToken userToken = (UsernamePasswordAuthenticationToken) authentication;
		String username = userToken.getName();
		int beginIndex = username.indexOf('\\');
		final Authentication auth;
		if (0 <= beginIndex) {
			username = username.substring(beginIndex + 1);
			auth = new UsernamePasswordAuthenticationToken(username, authentication.getCredentials());
		} else {
			auth = authentication;
		}
		return super.authenticate(auth);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.security.providers.ldap.LdapAuthenticationProvider
	 * #createSuccessfulAuthentication
	 * (org.springframework.security.providers.UsernamePasswordAuthenticationToken
	 * , org.springframework.security.userdetails.UserDetails)
	 */
	@Override
	protected Authentication createSuccessfulAuthentication(UsernamePasswordAuthenticationToken authentication, UserDetails user) {

		Object password = authentication.getCredentials();

		// Falls der LDAP Benutzer keine Berechtigung hat muss kein Auswertungen User erstellt werden.
		final UsernamePasswordAuthenticationToken result;
		if (!user.isAccountNonExpired() || !user.isAccountNonLocked() || !user.isCredentialsNonExpired() || !user.isEnabled()) {
			result = new UsernamePasswordAuthenticationToken(user, password, user.getAuthorities());
		} else {
			AuswertungenUser auswertungenUser = authenticationService.getAuswertungenUserFromUserDetails(user, String.valueOf(password));
			result = new UsernamePasswordAuthenticationToken(auswertungenUser, password, auswertungenUser.getAuthorities());
		}
		result.setDetails(authentication.getDetails());
		return result;
	}

	/**
	 * {@link AuthenticationService}
	 * 
	 * @param authenticationService {@link AuthenticationService}
	 */
	public void setAuthenticationService(AuthenticationService authenticationService) {
		this.authenticationService = authenticationService;
	}

}
