package de.gwvs.auswertungen.queries.service.impl;

import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import de.gwvs.auswertungen.queries.dao.QueryDao;
import de.gwvs.auswertungen.queries.domain.Query;
import de.gwvs.auswertungen.queries.service.QueryService;

/**
 * Implementation of the query service
 * @author prieger
 * @version 1.0
 */
@Service
public class QueryServiceImpl implements QueryService {

	/**
	 * query DAO object
	 */
	@Inject
	private QueryDao repository;
	
	@Override
	public List<Query> getAllQueries() {
		return repository.findAllQueries();
	}
	
	@Override
	public List<Query> getAllFavs(final String username) {
		return repository.findAllFavoriteQueries(username);
	}
	
	@Override
	public List<String> getBereicheList(final List<Query> queries) {
		final List<String> result = queries.stream().map(query -> query.getBereich()).distinct().sorted().collect(Collectors.toList());
		result.add("&lt;Bereich&gt;");
		Collections.sort(result);
		return result;
	}
	
	@Override
	public List<String> getErstelltList(final List<Query> queries) {
		final List<String> result = queries.stream().map(query -> DateTimeFormatter.ofPattern("dd.MM.yyyy").format(query.getErstellt())).distinct().collect(Collectors.toList()); 
		result.add("&lt;Erstell-Datum&gt;");
		Collections.sort(result);
		return result;
	}
	
	@Override
	public boolean removeQueryFromFav(final Long queryId, final String username) {
		if( repository.findAllFavIds(username).contains(queryId)) {
			repository.deleteQueryFromFavorites(queryId, username);
			return true;
		}
		return false;
	}
	
	@Override
	public boolean addRowToFav(final Long queryId, final String username) {
		// first check whether the query is already in the favs table
		if( ! repository.findAllFavIds(username).contains(queryId)) {
			repository.insertQueryToFav(queryId, username);
			return true;
		}
		return false;
	}

	@Override
	public Query getQueryById(final Long queryId) {
		return repository.findQueryById(queryId);
	}

	@Override
	public List<List<String>> executeQuery(String sql) {
		return repository.executeQuery(sql);
	}

	@Override
	public void insertInstance(Long queryId, String username, int dauer) {
		repository.insertInstance(queryId, username, dauer);
	}

	@Override
	public List<Long> getAllIds() {
		return repository.findAllIds();
	}

	@Override
	public void insertQuery(final Query query) {
		repository.insertQuery(query);
	}

	@Override
	public boolean updateQuery(Query query) {
		repository.updateQuery(query);
		return true;
	}

	@Override
	public List<Query> getAllQueriesForAdmin() {
		return repository.findAllQueriesForAdmin();
	}

	@Override
	public Query getQueryByIdForAdmin(Long queryId) {
		return repository.findQueryByIdForAdmin(queryId);
	}

}
