package de.gwvs.auswertungen.commons.security.permissions;

public class PermissionNotDefinedException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PermissionNotDefinedException(String msg) {
		super(msg);
	}
}
