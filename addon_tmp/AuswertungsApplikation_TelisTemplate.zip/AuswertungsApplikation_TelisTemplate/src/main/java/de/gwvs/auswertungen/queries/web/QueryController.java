package de.gwvs.auswertungen.queries.web;

import java.io.IOException;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import de.gwvs.auswertungen.commons.security.domain.AuswertungenUser;
import de.gwvs.auswertungen.queries.domain.Query;
import de.gwvs.auswertungen.queries.exceptions.ResourceNotFoundException;
import de.gwvs.auswertungen.queries.service.QueryService;

/**
 * Controller for the query view
 * @author prieger
 * @version 1.0
 */
@Controller
public class QueryController {
	
	/**
	 * query service
	 */
	private QueryService service;
	
	private List<Query> queries;
	private List<Query> favs;

	/**
	 * constructor
	 * @param service query service
	 */
	@Inject
	public QueryController(final QueryService service) {
		this.service = service;
	}
	
	/**
	 * Retrieves list of queries and favorites, filters domains and creation dates to
	 * display all required information for the query selection view
	 * @param model model object
	 * @param user user details
	 * @param response HTTP servlet response
	 * @return query JSP view name
	 * @throws IOException
	 */
	@RequestMapping(value = {"/", "/startseite"}, method = RequestMethod.GET)
	public String querySelection(final Model model, @AuthenticationPrincipal final AuswertungenUser user, final HttpServletResponse response) throws IOException {
		
		final String username = user.getUsername();
		
		// get all required information that is displayed in the view from the service
		queries = service.getAllQueries();
		favs = service.getAllFavs(username);
		List<String> bereicheList = service.getBereicheList(queries);
		List<String> erstelltList = service.getErstelltList(queries);
		
		// check if the retrieved information is as expected
		if(CollectionUtils.isEmpty(queries)) 
			throw new ResourceNotFoundException("Es konnten keine Auswertungen gefunden werden.");
		if(favs == null)  // may be empty
			throw new ResourceNotFoundException("Es konnten keine Favoriten aus der Datenbank bezogen werden.");
		if(CollectionUtils.isEmpty(bereicheList)) 
			throw new ResourceNotFoundException("Es konnten keine Bereiche im Filter extrahiert werden.");
		if(CollectionUtils.isEmpty(erstelltList))
			throw new ResourceNotFoundException("Es konnten keine Erstell-Daten im Filter extrahiert werden.");
		
		// display lists
		model.addAttribute("queryList", queries);
		model.addAttribute("favList", favs);
		// lists for filter
		model.addAttribute("bereicheList", bereicheList);
		model.addAttribute("erstelltList", erstelltList);
		
			
		return "queries";
	}
	
	/**
	 * Removes the query with given query ID from the favorite relation. 
	 * Invoked when the minus-button in the favorite list within the view is hit.
	 * @param queryId ID of the query that is to remove
	 * @param user user details
	 */
	@RequestMapping(value = "/removeQueryFromFav/{queryId}")
	public @ResponseBody boolean removeQueryFromFav(@PathVariable("queryId") Long queryId, @AuthenticationPrincipal final AuswertungenUser user) {
		return service.removeQueryFromFav(queryId, user.getUsername());
	}
	
	/**
	 * Adds the query with given query ID to the favorite relation.
	 * Invoked when the plus-button in the query list within the view is hit.
	 * @param queryId ID of the query that is to add
	 * @param user user details
	 * @return if the row was added successfully
	 */
	@RequestMapping(value = "/addQueryToFav/{queryId}")
	public @ResponseBody boolean addRowToFav(@PathVariable("queryId") Long queryId, @AuthenticationPrincipal final AuswertungenUser user) {
		
		// first check whether the queryId is permitted
		boolean isAllowed = false;
		for(Query query : queries) {
			if(query.getQueryId() == queryId) {
				isAllowed = true;
			}
		}
		
		if(isAllowed) {
			return service.addRowToFav(queryId, user.getUsername());
		} else {
			return false;
		}
		
	}
	
}