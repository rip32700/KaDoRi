package de.gwvs.auswertungen.queries.service.impl;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import de.gwvs.auswertungen.queries.domain.Parameter;
import de.gwvs.auswertungen.queries.domain.Query;
import de.gwvs.auswertungen.queries.exceptions.DuplicateIdException;
import de.gwvs.auswertungen.queries.service.AdminService;
import de.gwvs.auswertungen.queries.service.ParameterService;
import de.gwvs.auswertungen.queries.service.QueryService;

/**
 * admin service implementation
 * @author prieger
 * @version 1.0
 */
@Service
public class AdminServiceImpl implements AdminService {

	@Inject
	private QueryService queryService;
	
	@Inject
	private ParameterService parameterService;
	
	/**
	 * inserts a new query into the database if it is not contained yet
	 */
	@Override
	public void insertQuery(final Query query) throws DuplicateIdException {
		// first check for duplicate ID
		if(queryService.getAllIds().contains(query.getQueryId())) {
			throw new DuplicateIdException("Eine Auswertung mit dieser ID existiert bereits!");
		}
		queryService.insertQuery(query);
	}

	@Override
	public List<Long> getAllQueryIds() {
		return queryService.getAllIds();
	}

	@Override
	public Query getQuery(final Long queryId) {
		return queryService.getQueryByIdForAdmin(queryId);
	}

	@Override
	public List<Parameter> getAllParameters() {
		return parameterService.getAllParameters();
	}

	@Override
	public Parameter getParameterById(Long parameterId) {
		return parameterService.getParameterById(parameterId);
	}

	@Override
	public List<Query> getAllQueriesForAdmin() {
		return queryService.getAllQueriesForAdmin();
	}

	@Override
	public boolean updateQuery(Query query) {
		return queryService.updateQuery(query);
	}

	@Override
	public List<String> getBereicheList(List<Query> queries) {
		return queryService.getBereicheList(queries);
	}

	@Override
	public List<String> getErstelltList(List<Query> queries) {
		return queryService.getErstelltList(queries);
	}

	@Override
	public List<String> getTypeList(List<Parameter> parameters) {
		return parameterService.getTypeList(parameters);
	}

	@Override
	public boolean updateParameter(Parameter parameter) {
		return parameterService.updateParameter(parameter);
	}
	
	@Override
	public void insertParameter(final Parameter parameter) throws DuplicateIdException {
		// first check for duplicate ID
		if(parameterService.getAllIds().contains(parameter.getParameterId())) {
			throw new DuplicateIdException("Eine Auswertung mit dieser ID existiert bereits!");
		}
		parameterService.insertParameter(parameter);
	}
}
