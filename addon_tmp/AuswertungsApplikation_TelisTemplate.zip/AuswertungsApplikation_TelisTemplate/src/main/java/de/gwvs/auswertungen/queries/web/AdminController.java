package de.gwvs.auswertungen.queries.web;


import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.util.WebUtils;

import de.gwvs.auswertungen.commons.security.domain.AuswertungenUser;
import de.gwvs.auswertungen.queries.domain.Parameter;
import de.gwvs.auswertungen.queries.domain.Query;
import de.gwvs.auswertungen.queries.exceptions.DuplicateIdException;
import de.gwvs.auswertungen.queries.service.AdminService;
import de.gwvs.auswertungen.queries.web.validation.ParameterFormData;
import de.gwvs.auswertungen.queries.web.validation.QueryFormData;

/**
 * Controller for the ADMIN page to insert a new query
 * 
 * @author prieger
 * @version 1.0
 * 
 */
@Controller
public class AdminController {

	private static final String QUERY_COMMAND = "queryFormData";
	private static final String PARAMETER_COMMAND = "parameterFormData";
	
	@Inject
	private AdminService adminService;
	
	@Inject
	private Validator queryValidator;
	
	@Inject
	private Validator parameterValidator;
	
	/**
	 * Sets up the query form data object and prepares the admin page to be displayed
	 * @param model model object
	 * @param request HTTP Servlet request
	 * @return view name of the ADMIN page
	 */
	@RequestMapping(value="/admin/new_query", method = RequestMethod.GET)
	public String newQuery(final Model model, final HttpServletRequest request) {
		QueryFormData formData = new QueryFormData();

		// fill form data object with data that was already entered if it wasn't submitted correctly yet
		if(WebUtils.getSessionAttribute(request, QUERY_COMMAND) != null) {
			formData = (QueryFormData) WebUtils.getSessionAttribute(request, QUERY_COMMAND);
		}
		model.addAttribute(QUERY_COMMAND, formData);

		return "query_new";
	}
	
	/**
	 * Validates the entered input for a new query and redirects to the home page
	 * if the validation succeeded 
	 * @param formData query form data object
	 * @param bindingResult binding result object for validation
	 * @param model model object
	 * @param user user details
	 * @param request HTTP Servlet request
	 * @return view name depending on validation
	 * @throws DuplicateIdException if a new query with an already exisiting ID was inserted
	 */
	@RequestMapping(value="/admin/new_query", method = RequestMethod.POST)
	public String newQuery(@ModelAttribute(QUERY_COMMAND) final QueryFormData formData, final BindingResult bindingResult, @AuthenticationPrincipal final AuswertungenUser user, final HttpServletRequest request) throws DuplicateIdException {
		formData.setErstellt(LocalDate.now().format(DateTimeFormatter.ofPattern("dd.MM.yyyy")));
		
		queryValidator.validate(formData, bindingResult);

		// no errors -> process the insertions and delete form data object from session
		if(!bindingResult.hasErrors()) {
			Query query = getQueryFromFormDataObject(formData);
			adminService.insertQuery(query);
			WebUtils.setSessionAttribute(request, QUERY_COMMAND, null);
			return "redirect:/admin/query_edit";
		}
		
		// there were errors -> set form data object into session to be displayed again,
		// so that the user doesn't have to enter everything again
		// WebUtils.setSessionAttribute(request, COMMAND, formData);
		
		return "query_new";
	}
	
	/**
	 * shows a list with all queries where one of them can be chosen to edit
	 *
	 */
	@RequestMapping(value="/admin/edit_query", method = RequestMethod.GET)
	public String editQuery(final Model model) {
		List<Query> queries = adminService.getAllQueriesForAdmin();
		List<String> bereicheList = adminService.getBereicheList(queries);
		List<String> erstelltList = adminService.getErstelltList(queries);
		model.addAttribute("queryList", queries);
		model.addAttribute("bereicheList", bereicheList);
		model.addAttribute("erstelltList", erstelltList);
		
		return "query_admin_all";
	}
	
	/**
	 * query edit mask for a chosen query 
	 *
	 * @param queryId
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/admin/edit_query/{queryId}", method = RequestMethod.GET)
	public String editQuery(@PathVariable("queryId") final Long queryId, final Model model, final HttpServletRequest request) {
		QueryFormData formData = getFormDataObjectFromQuery(adminService.getQuery(queryId));
		model.addAttribute(QUERY_COMMAND, formData);
		return "query_edit";
	}
	
	

	/**
	 * update query with new information
	 *
	 * @param queryId
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/admin/edit_query/{queryId}", method = RequestMethod.POST)
	public String editQuery(@ModelAttribute(QUERY_COMMAND) final QueryFormData formData, final BindingResult bindingResult, @AuthenticationPrincipal final AuswertungenUser user, @PathVariable("queryId") final Long queryId, final Model model,  final HttpServletRequest request) {
		//adjust date format
		adjustDateFormat(formData);
		
		queryValidator.validate(formData, bindingResult);

		// no errors -> process the insertions and delete form data object from session
		if(!bindingResult.hasErrors()) {
			Query query = getQueryFromFormDataObject(formData);
			adminService.updateQuery(query);
			return "query_edit_success";
		}
		
		// there were errors 
		return "query_edit";
		
	}
	
	private void adjustDateFormat(final QueryFormData formData) {
		String[] tokens = formData.getErstellt().split("-");
		String erstellt = tokens[2] + "." + tokens[1] + "." + tokens[0];
		formData.setErstellt(erstellt);
	}
	
	@RequestMapping(value="/admin/new_parameter", method = RequestMethod.GET)
	public String newParameter(final Model model, final HttpServletRequest request) {
		ParameterFormData formData = new ParameterFormData();

		// fill form data object with data that was already entered if it wasn't submitted correctly yet
		if(WebUtils.getSessionAttribute(request, PARAMETER_COMMAND) != null) {
			formData = (ParameterFormData) WebUtils.getSessionAttribute(request, PARAMETER_COMMAND);
		}
		
		model.addAttribute(PARAMETER_COMMAND, formData);

		return "parameter_new";
	}
	
	@RequestMapping(value="/admin/new_parameter", method = RequestMethod.POST)
	public String newParameter(@ModelAttribute(PARAMETER_COMMAND) final ParameterFormData formData, final BindingResult bindingResult, @AuthenticationPrincipal final AuswertungenUser user, final HttpServletRequest request) throws DuplicateIdException {
		
		parameterValidator.validate(formData, bindingResult);

		// no errors -> process the insertions and delete form data object from session
		if(!bindingResult.hasErrors()) {
			Parameter parameter = getParameterFromFormDataObject(formData);
			adminService.insertParameter(parameter);
			WebUtils.setSessionAttribute(request, PARAMETER_COMMAND, null);
			return "redirect:/admin/edit_parameter";
		}
		
		return "parameter_new";
	}
	
	
	/**
	 * shows a list of all parameters where one can be chosen to edit
	 *
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/admin/edit_parameter", method = RequestMethod.GET)
	public String editParameter(final Model model) {
		List<Parameter> parameters = adminService.getAllParameters();
		List<String> types = adminService.getTypeList(parameters);
		model.addAttribute("parameterList", parameters);
		model.addAttribute("typeList", types);
		return "parameter_admin_all";
	}
	
	/**
	 * parameter edit mask for a chosen query
	 *
	 * @param parameterId
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/admin/edit_parameter/{parameterId}", method = RequestMethod.GET)
	public String editParameter(@PathVariable("parameterId") final Long parameterId, final Model model) {
		ParameterFormData formData = getFormDataObjectFromParameter(adminService.getParameterById(parameterId));
		model.addAttribute(PARAMETER_COMMAND, formData);
		return "parameter_edit";
	}
	
	/**
	 * update parameter with new information, then show list of all parameters again
	 *
	 * @param bindingResult
	 * @param queryId
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/admin/edit_parameter/{parameterId}", method = RequestMethod.POST)
	public String editParameter(final ParameterFormData formData, final BindingResult bindingResult, @PathVariable("parameterId") final Long queryId, final Model model) {
		parameterValidator.validate(formData, bindingResult);

		// no errors -> process the insertions and delete form data object from session
		if(!bindingResult.hasErrors()) {
			Parameter parameter = getParameterFromFormDataObject(formData);
			adminService.updateParameter(parameter);
			return "parameter_edit_success";
		}
		
		// there were errors 
		return "parameter_edit";
	}
	

	/**
	 * Transforms the query form data object into original query
	 * @param formData query form data object
	 * @return original query
	 */
	private Query getQueryFromFormDataObject(final QueryFormData formData) {
		final Query query = new Query();
		query.setQueryId(NumberUtils.toLong(formData.getQueryId())); 
		query.setArt(formData.getArt());
		query.setBereich(formData.getBereich());
		query.setBeschreibung(formData.getBeschreibung());
		query.setErstellt(LocalDate.parse(formData.getErstellt(), DateTimeFormatter.ofPattern("dd.MM.yyyy")));
		query.setSql(sanitizeSql(formData.getSql()));
		query.setText(formData.getText());
		query.setAuthority(formData.getAuthority());
		query.setDisabled(formData.isDisabled());
		return query;
	}
	
	/**
	 *
	 * @param query
	 * @return
	 */
	private QueryFormData getFormDataObjectFromQuery(final Query query) {
		final QueryFormData formData = new QueryFormData();
		formData.setQueryId(query.getQueryId().toString());
		formData.setArt(query.getArt());
		formData.setBereich(query.getBereich());
		formData.setBeschreibung(query.getBeschreibung());
		formData.setErstellt(query.getErstellt().toString());
		formData.setSql(query.getSql());
		formData.setText(query.getText());
		formData.setAuthority(query.getAuthority());
		formData.setDisabled(query.isDisabled());
		return formData;
	}
	
	/**
	 *
	 * @param formData
	 * @return
	 */
	private Parameter getParameterFromFormDataObject(final ParameterFormData formData) {
		final Parameter parameter = new Parameter();
		parameter.setParameterId(NumberUtils.toLong(formData.getParameterId()));
		parameter.setParameterName(formData.getParameterName());
		parameter.setType(formData.getType());
		parameter.setParameterLabel(formData.getParameterLabel());
		parameter.setErklaerung(formData.getErklaerung());
		parameter.setStandardwert(formData.getStandardwert());
		//parameter.setListboxInhalt(formData.getListboxInhalt());
		parameter.setRegexMaske(formData.getRegexMaske());
		parameter.setPflichtfeld(formData.isPflichtfeld());
		parameter.setFehlertext(formData.getFehlertext());
		return parameter;
	}
	
	private ParameterFormData getFormDataObjectFromParameter(Parameter parameter) {
		final ParameterFormData formData = new ParameterFormData();
		formData.setParameterId(parameter.getParameterId().toString());
		formData.setParameterName(parameter.getParameterName());
		formData.setType(parameter.getType());
		formData.setParameterLabel(parameter.getParameterLabel());
		formData.setErklaerung(parameter.getErklaerung());
		formData.setStandardwert(parameter.getStandardwert());
		//formData.setListboxInhalt(parameter.getListboxInhalt());
		formData.setRegexMaske(parameter.getRegexMaske());
		formData.setPflichtfeld(parameter.isPflichtfeld());
		formData.setFehlertext(parameter.getFehlertext());
		return formData;
	}

	
	/**
	 * Adapts the SQL statement to the expected format
	 * @param sql SQL statement
	 * @return sanitized SQL statement
	 */
	private String sanitizeSql(String sql) {
		// cut trailing ; if appended
		if(sql.endsWith(";")) {
			sql = sql.substring(0, sql.length() - 2);
		}
		return sql;
	}

}
