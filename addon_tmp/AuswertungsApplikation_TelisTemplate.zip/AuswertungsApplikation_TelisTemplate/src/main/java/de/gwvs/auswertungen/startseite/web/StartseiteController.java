/*
 * Copyright (C) 2015 GWVS mbH - All rights reserved.
 */
package de.gwvs.auswertungen.startseite.web;

import javax.servlet.http.HttpServletRequest;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import de.gwvs.auswertungen.commons.security.domain.AuswertungenUser;

/**
 * Controller für die Anzeige der Startseite
 * 
 * @author Krammer Ronny
 * 
 */
@Controller
public class StartseiteController {

	/**
	 * GET für /startseite
	 * 
	 * @param dikoUser {@link AuswertungenUser}
	 * @param request {@link HttpServletRequest}
	 * @param model {@link Model}
	 * @return Name der View
	 */
	//@RequestMapping(value = { "/startseite" }, method = RequestMethod.GET)
	public String startseite(@AuthenticationPrincipal AuswertungenUser user, HttpServletRequest request, Model model) {
		return "startseite";
	}
	
}
