package de.gwvs.auswertungen.queries.service;

import java.util.List;

/**
 * interface for processing service
 * @author prieger
 * @version 1.0
 */
public interface ProcessingService {
	
	public List<List<String>> startAsync(final Long queryId, final String username);
	public String getQueryTitle(final Long queryId);
	public void registerQuery(final Long queryId, final String sql);
	
}
