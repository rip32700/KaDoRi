package de.gwvs.auswertungen.queries.service.impl;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import de.gwvs.auswertungen.queries.service.ProcessingService;
import de.gwvs.auswertungen.queries.service.QueryService;
import de.gwvs.auswertungen.queries.web.HTTPErrorHandler;

/**
 * processing service implementation
 * @author prieger
 * @version 1.0
 */
@Service
public class ProcessingServiceImpl implements ProcessingService {

	@Inject 
	private QueryService queryService;
	
	final static Logger logger = LoggerFactory.getLogger(HTTPErrorHandler.class);
	
	/**
	 * map is used to correlate queryIds to sql statements, so that
	 * multiple queries can be executed simultaneously while the controller
	 * can be determine which one to execute by the URL parameter
	 */
	private ConcurrentMap<Long, String> awidToSqlMap = new ConcurrentHashMap<>();
	
	/**
	 * starts the SQL statement of a query given by the query ID asynchronously
	 * the SQL statement (resolved) is stored in the local map
	 */
	@Override
	public List<List<String>> startAsync(final Long queryId, final String username) {
        CompletableFuture<List<List<String>>> result = CompletableFuture.supplyAsync(() -> {
        	/* for simulated delay: try { Thread.sleep(5000); } catch (Exception e) {} */
        	// execute the final SQL statement and send result to view
        	return queryService.executeQuery(awidToSqlMap.get(queryId));
		});
        
        // add instance record into table to keep track
        queryService.insertInstance(queryId, username, -1);
        
        // IMPORTANT: timeout value
		try {
			return result.get(60, TimeUnit.MINUTES);
		} catch (InterruptedException | ExecutionException | TimeoutException e) {
			logger.error(e.getMessage());
			return null;
		}
	}
	
	/**
	 * gets the query title for a given query ID
	 */
	@Override
	public String getQueryTitle(final Long queryId) {
		return queryService.getQueryById(queryId).getText();
	}

	/**
	 * registers a resolved SQL statement for a given query ID
	 * (puts it into the local map for later asynchronous use)
	 */
	@Override
	public void registerQuery(Long queryId, String sql) {
		awidToSqlMap.put(queryId, sql);
	}
}
