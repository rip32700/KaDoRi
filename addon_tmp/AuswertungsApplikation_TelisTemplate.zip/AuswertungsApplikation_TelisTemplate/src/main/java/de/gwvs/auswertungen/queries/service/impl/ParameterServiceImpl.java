package de.gwvs.auswertungen.queries.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import de.gwvs.auswertungen.queries.dao.ParameterDao;
import de.gwvs.auswertungen.queries.domain.BoundParameter;
import de.gwvs.auswertungen.queries.domain.Parameter;
import de.gwvs.auswertungen.queries.domain.Query;
import de.gwvs.auswertungen.queries.service.ParameterService;
import de.gwvs.auswertungen.queries.service.QueryService;
import de.gwvs.auswertungen.queries.utils.ParameterUtils;

/**
 * parameter service implementation
 * @author prieger
 * @version 1.0
 */
@Service
public class ParameterServiceImpl implements ParameterService {

	@Inject
	private ParameterDao parameterRepository;
	
	@Inject
	private QueryService queryService;
	
	/**
	 * resolves an SQL statement by resolving all bound variables with given values
	 */
	@Override
	public Query resolveSqlStatement(final Long queryId, final List<BoundParameter> boundParas) {
		Query query = queryService.getQueryById(queryId); 
		String resolvedSql = ParameterUtils.resolvePreparedStatement(query.getSql(), boundParas);
		query.setSql(resolvedSql);
		return query;
	}

	/**
	 * return all bound variables of a query given by the query ID and username
	 * 
	 * extracts all bound variables of the form ":varName"
	 * of a SQL statement into a List (containing resolved 
	 * name and type of the variable)
	 * @param stmt
	 * @param repository
	 * @return
	 */
	@Override
	public List<Parameter> getParametersOfAQuery(Long queryId) {
		final Query query = queryService.getQueryById(queryId);
		String stmt = query.getSql();
		
		List<String> parametersNames = Arrays.asList(stmt.split(" "));
		
		parametersNames = parametersNames.stream()
							 .filter(s -> s.startsWith(":"))
							 .map(s -> s.substring(1).trim())
							 .map(s -> s.endsWith(";") ? s.substring(0, s.length() - 1) : s)
							 .distinct()
							 .collect(Collectors.toList());
		
		List<Parameter> parameters = new ArrayList<>();
		for(String name : parametersNames) {
			parameters.add(parameterRepository.findParameterByName(name));
		}
		
		return parameters;
	}

	@Override
	public Parameter getParameterById(Long parameterId) {
		return parameterRepository.findParameterById(parameterId);
	}

	@Override
	public List<Parameter> getAllParameters() {
		return parameterRepository.findAllParameters();
	}

	@Override
	public List<String> getTypeList(List<Parameter> parameters) {
		final List<String> result = parameters.stream().map(parameter -> parameter.getType()).distinct().sorted().collect(Collectors.toList());
		result.add("&lt;Typen&gt;");
		Collections.sort(result);
		return result;
	}

	@Override
	public boolean updateParameter(Parameter parameter) {
		return parameterRepository.updateParameter(parameter);
	}

	@Override
	public List<Long> getAllIds() {
		return parameterRepository.findAllIds();
	}

	@Override
	public void insertParameter(Parameter parameter) {
		parameterRepository.insertParameter(parameter);
		
	}

}