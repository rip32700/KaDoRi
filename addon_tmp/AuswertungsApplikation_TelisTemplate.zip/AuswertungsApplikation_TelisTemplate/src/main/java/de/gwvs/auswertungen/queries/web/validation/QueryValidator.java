package de.gwvs.auswertungen.queries.web.validation;

import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

/**
 * Validator for a query
 * @author prieger
 * @version 1.0
 */
public class QueryValidator implements Validator {

	@Override
	public boolean supports(final Class<?> clazz) {
		return clazz.equals(QueryFormData.class);
	}

	@Override
	public void validate(final Object target, final Errors errors) {
		QueryFormData formData = (QueryFormData) target;
		
		// validation
		if(!StringUtils.hasText(formData.getQueryId()) || !StringUtils.hasText(formData.getArt())
				|| !StringUtils.hasText(formData.getErstellt()) || !StringUtils.hasText(formData.getBereich()) || !StringUtils.hasText(formData.getSql()) 
				|| !StringUtils.hasText(formData.getText()) || !StringUtils.hasText(formData.getBeschreibung()) || !StringUtils.hasText(formData.getAuthority()) ) {
			errors.reject("", null, "Bitte füllen Sie alle Felder aus!");
		} else {
			ValidatorUtils.rejectIfNotValidLong(errors, formData.getQueryId(), "queryId", "invalid.queryId", "Die Auswertungs ID muss eine Zahl sein!", 1L, 99999999L, "invalid.queryId.range", "Auswertungs ID: Keine gültige Auswertungs ID!");
			ValidatorUtils.rejectIfStringNotInRange(errors, formData.getArt(), "art", "invalid.art", "Art: Keine gültige Auswertungsart!", 5, 30);
			ValidatorUtils.rejectIfStringNotInRange(errors, formData.getBereich(), "bereich", "invalid.bereich", "Bereich: Kein gültiger Auswertungsbereich!", 5, 30);
			ValidatorUtils.rejectIfNotValidDate(errors, formData.getErstellt(), "erstellt", "invalid.erstellt", "Erstellt: Kein gültiges Erstellungs-Datum!");
			ValidatorUtils.rejectIfStringNotInRange(errors, formData.getText(), "text", "invalid.text", "Text: Kein gültige Auswertungstext!", 5, 200);
			ValidatorUtils.rejectIfStringNotInRange(errors, formData.getSql(), "sql", "invalid.sql", "Sql: Keine gültige SQL-Query!", 10, 10000);
			ValidatorUtils.rejectIfStringNotInRange(errors, formData.getAuthority(), "authority", "invalid.authority", "Authority: Keine gültige Authority!", 2, 100);
			ValidatorUtils.rejectIfStringNotInRange(errors, formData.getBeschreibung(), "beschreibung", "invalid.beschreibung", "Beschreibung: Keine gültige Beschreibung!", 5, 300);
		}
	}

}
