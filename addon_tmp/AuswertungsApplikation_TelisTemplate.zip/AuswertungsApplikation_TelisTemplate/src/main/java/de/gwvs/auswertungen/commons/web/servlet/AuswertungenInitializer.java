/*
 * Copyright (C) 2015 GWVS mbH - All rights reserved.
 */
package de.gwvs.auswertungen.commons.web.servlet;

import java.util.EnumSet;

import javax.servlet.FilterRegistration;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.SessionTrackingMode;

import org.springframework.core.annotation.Order;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.CharacterEncodingFilter;
import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;
import org.springframework.web.util.IntrospectorCleanupListener;

import ch.qos.logback.ext.spring.web.LogbackConfigListener;
import de.gwvs.auswertungen.commons.web.config.RootConfig;

/**
 * Implements an {@link AbstractAnnotationConfigDispatcherServletInitializer}
 * 
 * @author Ronny Krammer
 * @version 1.0
 * 
 */
@Order(1)
public class AuswertungenInitializer extends AbstractAnnotationConfigDispatcherServletInitializer {

	/**
	 * The default servlet name.
	 */
	public static final String DEFAULT_SERVLET_NAME = "auswertungen";

	/**
	 * Root Key
	 */
	public static final String WEBAPP_ROOT_KEY = "auswertungen.root";

	/* (non-Javadoc)
	 * @see org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer#getRootConfigClasses()
	 */
	@Override
	protected Class<?>[] getRootConfigClasses() {
		return new Class<?>[] { RootConfig.class };
	}

	/* (non-Javadoc)
	 * @see org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer#getServletConfigClasses()
	 */
	@Override
	protected Class<?>[] getServletConfigClasses() {
		// Wegen der GlobalMethodSecurity wird alles im Root importiert
		return null;
	}

	/* (non-Javadoc)
	 * @see org.springframework.web.servlet.support.AbstractDispatcherServletInitializer#getServletMappings()
	 */
	@Override
	protected String[] getServletMappings() {
		return new String[] { "/" };
	}

	/* (non-Javadoc)
	 * @see org.springframework.web.servlet.support.AbstractDispatcherServletInitializer#getServletName()
	 */
	@Override
	protected String getServletName() {
		return DEFAULT_SERVLET_NAME;
	}

	/* (non-Javadoc)
	 * @see org.springframework.web.servlet.support.AbstractDispatcherServletInitializer#isAsyncSupported()
	 */
	@Override
	protected boolean isAsyncSupported() {
		return false;
	}

	/* (non-Javadoc)
	 * @see org.springframework.web.servlet.support.AbstractDispatcherServletInitializer#onStartup(javax.servlet.ServletContext)
	 */
	@Override
	public void onStartup(ServletContext servletContext) throws ServletException {
		super.onStartup(servletContext);
		servletContext.addListener(new IntrospectorCleanupListener());
		servletContext.addListener(new LogbackConfigListener());
		servletContext.setInitParameter("webAppRootKey", WEBAPP_ROOT_KEY);
		servletContext.setSessionTrackingModes(EnumSet.of(SessionTrackingMode.COOKIE));
		servletContext.getSessionCookieConfig().setHttpOnly(true);
		String profile = System.getProperty("spring.profiles.active");
		if(StringUtils.hasText(profile)) {
			if("PROD".equals(profile)) {
				servletContext.getSessionCookieConfig().setSecure(true);
			}
			servletContext.setInitParameter("logbackConfigLocation", "classpath:logback-" + profile +".xml");
		}
		
		FilterRegistration.Dynamic encodingFilter = servletContext.addFilter("encodingfilter", new CharacterEncodingFilter());
		encodingFilter.setInitParameter("encoding", "UTF-8");
		encodingFilter.setInitParameter("forceEncoding", "true");
		encodingFilter.addMappingForUrlPatterns(null, false, "/*");
	}

}
