package de.gwvs.auswertungen.queries.domain;

public class BoundParameter {

	private Parameter parameter;
	private String value;
	
	public BoundParameter() {
	
	}
	
	public BoundParameter(Parameter parameter, String value) {
		super();
		this.parameter = parameter;
		this.value = value;
	}

	public Parameter getParameter() {
		return parameter;
	}

	public void setParameter(Parameter parameter) {
		this.parameter = parameter;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
}
