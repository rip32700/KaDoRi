package de.gwvs.auswertungen.queries.web.validation;

import java.io.Serializable;
import java.util.List;

import de.gwvs.auswertungen.queries.domain.BoundParameter;

/**
 * form data object for parameter insertion
 * @author prieger
 * @version 1.0
 */
public class BoundParameterFormData implements Serializable {

	private static final long serialVersionUID = -2720881679062422538L;

	private Long queryId;
	private List<BoundParameter> boundVariables;
	
	/**
	 * empty constructor
	 */
	public BoundParameterFormData() {
	}

	/**
	 * constructor
	 * @param queryId
	 * @param boundVariables
	 */
	public BoundParameterFormData(final Long queryId, final List<BoundParameter> boundVariables) {
		this.boundVariables = boundVariables;
		this.queryId = queryId;
	}

	/**
	 * returns all bound variables (list)
	 * @return
	 */
	public List<BoundParameter> getBoundVariables() {
		return boundVariables;
	}

	/**
	 * sets all bound variables (list)
	 * @param boundVariables
	 */
	public void setBoundVariables(List<BoundParameter> boundVariables) {
		this.boundVariables = boundVariables;
	}
	
	/**
	 * returns the query ID
	 * @return
	 */
	public Long getQueryId() {
		return queryId;
	}

	/**
	 * sets the query ID
	 * @param queryId
	 */
	public void setQueryId(Long queryId) {
		this.queryId = queryId;
	}

	/**
	 * prints the object
	 */
	@Override
	public String toString() {
		return "ParameterFormData [queryId=" + queryId + ", boundVariables=" + boundVariables + "]";
	}
}
