package de.gwvs.auswertungen.queries.utils;

import java.util.List;

import de.gwvs.auswertungen.queries.domain.BoundParameter;

/**
 * bound variable utils class
 * @author prieger
 * @version 1.0
 */
public final class ParameterUtils {
	
	private ParameterUtils() { }

	/**
	 * resolve the bound variables in a given SQL
	 * statement with the correct value
	 * @param sql
	 * @param boundParas
	 * @return
	 */
	public static String resolvePreparedStatement(String sql, final List<BoundParameter> boundParas) {
		if(boundParas != null && !boundParas.isEmpty()) {
			for(BoundParameter para : boundParas) {
				if("Text".equals(para.getParameter().getType()) || "Werteliste".equals(para.getParameter().getType())) {
					sql = sql.replace(":" + para.getParameter().getParameterName(), "'" + para.getValue() + "'");
				} else if("Zahl".equals(para.getParameter().getType())) {
					sql = sql.replace(":" + para.getParameter().getParameterName(), "" + para.getValue() + "");
				}
			}
		}
		return sql;
	}
	
}
