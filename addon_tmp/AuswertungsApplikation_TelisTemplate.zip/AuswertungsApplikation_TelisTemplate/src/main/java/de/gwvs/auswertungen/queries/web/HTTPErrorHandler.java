package de.gwvs.auswertungen.queries.web;

import java.io.IOException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.BadSqlGrammarException;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import de.gwvs.auswertungen.queries.exceptions.DuplicateIdException;
import de.gwvs.auswertungen.queries.exceptions.ResourceNotFoundException;


/**
 * Controller for Handling Exceptions
 * 
 * @author prieger
 * @version 1.0
 * 
 */
@ControllerAdvice
public class HTTPErrorHandler {

	final static Logger logger = LoggerFactory.getLogger(HTTPErrorHandler.class);
	
	/**
	 * handels all ResourceNotFoundException exceptions
	 * @param model
	 * @param exception
	 * @return
	 */
	@ExceptionHandler(ResourceNotFoundException.class)
	public String handleResourceNotFoundException(final Model model, final Exception exception) {
		model.addAttribute("errorMsg", exception.getMessage());
		logger.error(exception.getLocalizedMessage(), exception);
		return "error-handler";
	}
	
	/**
	 * handels all DuplicateIdException exceptions
	 * @param model
	 * @param exception
	 * @return
	 */
	@ExceptionHandler(DuplicateIdException.class)
	public String handleDuplicateIdException(final Model model, final Exception exception) {
		model.addAttribute("errorMsg", exception.getMessage());
		logger.error(exception.getLocalizedMessage(), exception);
		return "error-handler";
	}
	
	/**
	 * handels all BadGrammarException exceptions
	 * @param model
	 * @param exception
	 * @return
	 */
	@ExceptionHandler(BadSqlGrammarException.class)
	public String handleBadSQLException(final Model model, final Exception exception) {
		model.addAttribute("errorMsg", exception.getMessage());
		logger.error(exception.getLocalizedMessage(), exception);
		return "error-handler";
	}
	
	/**
	 * handels all IOException exceptions
	 * @param model
	 * @param exception
	 * @return
	 */
	@ExceptionHandler(IOException.class)
	public String handleIOException(final Model model, final Exception exception) {
		model.addAttribute("errorMsg", exception.getMessage());
		logger.error(exception.getLocalizedMessage(), exception);
		return "error-handler";
	}
	
	
	@ExceptionHandler({InterruptedException.class, ExecutionException.class, TimeoutException.class})
	public String handleAsyncExceptions(final Model model, final Exception exception) {
		model.addAttribute("errorMsg", exception.getMessage());
		logger.error(exception.getLocalizedMessage(), exception);
		return "error-handler";
	}
}
