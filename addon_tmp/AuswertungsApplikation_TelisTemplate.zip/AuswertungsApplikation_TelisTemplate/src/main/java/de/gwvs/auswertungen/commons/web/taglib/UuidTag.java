/*
 * Copyright (C) 2008 GWVS mbH - All rights reserved.
 */
package de.gwvs.auswertungen.commons.web.taglib;

import java.io.IOException;
import java.util.UUID;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import org.springframework.web.util.TagUtils;

/**
 * Ein JSP Tag zum Setzen einer UUID
 * 
 * @author Krammer Ronny
 * 
 */
public class UuidTag extends SimpleTagSupport {

	/**
	 * Variablennamen, in welche der Wert gespeichert wird
	 */
	private String var;

	/**
	 * Scope, in dem die Variable verfügbar sein soll
	 */
	private int scope = PageContext.PAGE_SCOPE;

	/**
	 * Set PageContext attribute name under which to expose a variable that contains the result of the transformation.
	 * 
	 * @see #setScope
	 * @see javax.servlet.jsp.PageContext#setAttribute
	 */
	public void setVar(String var) {
		this.var = var;
	}

	/**
	 * Set the scope to export the variable to. Default is SCOPE_PAGE ("page").
	 * 
	 * @see #setVar
	 * @see org.springframework.web.util.TagUtils#SCOPE_PAGE
	 * @see javax.servlet.jsp.PageContext#setAttribute
	 */
	public void setScope(String scope) {
		this.scope = TagUtils.getScope(scope);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.jsp.tagext.SimpleTagSupport#doTag()
	 */
	@Override
	public void doTag() throws JspException, IOException {
		UUID uuid = java.util.UUID.randomUUID();
		getJspContext().setAttribute(var, uuid, scope);
	}
}
