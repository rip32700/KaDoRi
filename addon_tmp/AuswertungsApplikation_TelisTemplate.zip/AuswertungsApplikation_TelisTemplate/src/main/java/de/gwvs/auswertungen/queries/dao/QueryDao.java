package de.gwvs.auswertungen.queries.dao;

import java.util.List;

import de.gwvs.auswertungen.queries.domain.Query;

/**
 * Interface for the query data access object
 * @author prieger
 * @version 1.0
 */
public interface QueryDao {

	/**
	 * Queries all available queries for given user name
	 * @param username user name for the queries
	 * @return list of found queries
	 */
	List<Query> findAllQueries();
	
	List<Query> findAllQueriesForAdmin();
	
	/**
	 * Retrieves one query with given ID and user name
	 * @param queryId ID of the query 
	 * @param username user name for the query
	 * @return found query object
	 */
	Query findQueryById(final long queryId);
	
	Query findQueryByIdForAdmin(final long queryId);
	
	/**
	 * Retrieves all query IDs in the database
	 * @return list of all found query IDs
	 */
	List<Long> findAllIds();
	
	/**
	 * Retrieves all favorite queries user name
	 * @param username user name for the queries
	 * @return list of found queries
	 */
	List<Query> findAllFavoriteQueries(final String username);
	
	/**
	 * Queries all favorite query IDs  for a given user name
	 * @param username user name for the queries
	 * @return list of all found query IDs
	 */
	List<Long> findAllFavIds(final String username);
	
	/**
	 * Inserts a given query into the database 
	 * @param query the query object that is to insert
	 */
	void insertQuery(final Query query);
	
	/**
	 * Inserts a query from the query relation into the favorite relation
	 * by its given ID
	 * @param queryId ID of the query
	 * @param username user name 
	 */
	void insertQueryToFav(final long queryId, final String username);
	
	/**
	 * Inserts a new instance into the instance relation. Represents that
	 * a query was executed
	 * @param queryId ID of the query that was launched
	 * @param username user name
	 * @param dauer duration of execution
	 */
	void insertInstance(final long queryId, final String username, final long dauer);
	
	/**
	 * Deletes a query with given ID from the favorite relation
	 * @param queryId ID of query
	 * @param username user name 
	 */
	void deleteQueryFromFavorites(final Long queryId, final String username);
	
	/**
	 * Executes the given SQL statement and returns the results
	 * @param sql SQL statement that is to be executed
	 * @return list of list of strings: 1st inner list represents the column names,
	 * 									2nd inner list represents the rows
	 */
	List<List<String>> executeQuery(final String sql);

	void updateQuery(Query query);
}
