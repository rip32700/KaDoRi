/*
 * Copyright (C) 2010 GWVS mbH - All rights reserved.
 */
package de.gwvs.auswertungen.commons.web.controller;

import java.io.IOException;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * Controller für den Login, Logout usw.
 * 
 * @author Ronny Krammer
 * @version 1.0
 * 
 */
@Controller
public class CommonsController {

	/**
	 * Versionsnummer
	 */
	private String version = "";

	/**
	 * Verarbeitet einen HTTP 401 Seitenfehler
	 * 
	 * @param model {@link Model}
	 * @return Viewname
	 * @throws Exception Exception
	 */
	@RequestMapping({ "/accessdenied", "/error/accessdenied" })
	public String accessdenied(Model model) throws Exception {
		model.addAttribute("title", "HTTP Status 401 Access Denied");
		return "common/accessDenied";
	}
	
	/**
	 * Verarbeitet einen HTTP 403 Seitenfehler
	 * 
	 * @param model {@link Model}
	 * @return Viewname
	 * @throws Exception Exception
	 */
	@RequestMapping("/error/forbidden")
	public String forbidden(Model model) throws Exception {
		model.addAttribute("title", "HTTP Status 403 Forbidden");
		return "common/accessDenied";
	}

	/**
	 * Verarbeitet einen HTTP 404 Seitenfehler
	 * 
	 * @param request {@link HttpServletRequest}
	 * @param response {@link HttpServletResponse}
	 * @param model {@link Model}
	 * @return Viewname
	 * @throws Exception Exception
	 */
	@RequestMapping("/error/notfound")
	public String notfound(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {
		model.addAttribute("title", "HTTP Status 404 Not Found");
		model.addAttribute("caption", "HTTP Status 404");
		model.addAttribute("description", "Die gewünschte Seite wurde nicht gefunden.<br/><br/><strong>Gehen Sie bitte weiter auf die <a href=\"" + request.getContextPath() + response.encodeURL("/startseite")
				+ "\">Startseite</a>.</strong>");

		return "common/error";
	}

	/**
	 * {@link RequestMapping} für /status
	 * 
	 * @return String OK
	 */
	@RequestMapping(value = "/status", produces = "text/plain")
	@ResponseBody
	public String status() {
		return "OK";
	}

	/**
	 * Liefert die Version der Anwendung zurück
	 * 
	 * @param request {@link HttpServletRequest}
	 * @return Version der Anwendung
	 * @throws IOException IOException
	 */
	@RequestMapping("/version")
	public ResponseEntity<String> version(HttpServletRequest request) throws IOException {
		if (!StringUtils.hasText(version)) {
			ServletContext servletContext = request.getSession().getServletContext();
			Properties prop = new Properties();
			prop.load(servletContext.getResourceAsStream("/META-INF/MANIFEST.MF"));
			String build = prop.getProperty("Implementation-Build", "");
			String buildDate = prop.getProperty("Implementation-Build-Date", "");
			version = build;
			if (StringUtils.hasText(buildDate)) {
				version += " - " + buildDate;
			}
		}
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.TEXT_PLAIN);
		return new ResponseEntity<String>(version, headers, HttpStatus.OK);
	}
}
