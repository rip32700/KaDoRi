package de.gwvs.auswertungen.queries.domain;

import java.util.List;

/**
 * domain object for a bound variable
 * @author prieger
 * @version 1.0
 */
public class BoundVariable {

	private String name;
	private String bezeichnung;
	private String value;
	private String type;
	private List<String> defaultValues;
	
	/**
	 * empty constructor
	 */
	public BoundVariable() {
	}

	/**
	 * constructor
	 * @param name
	 * @param bezeichnung
	 * @param value
	 * @param type
	 */
	public BoundVariable(String name, String bezeichnung, String value, String type, List<String> defaultValues) {
		this.name = name;
		this.bezeichnung = bezeichnung;
		this.value = value;
		this.type = type;
		this.defaultValues = defaultValues;
	}
	
	/**
	 * returns the name value
	 * @return
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * sets the name value
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * returns the value property
	 * @return
	 */
	public String getValue() {
		return value;
	}
	
	/**
	 * sets the value property
	 * @param value
	 */
	public void setValue(String value) {
		this.value = value;
	}
	
	/**
	 * returns the type property
	 * @return
	 */
	public String getType() {
		return type;
	}
	
	/**
	 * sets the type property
	 * @param type
	 */
	public void setType(String type) {
		this.type = type;
	}
	
	/**
	 * returns the bezeichnung property
	 * @return
	 */
	public String getBezeichnung() {
		return bezeichnung;
	}
	
	/**
	 * sets the bezeichnung property
	 * @param bezeichnung
	 */
	public void setBezeichnung(String bezeichnung) {
		this.bezeichnung = bezeichnung;
	}
	
	public List<String> getDefaultValues() {
		return defaultValues;
	}

	public void setDefaultValues(List<String> defaultValues) {
		this.defaultValues = defaultValues;
	}

	/**
	 * prints object
	 */
	@Override
	public String toString() {
		return "BoundVariable [name=" + name + ", bezeichnung=" + bezeichnung + ", value=" + value + ", type=" + type + "]";
	}
	
}