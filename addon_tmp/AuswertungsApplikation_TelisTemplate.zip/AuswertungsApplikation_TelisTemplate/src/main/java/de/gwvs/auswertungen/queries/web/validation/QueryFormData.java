package de.gwvs.auswertungen.queries.web.validation;

import java.io.Serializable;

/**
 * Query form data object for insertion 
 * @author prieger
 * @version 1.0
 */
public class QueryFormData implements Serializable {

	private static final long serialVersionUID = 4642629601933779521L;

	private String queryId;
	private String text;
	private String art;
	private String erstellt;
	private String bereich;
	private String sql;
	private String beschreibung;
	private String authority;
	private boolean isDisabled;
	
	/**
	 * default constructor
	 */
	public QueryFormData() {
	}
	
	/**
	 * constructor with properties
	 * @param queryId the query ID
	 * @param text title of the query
	 * @param art query Art
	 * @param benutzer user of the query
	 * @param erstellt date of creation
	 * @param sql the query's SQL statement
	 * @param bereich domain of the query
	 * @param beschreibung description of the query
	 */
	public QueryFormData(String queryId, String text, String art, String erstellt, String sql, String bereich, String beschreibung, String authority, boolean isDisabled ) {
		super();
		this.queryId = queryId;
		this.text = text;
		this.art = art;
		this.erstellt = erstellt;
		this.sql = sql;
		this.bereich = bereich;
		this.beschreibung = beschreibung;
		this.authority = authority;
		this.setDisabled(isDisabled);
	}

	/**
	 * returns the query ID
	 * @return ID of query
	 */
	public String getQueryId() {
		return queryId;
	}

	/**
	 * sets the query ID
	 * @param queryId ID of query
	 */
	public void setQueryId(String queryId) {
		this.queryId = queryId;
	}

	/**
	 * returns the text value
	 * @return query title
	 */
	public String getText() {
		return text;
	}

	/**
	 * sets the text value
	 * @param text query title
	 */
	public void setText(String text) {
		this.text = text;
	}

	/**
	 * returns the art property
	 * @return art
	 */
	public String getArt() {
		return art;
	}

	/**
	 * sets the art property
	 * @param art art
	 */
	public void setArt(String art) {
		this.art = art;
	}

	/**
	 * returns the erstellt date
	 * @return creation date
	 */
	public String getErstellt() {
		return erstellt;
	}

	/**
	 * sets the erstellt date
	 * @param erstellt new creation date
	 */
	public void setErstellt(String erstellt) {
		this.erstellt = erstellt;
	}

	/**
	 * returns the sql statement
	 * @return SQL statement
	 */
	public String getSql() {
		return sql;
	}

	/**
	 * sets the sql statement
	 * @param sql new SQL statement
	 */
	public void setSql(String sql) {
		this.sql = sql;
	}

	/**
	 * returns the bereich property
	 * @return domain
	 */
	public String getBereich() {
		return bereich;
	}

	/**
	 * sets the bereich property
	 * @param bereich new domain
	 */
	public void setBereich(String bereich) {
		this.bereich = bereich;
	}

	/**
	 * returns the beschreibung property
	 * @return description
	 */
	public String getBeschreibung() {
		return beschreibung;
	}

	/**
	 * sets the beschreibung property
	 * @param beschreibung new description
	 */
	public void setBeschreibung(String beschreibung) {
		this.beschreibung = beschreibung;
	}

	/**
	 * returns serial version uid
	 * @return serial uid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	
	public String getAuthority() {
		return authority;
	}

	public void setAuthority(String authority) {
		this.authority = authority;
	}

	/**
	 * prints out the query
	 */
	@Override
	public String toString() {
		return "QueryFormData [queryId=" + queryId + ", text=" + text + ", art=" + art 
				+ ", erstellt=" + erstellt + ", sql=" + sql + ", bereich=" + bereich + ", beschreibung=" + beschreibung
				+ "]";
	}

	public boolean isDisabled() {
		return isDisabled;
	}

	public void setDisabled(boolean isDisabled) {
		this.isDisabled = isDisabled;
	}
}
