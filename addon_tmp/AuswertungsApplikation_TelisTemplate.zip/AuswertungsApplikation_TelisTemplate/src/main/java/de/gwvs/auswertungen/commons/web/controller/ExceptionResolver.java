/*
 * Copyright (C) 2015 GWVS mbH - All rights reserved.
 */
package de.gwvs.auswertungen.commons.web.controller;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ui.ModelMap;
import org.springframework.web.multipart.MultipartException;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;

/**
 * Controller zur Bearbeitung der Ausnahmebehandlung.
 * 
 * @author Ronny Krammer
 * @version 1.0
 * 
 */
public class ExceptionResolver extends SimpleMappingExceptionResolver {

	/**
	 * {@link Logger}
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(ExceptionResolver.class);
	
	/* (non-Javadoc)
	 * @see org.springframework.web.servlet.handler.AbstractHandlerExceptionResolver#logException(java.lang.Exception, javax.servlet.http.HttpServletRequest)
	 */
	@Override
	protected void logException(Exception ex, HttpServletRequest request) {
		LOGGER.error(ex.getLocalizedMessage(), ex);
	}
	
	/* (non-Javadoc)
	 * @see org.springframework.web.servlet.handler.SimpleMappingExceptionResolver#doResolveException(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, java.lang.Object, java.lang.Exception)
	 */
	@Override
	protected ModelAndView doResolveException(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {
		ModelAndView modelAndView = super.doResolveException(request, response, handler, ex);
		if(modelAndView != null) {
			ModelMap modelMap = modelAndView.getModelMap();
			modelMap.addAttribute("now", new Date());
			if(handler != null) {
				modelMap.addAttribute("handler", handler.toString());
			}
			if (ex instanceof javax.servlet.ServletException && ex.getMessage().contains("Does your handler implement a supported interface like Controller")) {
				modelMap.clear();
				modelAndView.setViewName("redirect:/error/notfound");
			} else if (ex instanceof MultipartException) {
				modelMap.clear();
				modelMap.addAttribute("maxUploadSizeExceeded", true);
				modelAndView.setViewName("redirect:" + request.getRequestURI().replace(request.getContextPath(), ""));
			}
		}
		return modelAndView; 
	}
}
