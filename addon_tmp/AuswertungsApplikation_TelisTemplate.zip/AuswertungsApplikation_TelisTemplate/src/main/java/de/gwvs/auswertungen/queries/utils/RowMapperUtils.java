package de.gwvs.auswertungen.queries.utils;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * row mapper utils class
 * used by DAO objects
 * @author prieger
 *
 */
public final class RowMapperUtils {
	
	/**
	 * empty constructor
	 */
	private RowMapperUtils() { 
	}

	/**
	 * returns a string from result set that has a given name, 
	 * if value is null, return given default value
	 * @param rs
	 * @param columnName
	 * @param defaultValue
	 * @return
	 * @throws SQLException
	 */
	public static String getString(final ResultSet rs, final String columnName, final String defaultValue) throws SQLException {
		final String value;
		if(rs.getString(columnName) == null) {
			value = defaultValue;
		} else {
			value = rs.getString(columnName);
		}
		return value;
	}

	/**
	 * returns an integer from result set that has a given name, 
	 * if value is null, return given default value
	 * @param rs
	 * @param columnName
	 * @param defaultValue
	 * @return
	 * @throws SQLException
	 */
	public static Integer getInteger(final ResultSet rs, final String columnName, final Integer defaultValue) throws SQLException {
		final Integer value;
		if(rs.getObject(columnName) == null) {
			value = defaultValue;
		} else {
			value = rs.getInt(columnName);
		}
		return value;
	}
	
	/**
	 * returns a long from result set that has a given name, 
	 * if value is null, return given default value
	 * @param rs
	 * @param columnName
	 * @param defaultValue
	 * @return
	 * @throws SQLException
	 */
	public static Long getLong(final ResultSet rs, final String columnName, final Long defaultValue) throws SQLException {
		final Long value;
		if(rs.getObject(columnName) == null) {
			value = defaultValue;
		} else {
			value = rs.getLong(columnName);
		}
		return value;
	}
	
	/**
	 * returns local date object from result set that has a given name, 
	 * if value is null, return given default value
	 * @param rs
	 * @param columnName
	 * @param defaultValue
	 * @return
	 * @throws SQLException
	 */
	public static LocalDate getLocalDate(final ResultSet rs, final String columnName, final LocalDate defaultValue) throws SQLException {
		final LocalDate value;
		if(rs.getObject(columnName) == null) {
			value = defaultValue;
		} else {
			value = rs.getDate(columnName).toLocalDate();
		}
		return value;
	}

	public static boolean getBoolean(ResultSet rs, String columnName, boolean defaultValue) throws SQLException {
		final boolean value;

		if(rs.getObject(columnName) == null) {
			value = defaultValue;
		} else if(rs.getInt(columnName) == 1) {
			value = true;
		} else {
			value = false;
		}
		return value;
	}
}