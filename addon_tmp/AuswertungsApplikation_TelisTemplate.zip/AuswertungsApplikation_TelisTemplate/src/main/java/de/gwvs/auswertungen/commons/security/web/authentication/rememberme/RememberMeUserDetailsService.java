/*
 * Copyright (C) 2007 GWVS mbH - All rights reserved.
 */
package de.gwvs.auswertungen.commons.security.web.authentication.rememberme;

import org.springframework.dao.DataAccessException;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

/**
 * {@link UserDetailsService} für den Remember me Service
 * 
 * @author Ronny Krammer
 * @version 1.0
 * 
 */
public class RememberMeUserDetailsService implements UserDetailsService {

	/*
	 * (non-Javadoc)
	 * 
	 * @seeorg.springframework.security.core.userdetails.UserDetailsService#
	 * loadUserByUsername(java.lang.String)
	 */
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException, DataAccessException {
		return new User(username, "", true, true, true, true, AuthorityUtils.NO_AUTHORITIES);
	}

}
