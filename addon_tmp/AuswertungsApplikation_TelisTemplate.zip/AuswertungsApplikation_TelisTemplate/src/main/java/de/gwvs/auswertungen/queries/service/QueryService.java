package de.gwvs.auswertungen.queries.service;

import java.util.List;

import org.springframework.security.access.prepost.PostFilter;

import de.gwvs.auswertungen.queries.domain.Query;

/**
 * Interface for the query service
 * @author prieger
 * @version 1.0
 */
public interface QueryService {

	/**
	 * Retrieves all queries for a given user name by means of the query DAO
	 *  (delegation)
	 * @param username user name 
	 * @return list of the found queries
	 */
	@PostFilter("hasPermission(filterObject, '')")
	public List<Query> getAllQueries();
	
	/**
	 * Retrieves all favorite queries by means of 
	 * the query DAO (delegation)
	 * @param username user name
	 * @return list of found favorite queries
	 */
	public List<Query> getAllFavs(final String username);
	
	/**
	 * Retrieves all queries for a given user name and filters all their 
	 * domain properties into a list
	 * @param username user name 
	 * @return list of all distinct domains
	 */
	public List<String> getBereicheList(final List<Query> queries);
	
	/**
	 * Retrieves all queries for a given user name and filters all 
	 * their creation dates into a list
	 * @param username user name 
	 * @return list of all distinct creation dates
	 */
	public List<String> getErstelltList(final List<Query> queries);
	
	/**
	 * Removes the query for a given query ID and user name from the 
	 * favorite relation by means of the query DAO (delegation)
	 * @param queryId ID of the query
	 * @param username user name 
	 * @return if the removal succeeded
	 */
	public boolean removeQueryFromFav(final Long queryId, final String username);
	
	/**
	 * Adds the query for a given query ID and user name to the favorite
	 * relation by means of the query DAO (delegation)
	 * @param queryId ID of the query
	 * @param username user name
	 * @return if insertion succeeded
	 */
	public boolean addRowToFav(final Long queryId, final String username);
	
	/**
	 * Retrieves a query by a given query ID by means of 
	 * the query DAO (delegation)
	 * @param queryId ID of the query
	 * @return found query object
	 */
	public Query getQueryById(final Long queryId);
	
	/**
	 * Executes the given SQL statement by means of the query DAO (delegation)
	 * and returns its result 
	 * @param sql SQL statement that is to be executed
	 * @return list of list of strings: 1st inner list represents the column names,
	 * 									2nd inner list represents the rows
	 */
	public List<List<String>> executeQuery(final String sql);
	
	/**
	 * Inserts a new instance into the instance relation by means of 
	 * the query DAO (delegation). Represents that a query was executed
	 * @param queryId ID of the query that was launched
	 * @param username user name
	 * @param dauer duration of execution
	 */
	public void insertInstance(final Long queryId, final String username, final int dauer);
	
	/**
	 * Retrieves all query IDs by means of the query DAO (delegation)
	 * @return list of all found query IDs
	 */
	public List<Long> getAllIds();
	
	/**
	 * Inserts a given query object into the database by means
	 * of the query DAO (delegation)
	 * @param query
	 */
	public void insertQuery(final Query query);

	public boolean updateQuery(Query query);

	public List<Query> getAllQueriesForAdmin();

	public Query getQueryByIdForAdmin(Long queryId);
	
}
