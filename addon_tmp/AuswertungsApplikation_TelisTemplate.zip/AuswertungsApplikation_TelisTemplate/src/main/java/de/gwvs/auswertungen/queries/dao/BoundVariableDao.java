package de.gwvs.auswertungen.queries.dao;

import java.util.List;

import org.springframework.cache.annotation.Cacheable;

/**
 * interface for bound variable data access object
 * @author prieger
 * @version 1.0
 */
public interface BoundVariableDao {

	@Cacheable("boundVarNameCache")
	String getTypeByName(final String name);
	
	@Cacheable("boundVarTypeCache")
	String getBezeichnungByName(final String name);
	
	List<String> getDefaultValuesByName(final String name);
}
