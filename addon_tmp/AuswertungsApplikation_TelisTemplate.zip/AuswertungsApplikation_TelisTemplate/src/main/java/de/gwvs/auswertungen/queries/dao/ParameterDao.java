package de.gwvs.auswertungen.queries.dao;

import java.util.List;

import de.gwvs.auswertungen.queries.domain.Parameter;

public interface ParameterDao {

	Parameter findParameterById(final Long parameterId);
	List<Parameter> findAllParameters();
	boolean updateParameter(final Parameter parameter);
	boolean insertParameter(final Parameter parameter);
	boolean deleteParameterById(final Long parameterId);
	boolean deleteParameter(final Parameter parameter);
	List<Long> findAllIds();
	Parameter findParameterByName(String name);
	
}