/*
 * Copyright (C) 2007 GWVS mbH - All rights reserved.
 */
package de.gwvs.auswertungen.commons.security.web.authentication.rememberme;

import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.encrypt.Encryptors;
import org.springframework.security.crypto.encrypt.TextEncryptor;
import org.springframework.security.web.authentication.rememberme.InvalidCookieException;
import org.springframework.security.web.authentication.rememberme.RememberMeAuthenticationException;
import org.springframework.security.web.authentication.rememberme.TokenBasedRememberMeServices;
import org.springframework.util.StringUtils;

import de.gwvs.auswertungen.commons.security.ldap.authentication.TosLdapAuthenticationProvider;

public class TosBasedRememberMeService extends TokenBasedRememberMeServices {

	private TosLdapAuthenticationProvider ldapAuthenticationProvider = null;

	private TextEncryptor textEncryptor = Encryptors.text("n0rb3rttr3F1nanzVerm1tAG", "6757763552654d65");

	public TosBasedRememberMeService(String key, UserDetailsService userDetailsService) {
		super(key, userDetailsService);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @seeorg.springframework.security.web.authentication.rememberme.
	 * TokenBasedRememberMeServices
	 * #calculateLoginLifetime(javax.servlet.http.HttpServletRequest,
	 * org.springframework.security.core.Authentication)
	 */
	@Override
	protected int calculateLoginLifetime(HttpServletRequest request, Authentication authentication) {
		if (isInternalIPAddr(request)) {
			return getTokenValiditySeconds();
		} else {
			Calendar now = Calendar.getInstance();
			long nowInMills = now.getTimeInMillis();
			now.set(Calendar.HOUR_OF_DAY, 23);
			now.set(Calendar.MINUTE, 59);
			now.set(Calendar.SECOND, 59);
			long eveningInMills = now.getTimeInMillis();
			return (int)((eveningInMills - nowInMills) / 1000);
		}
	}

	private String getIPAddr(HttpServletRequest request) {
		String ip = "";
		if (request.getHeader("x-forwarded-for") == null) {
			ip = request.getRemoteAddr();
		} else {
			ip = request.getHeader("x-forwarded-for");
		}

		if (ip.contains(",")) {
			String[] split = ip.split(",");
			ip = split[0].trim();
		}

		return ip;
	}

	private boolean isInternalIPAddr(HttpServletRequest request) {
		String ip = getIPAddr(request);
		return ip.startsWith("10.") || ip.startsWith("192.168.") || "127.0.0.1".equals(ip);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @seeorg.springframework.security.web.authentication.rememberme.
	 * TokenBasedRememberMeServices
	 * #onLoginSuccess(javax.servlet.http.HttpServletRequest,
	 * javax.servlet.http.HttpServletResponse,
	 * org.springframework.security.core.Authentication)
	 */
	@Override
	public void onLoginSuccess(HttpServletRequest request, HttpServletResponse response, Authentication successfulAuthentication) {
		String username = retrieveUserName(successfulAuthentication);
		String password = retrievePassword(successfulAuthentication);

		if (!StringUtils.hasLength(username) || !StringUtils.hasLength(password)) {
			return;
		}

		int tokenLifetime = calculateLoginLifetime(request, successfulAuthentication);
		long expiryTime = System.currentTimeMillis();
		expiryTime += 1000L * (tokenLifetime < 0 ? TWO_WEEKS_S : tokenLifetime);

		String passwortToken = "-";
		try {
			passwortToken = textEncryptor.encrypt(password + "|" + getIPAddr(request));
		} catch (Exception e) {
			logout(request, response, successfulAuthentication);
			logger.error(e.getLocalizedMessage(), e);
		}

		String signatureValue = makeTokenSignature(expiryTime, username, passwortToken);

		setCookie(new String[] { username, Long.toString(expiryTime), signatureValue, passwortToken, String.valueOf(UUID.randomUUID()) }, tokenLifetime, request, response);
		if (logger.isDebugEnabled()) {
			logger.debug("Added remember-me cookie for user '" + username + "', expiry: '" + new Date(expiryTime) + "'");
		}
	}

	/*
	 * (non-Javadoc)
	 *
	 * @seeorg.springframework.security.web.authentication.rememberme.
	 * TokenBasedRememberMeServices#processAutoLoginCookie(java.lang.String[],
	 * javax.servlet.http.HttpServletRequest,
	 * javax.servlet.http.HttpServletResponse)
	 */
	@Override
	public UserDetails processAutoLoginCookie(String[] cookieTokens, HttpServletRequest request, HttpServletResponse response) {
		if (cookieTokens.length != 5) {
			throw new InvalidCookieException("Cookie token did not contain " + 5 + " tokens, but contained '" + Arrays.asList(cookieTokens) + "'");
		}

		String[] passwordTokens = { "" };
		try {
			passwordTokens = StringUtils.delimitedListToStringArray(textEncryptor.decrypt(cookieTokens[3]), "|");
		} catch (Exception e1) {
			cancelCookie(request, response);
			logger.error(e1.getLocalizedMessage(), e1);
		}

		long tokenExpiryTime;

		try {
			tokenExpiryTime = Long.valueOf(cookieTokens[1]);
		} catch (NumberFormatException nfe) {
			throw new InvalidCookieException("Cookie token[1] did not contain a valid number (contained '" + cookieTokens[1] + "')");
		}

		if (isTokenExpired(tokenExpiryTime)) {
			throw new InvalidCookieException("Cookie token[1] has expired (expired on '" + new Date(tokenExpiryTime) + "'; current time is '" + new Date() + "')");
		}

		if (passwordTokens.length != 2) {
			try {
				throw new InvalidCookieException("Cookie token did not contain 2 passwort tokens; decoded value was '" + textEncryptor.decrypt(cookieTokens[1]) + "'");
			} catch (Exception e) {
				cancelCookie(request, response);
				logger.error(e.getLocalizedMessage(), e);
			}
		}

		if (!passwordTokens[1].equals(getIPAddr(request))) {
			throw new InvalidCookieException("IP address is wrong;");
		}

		UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(cookieTokens[0], passwordTokens[0]);
		Authentication auth = null;
		try {
			auth = ldapAuthenticationProvider.authenticate(authentication);
		} catch(BadCredentialsException e) {
			logout(request, response, authentication);
			throw new RememberMeAuthenticationException(e.getLocalizedMessage(), e);
		}

		return (UserDetails) auth.getPrincipal();
	}

	public void setLdapAuthenticationProvider(TosLdapAuthenticationProvider ldapAuthenticationProvider) {
		this.ldapAuthenticationProvider = ldapAuthenticationProvider;
	}

}
