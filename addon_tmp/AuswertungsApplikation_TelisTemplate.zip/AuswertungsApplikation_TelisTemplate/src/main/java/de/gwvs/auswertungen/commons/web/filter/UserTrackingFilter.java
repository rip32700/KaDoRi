/*
 * Copyright (C) 2007 GWVS mbH - All rights reserved.
 */
package de.gwvs.auswertungen.commons.web.filter;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.servletapi.SecurityContextHolderAwareRequestWrapper;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import de.gwvs.auswertungen.commons.security.domain.AuswertungenUser;

/**
 * Filter für das Tracking von Benutzerdaten
 *
 * @author Ronny Krammer
 * @version 1.0
 *
 */
public class UserTrackingFilter extends OncePerRequestFilter {

	/**
	 * {@link Logger}
	 */
	protected static final Logger TRACKING = LoggerFactory.getLogger("UserTracking");

	/* (non-Javadoc)
	 * @see org.springframework.web.filter.OncePerRequestFilter#doFilterInternal(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, javax.servlet.FilterChain)
	 */
	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
		if (request != null) {
			String uri = request.getRequestURI();
			String userAgent = request.getHeader("User-Agent");
			if (!StringUtils.hasText(userAgent)) {
				userAgent = "-";
			}

			if (StringUtils.hasText(uri) && !userAgent.contains("PRTG Network Monitor") && !uri.startsWith("/auswertungen/resources/")) {
				StringBuilder builder = new StringBuilder();
				builder.append("; ");

				AuswertungenUser dikoUser = null;
				SecurityContext securityContext = SecurityContextHolder.getContext();
				if (securityContext != null) {
					Authentication authentication = securityContext.getAuthentication();
					if (authentication != null) {
						Object principal = authentication.getPrincipal();
						if (principal instanceof AuswertungenUser) {
							dikoUser = (AuswertungenUser) principal;
						}
					}
				}

				if (dikoUser == null) {
					builder.append("\"\"; ");
					builder.append("\"\"; ");
				} else {
					builder.append("\"").append(dikoUser.getAdm()).append("\"; ");
					builder.append("\"").append(dikoUser.getUsername()).append(" ").append(dikoUser.getFullname()).append("\"; ");
				}
				builder.append("\"" + request.getRequestURI() + "\"; ");
				builder.append("\"");

				Enumeration<String> it = request.getParameterNames();
				if (request instanceof SecurityContextHolderAwareRequestWrapper) {
					SecurityContextHolderAwareRequestWrapper wrapper = (SecurityContextHolderAwareRequestWrapper) request;
					it = wrapper.getRequest().getParameterNames();
				}
				String value = "";

				while (it.hasMoreElements()) {
					String key = it.nextElement();
					value = request.getParameter(key);
					if (value != null) {
						value = value.replaceAll("\\n", " ");
						value = value.replaceAll("\\r", "");
						value = value.replaceAll("\"", "'");
					}

					if ("j_password".equals(key.trim()) || key.trim().contains("asswort")) {
						builder.append(key).append("=XXXXXXXX");
					} else {
						builder.append(key).append("=").append(value);
					}
					value = "";
					if (it.hasMoreElements()) {
						builder.append("&");
					}
				}

				builder.append("\"; ");
				if (request.getHeader("Referer") == null) {
					builder.append("\"\"; ");
				} else {
					builder.append("\"").append(request.getHeader("Referer")).append("\"; ");
				}
				if (StringUtils.hasText(request.getHeader("x-forwarded-for"))) {
					builder.append("\"").append(request.getHeader("x-forwarded-for")).append("\"; ");
				} else {
					builder.append("\"").append(request.getRemoteAddr()).append("\"; ");
				}
				builder.append("\"").append(request.getHeader("User-Agent")).append("\"; ");
				builder.append("\"").append(request.getMethod()).append("\"");

				TRACKING.trace(builder.toString());
			}
		}
		filterChain.doFilter(request, response);
	}

}
