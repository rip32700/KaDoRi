package de.gwvs.auswertungen.queries.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.springframework.jdbc.core.namedparam.NamedParameterJdbcOperations;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import de.gwvs.auswertungen.queries.dao.BoundVariableDao;
import de.gwvs.auswertungen.queries.utils.RowMapperUtils;

/**
 * bound variable data access object implementation
 * @author prieger
 * @version 1.0
 */
@Repository
public class BoundVariableDaoImpl implements BoundVariableDao {

	private final static String GET_TYPE_BY_NAME = "SELECT AU_TYP FROM AU_PARAMETER WHERE AU_PARAMNAME = :paramname";
	private final static String GET_BEZEICHNUNG_BY_NAME = "SELECT AU_BEZEICHNUNG FROM AU_PARAMETER WHERE AU_PARAMNAME = :paramname";
	private final static String GET_DEFAULT_VALUES_BY_NAME = "SELECT AU_DEFAULT FROM AU_PARAMETER WHERE AU_PARAMNAME = :paramname";
	
	private NamedParameterJdbcOperations jdbcOperations;
	
	/**
	 * sets the data source
	 * @param dataSource
	 */
	@Resource(name = "dataSource")
	public void setDataSource(DataSource dataSource) {
		jdbcOperations = new NamedParameterJdbcTemplate(dataSource);
	}

	/**
	 * gets the type of a bound variable by its name
	 */
	@Override
	public String getTypeByName(final String name) {
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("paramname", name);
		return jdbcOperations.queryForObject(GET_TYPE_BY_NAME, paramMap, this::mapType);
	}

	/**
	 * gets the bezeichnung of a bound variable by its name
	 */
	@Override
	public String getBezeichnungByName(final String name) {
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("paramname", name);
		return jdbcOperations.queryForObject(GET_BEZEICHNUNG_BY_NAME, paramMap, this::mapBezeichnung);
	}
	
	@Override
	public List<String> getDefaultValuesByName(final String name) {
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("paramname", name);
		String stringList = jdbcOperations.queryForObject(GET_DEFAULT_VALUES_BY_NAME, paramMap, this::mapDefaultValues);
		return Arrays.asList(stringList.split(","));
	}
	
	// MAPPER METHODS\
	/**
	 * maps a result set to a bound variable type (string)
	 * @param rs
	 * @param rowNum
	 * @return
	 * @throws SQLException
	 */
	private String mapType(final ResultSet rs, final long rowNum) throws SQLException {
		return new String(RowMapperUtils.getString(rs, "AU_TYP", ""));
	}
	
	/**
	 * maps a result set to a bound variable bezeichnung (string)
	 * @param rs
	 * @param rowNum
	 * @return
	 * @throws SQLException
	 */
	private String mapBezeichnung(final ResultSet rs, final long rowNum) throws SQLException {
		return new String(RowMapperUtils.getString(rs, "AU_BEZEICHNUNG", ""));
	}
	
	private String mapDefaultValues(final ResultSet rs, final long rowNum) throws SQLException {
		return new String(RowMapperUtils.getString(rs, "AU_DEFAULT", ""));
	}

}
