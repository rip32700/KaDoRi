/*
 * Copyright (C) 2015 GWVS mbH - All rights reserved.
 */
package de.gwvs.auswertungen.commons.web.config;

import java.util.List;
import java.util.Properties;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScan.Filter;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.web.method.annotation.AuthenticationPrincipalArgumentResolver;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.mvc.WebContentInterceptor;
import org.springframework.web.servlet.view.UrlBasedViewResolver;
import org.springframework.web.servlet.view.tiles3.TilesConfigurer;
import org.springframework.web.servlet.view.tiles3.TilesView;

import de.gwvs.auswertungen.commons.web.controller.ExceptionResolver;
import de.gwvs.auswertungen.commons.web.interceptor.TimeBasedAccessInterceptor;

/**
 * {@link Configuration} des Web MVC
 * 
 * @author Ronny Krammer
 * @version 1.0
 * 
 */
@Configuration
@EnableWebMvc
@ComponentScan(basePackages = { "de.gwvs.auswertungen" }, excludeFilters = @Filter(Configuration.class))
public class WebMvcConfig extends WebMvcConfigurerAdapter {

	/* (non-Javadoc)
	 * @see org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter#addArgumentResolvers(java.util.List)
	 */
	@Override
	public void addArgumentResolvers(List<HandlerMethodArgumentResolver> argumentResolvers) {
		argumentResolvers.add(new AuthenticationPrincipalArgumentResolver());
	}
	
	/** 
	 * Erzeugt einen {@link ExceptionResolver}
	 * 
	 * @return {@link ExceptionResolver}
	 */
	@Bean
	public ExceptionResolver exceptionResolver() {
		Properties mappings = new Properties();
		mappings.setProperty("org.springframework.security.access.AccessDeniedException", "common/accessDenied");

		ExceptionResolver resolver = new ExceptionResolver();
		resolver.setDefaultErrorView("common/exception");
		resolver.setExceptionMappings(mappings);
		return resolver;
	}
	
	/* (non-Javadoc)
	 * @see org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter#addInterceptors(org.springframework.web.servlet.config.annotation.InterceptorRegistry)
	 */
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(timeBasedAccessInterceptor());
		registry.addInterceptor(webContentInterceptor());
	}
	
	/* (non-Javadoc)
	 * @see org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter#addResourceHandlers(org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry)
	 */
	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler("/resources/**").addResourceLocations("/resources/").setCachePeriod(1209600);
		registry.addResourceHandler("/webjars/**").addResourceLocations("classpath:/META-INF/resources/webjars/").setCachePeriod(31556926);
	}
	
	/* (non-Javadoc)
	 * @see org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter#addViewControllers(org.springframework.web.servlet.config.annotation.ViewControllerRegistry)
	 */
	@Override
	public void addViewControllers(ViewControllerRegistry registry) {
		registry.addViewController("/login");
		registry.addViewController("/impressum");
	}

	/**
	 * Erzeugt einen {@link UrlBasedViewResolver}
	 * 
	 * @return {@link UrlBasedViewResolver}
	 */
	@Bean
	public UrlBasedViewResolver getInternalResourceViewResolver() {
		UrlBasedViewResolver resolver = new UrlBasedViewResolver();
		resolver.setViewClass(TilesView.class);
		return resolver;
	}

	/**
	 * Erzeugt einen {@link TilesConfigurer}
	 * 
	 * @return {@link TilesConfigurer}
	 */
	@Bean
	public TilesConfigurer tilesConfigurer() {
		TilesConfigurer configurer = new TilesConfigurer();
		configurer.setDefinitions("/WEB-INF/layouts/layouts.xml", "/WEB-INF/views/**/views.xml");
		return configurer;
	}

	/**
	 * Erzeugt einen {@link TimeBasedAccessInterceptor}
	 * 
	 * @return {@link TimeBasedAccessInterceptor}
	 */
	@Bean
	public TimeBasedAccessInterceptor timeBasedAccessInterceptor() {
		TimeBasedAccessInterceptor timeBasedAccessInterceptor = new TimeBasedAccessInterceptor();
		timeBasedAccessInterceptor.setOutTimeLink("/WEB-INF/views/common/zeit.jsp");
		timeBasedAccessInterceptor.setOpeningTime(2);
		timeBasedAccessInterceptor.setClosingTime(24);
		return timeBasedAccessInterceptor;
	}

	/**
	 * Erzeugt einen {@link WebContentInterceptor}
	 * 
	 * @return {@link WebContentInterceptor}
	 */
	@Bean
	public WebContentInterceptor webContentInterceptor() {
		WebContentInterceptor webContentInterceptor = new WebContentInterceptor();
		webContentInterceptor.setCacheSeconds(0);
		return webContentInterceptor;
	}

}
