/*
 * Copyright (C) 2008 GWVS mbH - All rights reserved.
 */
package de.gwvs.auswertungen.commons.security.exception;

import org.springframework.security.authentication.BadCredentialsException;

/**
 * Eine {@link org.springframework.security.authentication.BadCredentialsException} Exception.
 * 
 * @author Ronny Krammer
 * @version 1.0
 * 
 */
public class NoAccessException extends BadCredentialsException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1903893108587745681L;

	/**
	 * Constructs a <code>NoAccessException</code> with the specified message.
	 * 
	 * @param msg the detail message.
	 */
	public NoAccessException(String msg) {
		super(msg);
	}

	/**
	 * Constructs a <code>NoAccessException</code> with the specified message and root cause.
	 * 
	 * @param msg the detail message.
	 * @param t root cause
	 */
	public NoAccessException(String msg, Throwable t) {
		super(msg, t);
	}

}
