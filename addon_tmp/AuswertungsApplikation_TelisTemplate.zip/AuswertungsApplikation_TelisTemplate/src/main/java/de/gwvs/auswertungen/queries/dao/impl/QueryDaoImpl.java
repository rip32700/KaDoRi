package de.gwvs.auswertungen.queries.dao.impl;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.springframework.jdbc.core.namedparam.NamedParameterJdbcOperations;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import de.gwvs.auswertungen.queries.dao.QueryDao;
import de.gwvs.auswertungen.queries.domain.Query;
import de.gwvs.auswertungen.queries.utils.RowMapperUtils;

/**
 * Query data access object implementation
 * @author prieger
 * @version 1.0
 */
@Repository
public class QueryDaoImpl implements QueryDao {
	
	private final String FIND_ALL_QUERIES 			= 	"SELECT A.AU_AID, A.AU_TITEL, A.AU_ART, A.AU_BESCHREIBUNG, A.AU_DATUM, A.AU_BEREICH, A.AU_SQL, M.MR_TOS AS AU_AUTHORITY_NO, A.AU_DISABLED FROM au_auswertungen A INNER JOIN menuerechte M on (au_authority_no = mr_rechtenr) WHERE au_disabled = 0 ORDER BY A.AU_AID"; //"SELECT A.AU_AID, A.AU_TITEL, A.AU_ART, B.AU_USERNAME, A.AU_DATUM, A.AU_BEREICH, A.AU_SQL, M.MR_TOS AS AU_AUTHORITY_NO FROM au_auswertung_zu_benutzer INNER JOIN au_auswertungen A on (au_aid = aid) INNER JOIN au_benutzer B on (b.id = benutzer_id) INNER JOIN menuerechte M on (au_authority_no = mr_rechtenr) WHERE LOWER(B.AU_USERNAME) = :username ORDER BY A.AU_AID";
	private final String FIND_ALL_QUERIES_FOR_ADMIN =   "SELECT * FROM AU_AUSWERTUNGEN";
	private final String FIND_ONE_QUERY    			= 	"SELECT A.AU_AID, A.AU_TITEL, A.AU_ART, A.AU_BESCHREIBUNG, A.AU_DATUM, A.AU_BEREICH, A.AU_SQL, M.MR_TOS AS AU_AUTHORITY_NO, A.AU_DISABLED FROM au_auswertungen A INNER JOIN menuerechte M on (au_authority_no = mr_rechtenr) WHERE a.au_aid = :id AND au_disabled = 0";
	private final String FIND_ONE_QUERY_FOR_ADMIN	= 	"SELECT A.AU_AID, A.AU_TITEL, A.AU_ART, A.AU_BESCHREIBUNG, A.AU_DATUM, A.AU_BEREICH, A.AU_SQL, M.MR_TOS AS AU_AUTHORITY_NO, A.AU_DISABLED FROM au_auswertungen A INNER JOIN menuerechte M on (au_authority_no = mr_rechtenr) WHERE a.au_aid = :id";
	private final String FIND_ALL_IDS 				= 	"SELECT au_aid FROM AU_AUSWERTUNGEN au_disabled = 0";
	private final String FIND_FAVS_BY_USER 			= 	"SELECT A.AU_AID, A.AU_TITEL, A.AU_ART, A.AU_BESCHREIBUNG, F.AU_USER, A.AU_DATUM, A.AU_BEREICH, A.AU_SQL, M.MR_TOS AS AU_AUTHORITY_NO, A.AU_DISABLED FROM au_favoriten F INNER JOIN au_auswertungen A on (F.au_aid = A.au_aid) INNER JOIN menuerechte M on (au_authority_no = mr_rechtenr) WHERE LOWER(F.AU_USER) = :username AND au_disabled = 0 ORDER BY A.AU_AID";
	private final String FIND_ALL_FAV_IDS			= 	"SELECT au_aid FROM AU_FAVORITEN INNER JOIN AU_AUSWERTUNGEN USING(au_aid) WHERE LOWER(au_user) = :username AND au_disabled = 0";
	private final String UPDATE_QUERY               =   "UPDATE au_auswertungen SET au_aid = :aid, au_art = :art, au_vertriebskz = :vertriebskz, au_bereich = :bereich, au_datum = SYSDATE, au_titel = :title, au_beschreibung = :beschreibung, au_sql = :sql, au_disabled = :disabled WHERE au_aid = :aid";
	private final String INSERT_QUERY 				= 	"INSERT INTO AU_AUSWERTUNGEN (au_aid, au_titel, au_beschreibung, au_art, au_datum, au_bereich, au_sql, au_vertriebskz, au_disabled) VALUES(:aid, :title, :beschreibung, :art, SYSDATE, :bereich, :sql, :vertriebskz, :disabled)";
	private final String INSERT_QUERY_INTO_FAV		= 	"INSERT INTO AU_FAVORITEN (au_fid, au_aid, au_user) VALUES(au_fav_seq.NEXTVAL, :aid, :username)";
	private final String INSERT_INSTANCE			= 	"INSERT INTO AU_INSTANZEN VALUES (au_inst_seq.NEXTVAL, :aid, SYSDATE, :username, '---', :dauer)";
	private final String DELETE_FAV				 	= 	"DELETE FROM AU_FAVORITEN WHERE au_aid = :aid AND LOWER(au_user) = :username";
	
	/**
	 * JDBC operations object for the configured database access
	 */
	private NamedParameterJdbcOperations jdbcOperations;

	/**
	 * Sets the JDBC operations object with the configured data source
	 * @param dataSource
	 */
	@Resource(name = "dataSource")
	public void setDataSource(DataSource dataSource) {
		jdbcOperations = new NamedParameterJdbcTemplate(dataSource);
	}
	
	@Override
	public List<Query> findAllQueries() {
		return jdbcOperations.getJdbcOperations().query(FIND_ALL_QUERIES, this::mapQuery);
	}
	
	@Override
	public List<Query> findAllQueriesForAdmin() {
		return jdbcOperations.getJdbcOperations().query(FIND_ALL_QUERIES_FOR_ADMIN, this::mapQuery);
	}
	
	@Override
	public Query findQueryById(final long id) {
		return jdbcOperations.getJdbcOperations().queryForObject(FIND_ONE_QUERY, this::mapQuery, id);
	}
	
	@Override
	public Query findQueryByIdForAdmin(final long id) {
		return jdbcOperations.getJdbcOperations().queryForObject(FIND_ONE_QUERY_FOR_ADMIN, this::mapQuery, id);
	}
	
	@Override
	public List<Long> findAllIds() {
		return jdbcOperations.getJdbcOperations().query(FIND_ALL_IDS, this::mapQueryId);
	}
	
	@Override
	public List<Query> findAllFavoriteQueries(final String username) {
		return jdbcOperations.getJdbcOperations().query(FIND_FAVS_BY_USER, this::mapQuery, username);
	}
	
	@Override
	public List<Long> findAllFavIds(final String username) {
		return jdbcOperations.getJdbcOperations().query(FIND_ALL_FAV_IDS, this::mapQueryId, username);
	}
	
	@Override
	public void insertQuery(final Query query) {
		jdbcOperations.update(INSERT_QUERY, buildUpsertMap(query));
	}

	@Override
	public void updateQuery(Query query) {
		Map<String, Object> paramMap = buildUpsertMap(query);
		jdbcOperations.update(UPDATE_QUERY, paramMap);
	}

	@Override
	public void insertQueryToFav(final long queryId, final String username) {
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("aid", queryId);
		paramMap.put("username", username.toUpperCase());
		jdbcOperations.update(INSERT_QUERY_INTO_FAV, paramMap);
	}

	@Override
	public void insertInstance(final long queryId, final String username, final long dauer) {
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("aid", queryId);
		paramMap.put("username", username);
		paramMap.put("dauer", dauer);
		jdbcOperations.update(INSERT_INSTANCE, paramMap);
	}
	
	@Override
	public void deleteQueryFromFavorites(final Long queryId, final String username) {
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("aid", queryId);
		paramMap.put("username", username);
		
		jdbcOperations.update(DELETE_FAV, paramMap);
	}
	
	@Override
	public List<List<String>> executeQuery(final String sql) {
		final List<List<String>> resultList = new ArrayList<List<String>>();
		List<String> columnNames = new ArrayList<>();
		List<String> rows = new ArrayList<>();
		
		// fetch rows from the database
		rows = jdbcOperations.query(sql, (rs, rowNum) -> {
			
			// get all column names (only once within the 1st iteration (-> it's empty in this case)
			if(columnNames.isEmpty()) {
				ResultSetMetaData rsmd = rs.getMetaData();
				for(int i = 1; i < rsmd.getColumnCount(); i++) {
					columnNames.add(rsmd.getColumnName(i));
				}
			}
			
			// create result string (concatenation of all column values)
			String result = "";
			for(String column : columnNames) {
				result += rs.getString(column) + "#";
			}
			
			// add delimiter for splitting in Java Script later on
			result += ";";
			
			return result ;
		});
		
		resultList.add(columnNames);
		resultList.add(rows);
		
		return resultList;
	}
	
	// MAPPER METHODS
	
	/**
	 * Maps a result set to a query 
	 * @param rs result set
	 * @param rowNum number of rows
	 * @return query object
	 * @throws SQLException SQL exception
	 */
	private Query mapQuery(final ResultSet rs, final int rowNum) throws SQLException {
		return new Query(
					RowMapperUtils.getLong(rs, "AU_AID", 0L),
					RowMapperUtils.getString(rs, "AU_TITEL", ""),
					RowMapperUtils.getString(rs, "AU_BESCHREIBUNG", ""),
					RowMapperUtils.getString(rs, "AU_ART", ""),
					RowMapperUtils.getLocalDate(rs, "AU_DATUM", LocalDate.now()),
					RowMapperUtils.getString(rs, "AU_BEREICH", ""),
					RowMapperUtils.getString(rs, "AU_SQL", ""),
					RowMapperUtils.getString(rs, "AU_AUTHORITY_NO", ""),
					RowMapperUtils.getBoolean(rs, "AU_DISABLED", false)
				);
	}
	
	/**
	 * Maps a result set to a query ID
	 * @param rs result set
	 * @param rowNum number of rows
	 * @return query ID
	 * @throws SQLException SQL exception
	 */
	private Long mapQueryId(final ResultSet rs, final int rowNum) throws SQLException {
		return RowMapperUtils.getLong(rs, "AU_AID", -1L);
	}
	
	private Map<String, Object> buildUpsertMap(final Query query) {
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("aid", query.getQueryId());
		paramMap.put("title", query.getText());
		paramMap.put("beschreibung", query.getBeschreibung());
		paramMap.put("art", query.getArt());
		paramMap.put("bereich", query.getBereich());
		paramMap.put("sql", query.getSql());
		paramMap.put("vertriebskz", "TELIS");
		paramMap.put("disabled", query.isDisabled());
		return paramMap;
	}
	
}