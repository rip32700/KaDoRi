/*
 * Copyright (C) 2011 GWVS mbH - All rights reserved.
 */
package de.gwvs.auswertungen.commons.security.dao.jdbc;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import de.gwvs.auswertungen.commons.security.dao.AuthenticationDao;

/**
 * Implementierung des Repository für Authentifizierungs- und Benutzerdaten
 * 
 * @author Ronny Krammer
 * @version 1.0
 * 
 */
public class AuthenticationDaoJdbc implements AuthenticationDao {

	/**
	 * {@link JdbcTemplate}
	 */
	private JdbcTemplate jdbcTemplate = null;

	/* (non-Javadoc)
	 * @see de.gwvs.auswertungen.commons.security.dao.AuthenticationDao#getUserData(java.lang.String)
	 */
	@Override
	public Map<String, Object> getUserData(String username) {
		final String sql = "SELECT be.be_adm AS adm, pe.pe_persnr AS persnr, spack_person.get_name(pe.pe_persnr, 'NUR_TITEL') AS titel, pe.pe_vorname AS vorname, pe.pe_nachname AS nachname, be.be_gesperrt AS gesperrt FROM benutzer be, personen pe WHERE be.be_persnr = pe.pe_persnr AND be.be_user = ?";
		try {
			return jdbcTemplate.queryForMap(sql, username.toUpperCase(Locale.GERMANY));
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}

	/**
	 * Setzt die DataSource
	 * 
	 * @param dataSource DataSource
	 */
	public void setDataSource(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Override
	public List<GrantedAuthority> getUserAuthorities(String username) {
		List<GrantedAuthority> grantedAuthorityList = new ArrayList<GrantedAuthority>();
		String sql = "SELECT mr_tos authority, NVL(bc_insert, 'N') bcinsert, NVL(bc_update, 'N') bcupdate, NVL(bc_delete, 'N') bcdelete, NVL(bc_zusatz, 'N') bczusatz FROM benutzerrechte_cache, menuerechte WHERE bc_rechtenr = mr_rechtenr AND bc_execute = 'J' AND mr_tos IS NOT NULL AND bc_user = ? UNION SELECT mr_tos authority, 'N' bcinsert, 'N' bcupdate, 'N' bcdelete, 'N' bczusatz FROM benutzerrechte_cache, menuerechte WHERE bc_rechtenr = mr_rechtenr AND mr_tos LIKE 'ROLE_%' AND mr_tos IS NOT NULL AND bc_user = ?";

		try {
			List<Map<String, Object>> authorities = jdbcTemplate.queryForList(sql, username.toUpperCase(Locale.GERMANY), username.toUpperCase(Locale.GERMANY));

			for (Map<String, Object> authorityMap : authorities) {
				String authority = String.valueOf(authorityMap.get("authority"));
				grantedAuthorityList.add(new SimpleGrantedAuthority(authority));
				if (!authority.startsWith("ROLE_")) {
					if ("J".equals(String.valueOf(authorityMap.get("bcinsert")))) {
						grantedAuthorityList.add(new SimpleGrantedAuthority(authority + "_INSERT"));
					}
					if ("J".equals(String.valueOf(authorityMap.get("bcupdate")))) {
						grantedAuthorityList.add(new SimpleGrantedAuthority(authority + "_UPDATE"));
					}
					if ("J".equals(String.valueOf(authorityMap.get("bcdelete")))) {
						grantedAuthorityList.add(new SimpleGrantedAuthority(authority + "_DELETE"));
					}
					if ("J".equals(String.valueOf(authorityMap.get("bczusatz")))) {
						grantedAuthorityList.add(new SimpleGrantedAuthority(authority + "_ZUSATZ"));
					}
				}
			}
			return grantedAuthorityList;
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}

}
