package de.gwvs.auswertungen.queries.web.validation;

import java.util.List;

import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import de.gwvs.auswertungen.queries.domain.BoundParameter;

/**
 * validator for parameters 
 * @author prieger
 * @version 1.0
 */
public class BoundVariableValidator implements Validator {

	@Override
	public boolean supports(final Class<?> clazz) {
		return clazz.equals(BoundParameterFormData.class);
	}

	/**
	 * validates a parameter
	 */
	@Override
	public void validate(final Object target, final Errors errors) {
		List<BoundParameter> boundVars = ((BoundParameterFormData) target).getBoundVariables();

		// validation
		boolean emptyField = false;
		if (boundVars != null) {
			for (BoundParameter var : boundVars) {
				if (!StringUtils.hasText(var.getValue())) {
					emptyField = true;
				}
				if ("Integer".equals(var.getParameter().getType())) {
					ValidatorUtils.rejectIfNotValidInteger(errors, var.getValue(), var.getParameter().getParameterLabel(), "invalid." + var.getParameter().getParameterLabel(), "Dieser Parameter muss eine ganze Zahl sein!");
				} else if ("Float".equals(var.getParameter())) {
					ValidatorUtils.rejectIfNotValidFloat(errors, var.getValue(), var.getParameter().getParameterLabel(), "invalid." + var.getParameter().getParameterLabel(), "Dieser Parameter muss eine Fließkommazahl sein!");
				} else if ("Text".equals(var.getParameter().getType())) {
					ValidatorUtils.rejectIfStringTooLong(errors, var.getValue(), var.getParameter().getParameterLabel(), "invalid." + var.getParameter().getParameterLabel(), "Die Eingabe für diesen Parameter ist zu lang!", 100);
				}
			}
		}
		if (emptyField) {
			errors.reject("", null, "Bitte füllen Sie alle Felder aus!");
		}
	}

}
