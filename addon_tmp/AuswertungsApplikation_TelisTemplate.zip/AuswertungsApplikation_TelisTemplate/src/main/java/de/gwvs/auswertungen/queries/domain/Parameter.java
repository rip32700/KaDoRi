package de.gwvs.auswertungen.queries.domain;

import java.util.List;

public class Parameter {

	private Long parameterId;
	private String parameterName;
	private String type;
	private String parameterLabel;
	private String erklaerung;
	private String standardwert;
	private List<String> listboxInhalt;
	private String regexMaske;
	private boolean isPflichtfeld;
	private String fehlertext;
	
	public Parameter() {
		
	}

	public Parameter(Long parameterId, String parameterName, String type, String parameterLabel, String erklaerung,
			String standardwert, List<String> listboxInhalt, String regexMaske, boolean isPflichtfeld, String fehlertext) {
		super();
		this.parameterId = parameterId;
		this.parameterName = parameterName;
		this.type = type;
		this.parameterLabel = parameterLabel;
		this.erklaerung = erklaerung;
		this.standardwert = standardwert;
		this.listboxInhalt = listboxInhalt;
		this.regexMaske = regexMaske;
		this.isPflichtfeld = isPflichtfeld;
		this.fehlertext = fehlertext;
	}

	public Long getParameterId() {
		return parameterId;
	}

	public void setParameterId(Long parameterId) {
		this.parameterId = parameterId;
	}

	public String getParameterName() {
		return parameterName;
	}

	public void setParameterName(String parameterName) {
		this.parameterName = parameterName;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getParameterLabel() {
		return parameterLabel;
	}

	public void setParameterLabel(String parameterLabel) {
		this.parameterLabel = parameterLabel;
	}

	public String getErklaerung() {
		return erklaerung;
	}

	public void setErklaerung(String erklaerung) {
		this.erklaerung = erklaerung;
	}

	public String getStandardwert() {
		return standardwert;
	}

	public void setStandardwert(String standardwert) {
		this.standardwert = standardwert;
	}

	public List<String> getListboxInhalt() {
		return listboxInhalt;
	}

	public void setListboxInhalt(List<String> listboxInhalt) {
		this.listboxInhalt = listboxInhalt;
	}

	public String getRegexMaske() {
		return regexMaske;
	}

	public void setRegexMaske(String regexMaske) {
		this.regexMaske = regexMaske;
	}

	public boolean isPflichtfeld() {
		return isPflichtfeld;
	}

	public void setPflichtfeld(boolean isPflichtfeld) {
		this.isPflichtfeld = isPflichtfeld;
	}

	public String getFehlertext() {
		return fehlertext;
	}

	public void setFehlertext(String fehlertext) {
		this.fehlertext = fehlertext;
	}

	@Override
	public String toString() {
		return "Parameter [parameterId=" + parameterId + ", parameterName=" + parameterName + ", type=" + type
				+ ", parameterLabel=" + parameterLabel + ", erklaerung=" + erklaerung + ", standardwert=" + standardwert
				+ ", listboxInhalt=" + listboxInhalt + ", regexMaske=" + regexMaske + ", isPflichtfeld=" + isPflichtfeld
				+ ", fehlertext=" + fehlertext + "]";
	}
	
}
