/*
 * Copyright (C) 2009 GWVS mbH - All rights reserved.
 */
package de.gwvs.auswertungen.commons.security.service.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.SpringSecurityMessageSource;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.util.CollectionUtils;

import de.gwvs.auswertungen.commons.security.dao.AuthenticationDao;
import de.gwvs.auswertungen.commons.security.domain.AuswertungenUser;
import de.gwvs.auswertungen.commons.security.exception.NoAccessException;
import de.gwvs.auswertungen.commons.security.service.AuthenticationService;
import de.gwvs.commons.tos.utils.MapEntryValueUtils;

/**
 * Serivce für Authentifizierungs- und Benutzerdaten
 * 
 * @author Ronny Krammer
 * @version 1.0
 * 
 */
public class AuthenticationServiceImpl implements AuthenticationService {

	/**
	 * {@link Logger}
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(AuthenticationServiceImpl.class);
	
	/**
	 * Liste mit loginberechtigten Rollen
	 */
	private List<GrantedAuthority> allowedAuthorities = null;

	/**
	 * {@link AuthenticationDao}
	 */
	private AuthenticationDao authenticationDao = null;

	/**
	 * {@link MessageSourceAccessor}
	 */
	private MessageSourceAccessor messages = SpringSecurityMessageSource.getAccessor();
	
	/* (non-Javadoc)
	 * @see de.gwvs.auswertungen.commons.security.service.AuthenticationService#getAuswertungenUserFromUserDetails(org.springframework.security.core.userdetails.UserDetails, java.lang.String)
	 */
	@Override
	public AuswertungenUser getAuswertungenUserFromUserDetails(UserDetails userDetails, String password) {
		String username = userDetails.getUsername().toLowerCase(Locale.GERMANY);

		Set<GrantedAuthority> dbAuthsSet = new HashSet<GrantedAuthority>();
		dbAuthsSet.addAll(authenticationDao.getUserAuthorities(username));
		dbAuthsSet.addAll(userDetails.getAuthorities());
		
		if (!CollectionUtils.isEmpty(allowedAuthorities) && !CollectionUtils.containsAny(allowedAuthorities, dbAuthsSet)) {
			throw new NoAccessException("Sie sind nicht für diese Anwendung freigeschalten!");
		}

		// Ladt die Benutzerdaten aus der Datenbank und setzt Sie in einem AuswertungenUser

		Map<String, Object> userMap = authenticationDao.getUserData(username);
		if (userMap == null) {
			LOGGER.warn("User account no data found " + username);
			throw new NoAccessException("Sie sind nicht für diese Anwendung freigeschalten!");
		}
		long adm = MapEntryValueUtils.getLong(userMap, "adm");

		boolean accountNonLocked = false;
		if (userDetails.isAccountNonLocked() || userMap.get("gesperrt") != null) {
			accountNonLocked = true;
		}

		AuswertungenUser auswertungenUser = new AuswertungenUser(username, password, userDetails.isEnabled(), userDetails.isAccountNonExpired(), userDetails.isCredentialsNonExpired(), accountNonLocked, dbAuthsSet);
		auswertungenUser.setAdm(adm);
		auswertungenUser.setPersnr(MapEntryValueUtils.getLong(userMap, "persnr"));
		auswertungenUser.setAkademischerTitel(MapEntryValueUtils.getString(userMap, "titel"));
		auswertungenUser.setVorname(MapEntryValueUtils.getString(userMap, "vorname"));
		auswertungenUser.setNachname(MapEntryValueUtils.getString(userMap, "nachname"));

		if (!auswertungenUser.isAccountNonExpired()) {
			LOGGER.warn("User account has expired " + username);
			throw new BadCredentialsException(messages.getMessage("AbstractUserDetailsAuthenticationProvider.expired", "User account has expired"));
		}
		if (!auswertungenUser.isAccountNonLocked()) {
			LOGGER.warn("User account is locked " + username);
			throw new BadCredentialsException(messages.getMessage("AbstractUserDetailsAuthenticationProvider.locked", "User account is locked"));
		}

		return auswertungenUser;
	}

	/**
	 * Setzt eine Liste mit loginberechtigten Rollen
	 * 
	 * @param allowedAuthorities Liste mit loginberechtigten Rollen
	 */
	@Resource(name = "allowedAuthorities")
	public void setAllowedAuthorities(List<String> allowedAuthorities) {
		if (!CollectionUtils.isEmpty(allowedAuthorities)) {
			List<GrantedAuthority> grantedAuthorities = new ArrayList<GrantedAuthority>();
			for (String role : allowedAuthorities) {
				grantedAuthorities.add(new SimpleGrantedAuthority(role));
			}
			this.allowedAuthorities = grantedAuthorities;
		}
	}

	/**
	 * {@link AuthenticationDao}
	 * 
	 * @param authenticationDao {@link AuthenticationDao}
	 */
	public void setAuthenticationDao(AuthenticationDao authenticationDao) {
		this.authenticationDao = authenticationDao;
	}

}
