/*
 * Copyright (C) 2011 GWVS mbH - All rights reserved.
 */
package de.gwvs.auswertungen.commons.security.domain;

import java.io.Serializable;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import org.springframework.security.core.CredentialsContainer;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.SpringSecurityCoreVersion;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.util.Assert;

import de.gwvs.commons.tos.security.userdetails.TosUserDetails;

/**
 * {@link UserDetails} für die Auswertungen
 * 
 * @author Ronny Krammer
 * @version 1.0
 * 
 */
public class AuswertungenUser implements TosUserDetails, CredentialsContainer {

	private static class AuthorityComparator implements Comparator<GrantedAuthority>, Serializable {

		private static final long serialVersionUID = SpringSecurityCoreVersion.SERIAL_VERSION_UID;

		public int compare(GrantedAuthority g1, GrantedAuthority g2) {
			// Neither should ever be null as each entry is checked before
			// adding it to the set.
			// If the authority is null, it is a custom authority and should
			// precede others.
			if (g2.getAuthority() == null) {
				return -1;
			}

			if (g1.getAuthority() == null) {
				return 1;
			}

			return g1.getAuthority().compareTo(g2.getAuthority());
		}
	}

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -7153618302560343656L;

	private static SortedSet<GrantedAuthority> sortAuthorities(Collection<? extends GrantedAuthority> authorities) {
		Assert.notNull(authorities, "Cannot pass a null GrantedAuthority collection");
		// Ensure array iteration order is predictable (as per
		// UserDetails.getAuthorities() contract and SEC-717)
		SortedSet<GrantedAuthority> sortedAuthorities = new TreeSet<GrantedAuthority>(new AuthorityComparator());

		for (GrantedAuthority grantedAuthority : authorities) {
			Assert.notNull(grantedAuthority, "GrantedAuthority list cannot contain any null elements");
			sortedAuthorities.add(grantedAuthority);
		}

		return sortedAuthorities;
	}

	private final boolean accountNonExpired;

	private final boolean accountNonLocked;

	private long adm;

	private String akademischerTitel = "";

	private final Set<GrantedAuthority> authorities;

	private final boolean credentialsNonExpired;

	private final boolean enabled;

	private String nachname = "";

	private String password;

	private long persnr;

	private final String username;

	private String vorname = "";

	/**
	 * Construct the <code>User</code> with the details required by {@link org.springframework.security.authentication.dao.DaoAuthenticationProvider} .
	 * 
	 * @param username the username presented to the <code>DaoAuthenticationProvider</code>
	 * @param password the password that should be presented to the <code>DaoAuthenticationProvider</code>
	 * @param enabled set to <code>true</code> if the user is enabled
	 * @param accountNonExpired set to <code>true</code> if the account has not expired
	 * @param credentialsNonExpired set to <code>true</code> if the credentials have not expired
	 * @param accountNonLocked set to <code>true</code> if the account is not locked
	 * @param authorities the authorities that should be granted to the caller if they presented the correct username and password and the user is enabled. Not null.
	 * 
	 * @throws IllegalArgumentException if a <code>null</code> value was passed either as a parameter or as an element in the <code>GrantedAuthority</code> collection
	 */
	public AuswertungenUser(String username, String password, boolean enabled, boolean accountNonExpired, boolean credentialsNonExpired, boolean accountNonLocked, Collection<? extends GrantedAuthority> authorities) {

		if (((username == null) || "".equals(username)) || (password == null)) {
			throw new IllegalArgumentException("Cannot pass null or empty values to constructor");
		}

		this.username = username;
		this.password = password;
		this.enabled = enabled;
		this.accountNonExpired = accountNonExpired;
		this.credentialsNonExpired = credentialsNonExpired;
		this.accountNonLocked = accountNonLocked;
		this.authorities = Collections.unmodifiableSet(sortAuthorities(authorities));
	}

	/**
	 * Returns {@code true} if the supplied object is a {@code User} instance with the same {@code username} value.
	 * <p>
	 * In other words, the objects are equal if they have the same username, representing the same principal.
	 */
	@Override
	public boolean equals(Object rhs) {
		if (rhs instanceof AuswertungenUser) {
			return username.equals(((AuswertungenUser) rhs).username);
		}
		return false;
	}

	public void eraseCredentials() {
		password = null;
	}

	public long getAdm() {
		return adm;
	}

	public String getAkademischerTitel() {
		return akademischerTitel;
	}

	public Collection<GrantedAuthority> getAuthorities() {
		return authorities;
	}

	public String getFullname() {
		StringBuilder fullname = new StringBuilder();
		if (!"".equals(akademischerTitel)) {
			fullname.append(akademischerTitel).append(" ");
		}
		if (!"".equals(vorname)) {
			fullname.append(vorname).append(" ");
		}
		if (!"".equals(nachname)) {
			fullname.append(nachname);
		}
		return fullname.toString();
	}

	public String getNachname() {
		return nachname;
	}

	public String getPassword() {
		return password;
	}

	public long getPersnr() {
		return persnr;
	}

	/* (non-Javadoc)
	 * @see de.gwvs.commons.tos.security.userdetails.TosUserDetails#getStaffToken()
	 */
	@Override
	public String getStaffToken() {
		return "MA";
	}

	public String getUsername() {
		return username;
	}

	public String getVorname() {
		return vorname;
	}

	// ~ Methods
	// ========================================================================================================

	/**
	 * Hat der Benutzer die Berechtigung
	 * 
	 * @param authority Authority
	 * @return Hat der Benutzer die Berechtigung
	 */
	public boolean hasAuthority(String authority) {
		boolean hasAuth = false;
		for (GrantedAuthority auth : authorities) {
			if (auth.getAuthority().equals(authority)) {
				hasAuth = true;
				break;
			}
		}
		return hasAuth;
	}

	/**
	 * Returns the hashcode of the {@code username}.
	 */
	@Override
	public int hashCode() {
		return username.hashCode();
	}

	public boolean isAccountNonExpired() {
		return accountNonExpired;
	}

	public boolean isAccountNonLocked() {
		return accountNonLocked;
	}

	public boolean isCredentialsNonExpired() {
		return credentialsNonExpired;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setAdm(long adm) {
		this.adm = adm;
	}

	public void setAkademischerTitel(String akademischerTitel) {
		this.akademischerTitel = akademischerTitel;
	}

	public void setNachname(String nachname) {
		this.nachname = nachname;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setPersnr(long persnr) {
		this.persnr = persnr;
	}

	public void setVorname(String vorname) {
		this.vorname = vorname;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(super.toString()).append(": ");
		sb.append("Username: ").append(this.username).append("; ");
		sb.append("Password: [PROTECTED]; ");
		sb.append("Enabled: ").append(this.enabled).append("; ");
		sb.append("AccountNonExpired: ").append(this.accountNonExpired).append("; ");
		sb.append("credentialsNonExpired: ").append(this.credentialsNonExpired).append("; ");
		sb.append("AccountNonLocked: ").append(this.accountNonLocked).append("; ");
		sb.append("ADM: ").append(this.adm).append("; ");
		sb.append("Persnr: ").append(this.persnr).append("; ");
		sb.append("Akademischer Titel: ").append(this.akademischerTitel).append("; ");
		sb.append("Vorname: ").append(this.vorname).append("; ");
		sb.append("Nachname: ").append(this.nachname).append("; ");

		if (!authorities.isEmpty()) {
			sb.append("Granted Authorities: ");

			boolean first = true;
			for (GrantedAuthority auth : authorities) {
				if (!first) {
					sb.append(",");
				}
				first = false;

				sb.append(auth);
			}
		} else {
			sb.append("Not granted any authorities");
		}

		return sb.toString();
	}
}