/*
 * Copyright (C) 2011 GWVS mbH - All rights reserved.
 */
package de.gwvs.auswertungen.commons.security.dao;

import java.util.List;
import java.util.Map;

import org.springframework.security.core.GrantedAuthority;

/**
 * Repository für Authentifizierungs- und Benutzerdaten
 * 
 * @author Ronny Krammer
 * @version 1.0
 * 
 */
public interface AuthenticationDao {

	/**
	 * Gibt die Liste mit den {@link GrantedAuthority} zurück
	 * 
	 * @param username Benutzername
	 * @return {@link GrantedAuthority} List
	 */
	List<GrantedAuthority> getUserAuthorities(String username);
	
	/**
	 * Gibt eine Map mit den Benutzer und Authenifizierungsdaten zurück
	 * 
	 * @param username Benutzername
	 * @return Map mit den Benutzer und Authenifizierungsdaten
	 */
	Map<String, Object> getUserData(String username);

}
