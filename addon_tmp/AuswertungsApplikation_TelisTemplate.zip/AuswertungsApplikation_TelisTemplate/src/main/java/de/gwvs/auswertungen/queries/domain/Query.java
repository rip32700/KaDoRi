package de.gwvs.auswertungen.queries.domain;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;

/**
 * Domain object for a query
 * @author prieger
 * @version 1.0
 */
public class Query {

	private Long queryId;
	private String text;
	private String art;
	@DateTimeFormat(pattern = "dd.MM.yyyy")
	private LocalDate erstellt;
	private String bereich;
	private String sql;
	private String beschreibung;
	private String authority;
	private boolean isDisabled;

	/**
	 * default constructor
	 */
	public Query() {
	
	}
	
	/**
	 * constructor without property 'beschreibung'
	 * @param queryId the query ID
	 * @param text title of the query
	 * @param art query Art
	 * @param benutzer user of the query
	 * @param erstellt date of creation
	 * @param bereich domain of the query
	 * @param sql the query's SQL statement
	 */
	public Query(final Long queryId, final String text, final String art, final LocalDate erstellt, final String bereich, final String sql, final String authority, final boolean isDisabled) {
		super();
		this.queryId = queryId;
		this.text = text;
		this.art = art;
		this.erstellt = erstellt;
		this.bereich = bereich;
		this.sql = sql;
		this.authority = authority;
		this.setDisabled(isDisabled);
	}
	
	/**
	 * constructor with property 'beschreibung'(used for insertion)
	 * @param queryId the query ID
	 * @param text title of the query
	 * @param beschreibung description of the query
	 * @param art query Art
	 * @param benutzer user of the query
	 * @param erstellt date of creation
	 * @param bereich domain of the query
	 * @param sql the query's SQL statement
	 */
	public Query(final Long queryId, final String text, final String beschreibung, final String art, final LocalDate erstellt, final String bereich, final String sql,  final String authority, final boolean isDisabled) {
		super();
		this.queryId = queryId;
		this.text = text;
		this.beschreibung = beschreibung;
		this.art = art;
		this.erstellt = erstellt;
		this.bereich = bereich;
		this.sql = sql;
		this.authority = authority;
		this.setDisabled(isDisabled);
	}
	
	/**
	 * returns the query ID
	 * @return query ID
	 */
	public Long getQueryId() {
		return queryId;
	}
	
	/**
	 * sets the query ID
	 * @param queryId the new query ID
	 */
	public void setQueryId(final Long queryId) {
		this.queryId = queryId;
	}
	
	/**
	 * returns the text value
	 * @return the query's title
	 */
	public String getText() {
		return text;
	}
	
	/**
	 * sets the text value
	 * @param text the new query title
	 */
	public void setText(String text) {
		this.text = text;
	}
	
	/**
	 * returns the art property
	 * @return query Art
	 */
	public String getArt() {
		return art;
	}
	
	/**
	 * sets the art property
	 * @param art new query Art
	 */
	public void setArt(String art) {
		this.art = art;
	}
	
	/**
	 * returns the erstellt date
	 * @return creation date
	 */
	public LocalDate getErstellt() {
		return erstellt;
	}
	
	/**
	 * sets the erstellt date
	 * @param erstellt new creation date
	 */
	public void setErstellt(LocalDate erstellt) {
		this.erstellt = erstellt;
	}
	
	/**
	 * returns the bereich property
	 * @return domain name
	 */
	public String getBereich() {
		return bereich;
	}
	
	/**
	 * sets the bereich property
	 * @param bereich new domain name
	 */
	public void setBereich(String bereich) {
		this.bereich = bereich;
	}
	
	/**
	 * returns the SQL statement
	 * @return SQL statement
	 */
	public String getSql() {
		return sql;
	}
	
	/**
	 * sets the SQL statement
	 * @param sql new SQL statement
	 */
	public void setSql(String sql) {
		this.sql = sql;
	}
	
	/**
	 * returns the beschreibung property
	 * @return description
	 */
	public String getBeschreibung() {
		return beschreibung;
	}
	
	/**
	 * sets the beschreibung property
	 * @param beschreibung new description
	 */
	public void setBeschreibung(String beschreibung) {
		this.beschreibung = beschreibung;
	}
	
	/**
	 *
	 * @return the authority
	 */
	public String getAuthority() {
		return authority;
	}

	/**
	 * @param authority the authority to set
	 */
	public void setAuthority(String authority) {
		this.authority = authority;
	}
	
	public boolean isDisabled() {
		return isDisabled;
	}

	public void setDisabled(boolean isDisabled) {
		this.isDisabled = isDisabled;
	}

	/**
	 * prints out the query
	 */
	
	@Override
	public String toString() {
		return "Query [queryId=" + queryId + ", text=" + text + ", art=" + art
				+ ", erstellt=" + erstellt + ", bereich=" + bereich + ", sql=" + sql + ", beschreibung=" + beschreibung
				+ ", authority=" + authority + "]";
	}
	
}
