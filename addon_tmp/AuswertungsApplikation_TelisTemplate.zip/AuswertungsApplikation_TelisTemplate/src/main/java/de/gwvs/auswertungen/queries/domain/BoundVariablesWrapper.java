package de.gwvs.auswertungen.queries.domain;

import java.util.List;

/**
 * wrapper object for bound variables of a query
 * used for representation in the view (set into the model by constroller)
 * @author prieger
 * @version 1.0
 */
public class BoundVariablesWrapper {

	private Long queryId;
	private List<BoundVariable> variableList;

	/**
	 * returns the query ID
	 * @return
	 */
	public Long getQueryId() {
		return queryId;
	}
	
	/**
	 * sets the query ID
	 * @param queryId
	 */
	public void setQueryId(Long queryId) {
		this.queryId = queryId;
	}
	
	/**
	 * returns all bound variables (list)
	 * @return
	 */
	public List<BoundVariable> getVariableList() {
		return variableList;
	}

	/**
	 * sets bound variables (list)
	 * @param variableList
	 */
	public void setVariableList(List<BoundVariable> variableList) {
		this.variableList = variableList;
	}
	
}
