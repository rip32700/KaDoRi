package de.gwvs.auswertungen.commons.security.permissions;

import java.io.Serializable;

import org.springframework.security.access.PermissionEvaluator;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;

import de.gwvs.auswertungen.queries.domain.Query;

public class QueryPermissionEvaluator implements PermissionEvaluator {

	@Override
	public boolean hasPermission(Authentication authentication, Object targetDomainObject, Object permission) {
		boolean hasPermission = false;
		if(authentication != null && targetDomainObject != null && targetDomainObject instanceof Query) {
			Query query = (Query) targetDomainObject;
			for(GrantedAuthority authority : authentication.getAuthorities()) {
				// check for same authority
				if(query.getAuthority().equals(authority.getAuthority())) {
					hasPermission = true;
				}
			}
		}
		return hasPermission;
	}

	@Override
	public boolean hasPermission(Authentication authentication, Serializable targetId, String targetType, Object permission) {
		return false;
	}

}
