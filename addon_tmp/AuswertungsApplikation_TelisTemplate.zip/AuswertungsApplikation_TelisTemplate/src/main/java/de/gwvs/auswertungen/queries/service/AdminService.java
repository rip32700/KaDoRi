package de.gwvs.auswertungen.queries.service;

import java.util.List;

import de.gwvs.auswertungen.queries.domain.Parameter;
import de.gwvs.auswertungen.queries.domain.Query;
import de.gwvs.auswertungen.queries.exceptions.DuplicateIdException;

/**
 * interface for admin service
 * @author prieger
 * @version 1.0
 */
public interface AdminService {

	public void insertQuery(final Query query) throws DuplicateIdException;
	public List<Long> getAllQueryIds();
	public Query getQuery(Long queryId);
	public List<Parameter> getAllParameters();
	public Parameter getParameterById(Long parameterId);
	public boolean updateQuery(Query query);
	public List<Query> getAllQueriesForAdmin();
	public List<String> getBereicheList(List<Query> queries);
	public List<String> getErstelltList(List<Query> queries);
	public List<String> getTypeList(List<Parameter> parameters);
	public boolean updateParameter(Parameter parameter);
	public void insertParameter(Parameter parameter);
	
}
