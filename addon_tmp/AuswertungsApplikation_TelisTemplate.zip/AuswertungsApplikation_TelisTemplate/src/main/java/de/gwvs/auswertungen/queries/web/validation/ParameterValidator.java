package de.gwvs.auswertungen.queries.web.validation;

import org.springframework.util.StringUtils;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

public class ParameterValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		return clazz.equals(ParameterFormData.class);
	}

	@Override
	public void validate(Object target, Errors errors) {
		ParameterFormData formData = (ParameterFormData) target;
		
		// validation
		if(!StringUtils.hasText(formData.getParameterId()) || !StringUtils.hasText(formData.getParameterName()) || !StringUtils.hasText(formData.getType()) 
				|| !StringUtils.hasText(formData.getParameterLabel()) || !StringUtils.hasText(formData.getErklaerung()) || !StringUtils.hasText(formData.getStandardwert()) 
				|| !StringUtils.hasText(formData.getListboxInhalt()) || !StringUtils.hasText(formData.getRegexMaske())
				|| !StringUtils.hasText(formData.getFehlertext())) {
			errors.reject("", null, "Bitte füllen Sie alle Felder aus!");
		} else {
			ValidatorUtils.rejectIfNotValidLong(errors, formData.getParameterId(), "parameterId", "invalid.parameterId", "Die Parameter ID muss eine Zahl sein!", 1L, 99999999L, "invalid.parameterId.range", "Parameter ID: Keine gültige Parameter ID!");
			ValidatorUtils.rejectIfStringNotInRange(errors, formData.getParameterName(), "parameterName", "invalid.parameterName", "Parametername: Kein gültiger Parametername!", 5, 30);
			ValidatorUtils.rejectIfStringNotInRange(errors, formData.getType(), "type", "invalid.type", "Typ: Kein gültiger Typ!", 1, 30);
			ValidatorUtils.rejectIfStringNotInRange(errors, formData.getParameterLabel(), "parameterLabel", "invalid.parameterLabel", "Label: Kein gültiges Label!", 5, 30);
			ValidatorUtils.rejectIfStringNotInRange(errors, formData.getErklaerung(), "erklaerung", "invalid.erklaerung", "Erklärung: Keine gültige Erklärung!", 5, 200);
			ValidatorUtils.rejectIfStringNotInRange(errors, formData.getStandardwert(), "standardwert", "invalid.standardwert", "Standardwert: Kein gültiger Standardwert!", 1, 200);
			ValidatorUtils.rejectIfStringNotInRange(errors, formData.getListboxInhalt(), "listboxInhalt", "invalid.listboxInhalt", "Listbox Inhalt: Kein gültiger Listbox-Inhalt!", 10, 1000);
			ValidatorUtils.rejectIfStringNotInRange(errors, formData.getRegexMaske(), "regexMaske", "invalid.regexMaske", "Regex-Maske: Keine gültige Regex-Maske!", 2, 100);
			ValidatorUtils.rejectIfStringNotInRange(errors, formData.getFehlertext(), "fehlertext", "invalid.fehlertext", "Fehlertext: Kein gültiger Fehlertext!", 5, 300);
		}
		
	}

}

