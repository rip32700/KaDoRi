/*
 * Copyright (C) 2015 GWVS mbH - All rights reserved.
 */
package de.gwvs.auswertungen.commons.web.servlet;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;

import org.springframework.core.annotation.Order;
import org.springframework.web.WebApplicationInitializer;

import net.jawr.web.JawrConstant;
import net.jawr.web.servlet.JawrServlet;

/**
 * Implements an {@link WebApplicationInitializer} for Jawr
 * 
 * @author Ronny Krammer
 * @version 1.0
 * 
 */
@Order(3)
public class JawrInitializer implements WebApplicationInitializer {

	/* (non-Javadoc)
	 * @see org.springframework.web.WebApplicationInitializer#onStartup(javax.servlet.ServletContext)
	 */
	@Override
	public void onStartup(ServletContext servletContext) throws ServletException {
		ServletRegistration.Dynamic registration = servletContext.addServlet("CssServlet", new JawrServlet());
		registration.setInitParameter("configLocation", "/jawr.properties");
		registration.setInitParameter("mapping", "/styles/");
		registration.setInitParameter("type", JawrConstant.CSS_TYPE);
		registration.setLoadOnStartup(3);
		registration.addMapping("/styles/*");
	}
}
