/*
 * Copyright (C) 2015 GWVS mbH - All rights reserved.
 */
package de.gwvs.auswertungen.commons.web.config;

import java.util.ArrayList;
import java.util.List;

import org.jasypt.encryption.StringEncryptor;
import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.jasypt.encryption.pbe.config.EnvironmentStringPBEConfig;
import org.jasypt.spring31.properties.EncryptablePropertyPlaceholderConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Profile;
import org.springframework.context.support.MessageSourceSupport;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.core.io.ClassPathResource;
import org.springframework.util.StringUtils;

/**
 * Root {@link Configuration}
 * 
 * @author Ronny Krammer
 * @version 1.0
 * 
 */
@Import(value = { InfrastructureConfig.class, SecurityConfig.class, WebMvcConfig.class })
@Configuration
public class RootConfig {

	/**
	 * Encoder Password
	 */
	private static final String ENC_PASSWORD = "teamt0ss0tmeat";

	/**
	 * Filename of configuration
	 */
	private static final String FILENAME_PROPERTIES = "auswertungen";

	/**
	 * Erzeugt einen {@link EncryptablePropertyPlaceholderConfigurer}
	 * 
	 * @param profile Profile
	 * @param order Sortierung
	 * @return {@link EncryptablePropertyPlaceholderConfigurer}
	 */
	private static EncryptablePropertyPlaceholderConfigurer buildEncryptablePropertyPlaceholderConfigurer(String profile, int order) {
		EncryptablePropertyPlaceholderConfigurer placeholderConfigurer = new EncryptablePropertyPlaceholderConfigurer(stringEncryptor());
		if (StringUtils.hasText(profile)) {
			placeholderConfigurer.setLocations(new ClassPathResource(RootConfig.FILENAME_PROPERTIES + ".properties"), new ClassPathResource(RootConfig.FILENAME_PROPERTIES + "-" + profile + ".properties"));
		} else {
			placeholderConfigurer.setLocations(new ClassPathResource(RootConfig.FILENAME_PROPERTIES + ".properties"));
		}
		placeholderConfigurer.setIgnoreResourceNotFound(true);
		placeholderConfigurer.setOrder(order);
		return placeholderConfigurer;
	}

	/**
	 * Erzeugt einen {@link EncryptablePropertyPlaceholderConfigurer}
	 * 
	 * @return {@link EncryptablePropertyPlaceholderConfigurer}
	 */
	@Bean
	public static EncryptablePropertyPlaceholderConfigurer propertyConfigurer() {
		return buildEncryptablePropertyPlaceholderConfigurer("", 20);
	}

	/**
	 * Erzeugt einen {@link EncryptablePropertyPlaceholderConfigurer} im Profil DEVWIN
	 * 
	 * @return {@link EncryptablePropertyPlaceholderConfigurer}
	 */
	@Profile("DEVWIN")
	@Bean
	public static EncryptablePropertyPlaceholderConfigurer propertyConfigurerDevWin() {
		return buildEncryptablePropertyPlaceholderConfigurer("DEVWIN", 11);
	}

	/**
	 * Erzeugt einen {@link EncryptablePropertyPlaceholderConfigurer} im Profil PROD
	 * 
	 * @return {@link EncryptablePropertyPlaceholderConfigurer}
	 */
	@Profile("PROD")
	@Bean
	public static EncryptablePropertyPlaceholderConfigurer propertyConfigurerProd() {
		return buildEncryptablePropertyPlaceholderConfigurer("PROD", 10);
	}

	/**
	 * Init {@link StringEncryptor}
	 * 
	 * @return {@link StringEncryptor}
	 */
	@Bean
	public static StringEncryptor stringEncryptor() {
		EnvironmentStringPBEConfig pbeConfig = new EnvironmentStringPBEConfig();
		pbeConfig.setAlgorithm("PBEWithMD5AndDES");
		pbeConfig.setPassword(ENC_PASSWORD);
		StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
		encryptor.setConfig(pbeConfig);
		return encryptor;
	}

	/**
	 * Liste ausgeschlossener Links
	 * 
	 * @return {@link List}
	 */
	@Bean(name = "excludedLinks")
	public List<String> excludedLinks() {
		List<String> excludedLinks = new ArrayList<>();
		excludedLinks.add("/impressum");
		excludedLinks.add("/resources/*");
		return excludedLinks;
	}

	/**
	 * Erzeugt eine {@link ReloadableResourceBundleMessageSource}
	 * 
	 * @return {@link MessageSourceSupport}
	 */
	@Bean(name = "messageSource")
	public MessageSourceSupport messageSourceSupport() {
		ReloadableResourceBundleMessageSource messageSource = new ReloadableResourceBundleMessageSource();
		messageSource.setBasename("classpath:org/springframework/security/messages");
		return messageSource;
	}

}
