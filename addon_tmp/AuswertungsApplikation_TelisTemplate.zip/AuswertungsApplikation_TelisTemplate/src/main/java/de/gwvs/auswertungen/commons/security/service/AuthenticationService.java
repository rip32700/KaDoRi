/*
 * Copyright (C) 2009 GWVS mbH - All rights reserved.
 */
package de.gwvs.auswertungen.commons.security.service;

import org.springframework.security.core.userdetails.UserDetails;

import de.gwvs.auswertungen.commons.security.domain.AuswertungenUser;

/**
 * Serivce für Authentifizierungs- und Benutzerdaten
 * 
 * @author Ronny Krammer
 * @version 1.0
 * 
 */
public interface AuthenticationService {

	/**
	 * Erzeugt aus den {@link UserDetails} einen {@link AuswertungenUser}
	 * 
	 * @param userDetails {@link UserDetails}
	 * @param password Passwort
	 * @return {@link UserDetails}
	 */
	AuswertungenUser getAuswertungenUserFromUserDetails(UserDetails userDetails, String password);

}
