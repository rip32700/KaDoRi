package de.gwvs.auswertungen.queries.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.springframework.jdbc.core.namedparam.NamedParameterJdbcOperations;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import de.gwvs.auswertungen.queries.dao.ParameterDao;
import de.gwvs.auswertungen.queries.domain.Parameter;
import de.gwvs.auswertungen.queries.utils.RowMapperUtils;

@Repository
public class ParameterDaoImpl implements ParameterDao {

	private final static String FIND_PARAMETER_BY_ID   = "SELECT * FROM au_parameter WHERE au_pid = :pid";
	private final static String FIND_PARAMETER_BY_NAME = "SELECT * FROM au_parameter WHERE au_parametername = :name";
	private final static String FIND_ALL_PARAMETERS    = "SELECT * FROM au_parameter";
	private final static String FIND_ALL_IDS 		   = "SELECT au_pid FROM au_parameter";
	private final static String UPDATE_PARAMETER       = "UPDATE au_parameter SET au_pid = :pid, au_parametername = :parameterName, au_typ = :type, au_erklaerung = :erklaerung, au_standardwert = :standardwert, au_listbox_inhalt = :listboxInhalt, au_maske_regex = :regexMaske, au_pflichtfeld = :isPflichtfeld, au_fehlertext = :fehlerText WHERE au_pid = :pid";
	private final static String INSERT_PARAMETER       = "INSERT INTO au_parameter VALUES (:pid, :parameterName, :type, :parameterLabel, :erklaerung, :standardwert, :listboxInhalt, :regexMaske, :isPflichtfeld, :fehlerText)";
	private final static String DELETE_PARAMETER_BY_ID = "DROP TABLE au_parameter WHERE au_pid = :pid";
	
	/**
	 * JDBC operations object for the configured database access
	 */
	private NamedParameterJdbcOperations jdbcOperations;

	/**
	 * Sets the JDBC operations object with the configured data source
	 * @param dataSource
	 */
	@Resource(name = "dataSource")
	public void setDataSource(DataSource dataSource) {
		jdbcOperations = new NamedParameterJdbcTemplate(dataSource);
	}
	
	@Override
	public Parameter findParameterById(Long parameterId) {
		return jdbcOperations.getJdbcOperations().queryForObject(FIND_PARAMETER_BY_ID, this::mapParameter, parameterId);
	}

	@Override
	public List<Parameter> findAllParameters() {
		return jdbcOperations.getJdbcOperations().query(FIND_ALL_PARAMETERS, this::mapParameter);
	}
	

	@Override
	public List<Long> findAllIds() {
		return jdbcOperations.getJdbcOperations().query(FIND_ALL_IDS, this::mapParameterId);
	}
	
	@Override
	public Parameter findParameterByName(String name) {
		return jdbcOperations.getJdbcOperations().queryForObject(FIND_PARAMETER_BY_NAME, this::mapParameter, name);
	}

	@Override
	public boolean updateParameter(Parameter parameter) {
		jdbcOperations.update(UPDATE_PARAMETER, buildUpsertMap(parameter));
		return true;
	}

	@Override
	public boolean insertParameter(Parameter parameter) {
		jdbcOperations.update(INSERT_PARAMETER, buildUpsertMap(parameter));
		return true;
	}

	@Override
	public boolean deleteParameterById(Long parameterId) {
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("pid", parameterId);
		jdbcOperations.update(DELETE_PARAMETER_BY_ID, paramMap);
		return true;
	}

	@Override
	public boolean deleteParameter(Parameter parameter) {
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("pid", parameter.getParameterId());
		jdbcOperations.update(DELETE_PARAMETER_BY_ID, paramMap);
		return true;
	}
	
	// MAPPER METHODS
	
	private Parameter mapParameter(final ResultSet rs, final int rowNum) throws SQLException {
		return new Parameter(
					RowMapperUtils.getLong(rs, "AU_PID", 0L),
					RowMapperUtils.getString(rs, "AU_PARAMETERNAME", ""),
					RowMapperUtils.getString(rs, "AU_TYP", ""),
					RowMapperUtils.getString(rs, "AU_PARAMETERLABEL", ""),
					RowMapperUtils.getString(rs, "AU_ERKLAERUNG", ""),
					getStandardwert(rs),
					getListBoxContent(rs),
					RowMapperUtils.getString(rs, "AU_MASKE_REGEX", ""),
					RowMapperUtils.getBoolean(rs, "AU_PFLICHTFELD", true),
					RowMapperUtils.getString(rs, "AU_FEHLERTEXT", "")
				);
	}

	private String getStandardwert(ResultSet rs) throws SQLException {
		String standardwertValue = RowMapperUtils.getString(rs, "AU_STANDARDWERT", "");
		if(!StringUtils.isEmpty(standardwertValue)) {
			if(standardwertValue.toLowerCase().contains("select")) {
				standardwertValue = this.executeStandardwert(standardwertValue);
			}
		}
		return standardwertValue;
	}

	private String executeStandardwert(String standardwertQuery) {
		return jdbcOperations.getJdbcOperations().queryForObject(standardwertQuery, String.class);
	}

	private List<String> getListBoxContent(final ResultSet rs) throws SQLException {
		String listBoxContent = RowMapperUtils.getString(rs, "AU_LISTBOX_INHALT", "");
		List<String> listBoxContentList = new ArrayList<>();
		if(!StringUtils.isEmpty(listBoxContent)) {
			if(listBoxContent.toLowerCase().contains("select")) {
				listBoxContentList = this.executeListBoxQuery(listBoxContent);
			} else {
				listBoxContentList = Arrays.asList(listBoxContent.split(","));
			}
		}
		return listBoxContentList;
	}
	
	private List<String> executeListBoxQuery(String listBoxContentQuery) {
		List<String> resultList = new ArrayList<>();
		// fetch rows from the database
		resultList = jdbcOperations.query(listBoxContentQuery, (rs, rowNum) -> {
			return rs.getString(1);
		});
		return resultList;
	}

	private Long mapParameterId(final ResultSet rs, final int rowNum) throws SQLException {
		return RowMapperUtils.getLong(rs, "AU_PID", -1L);
	}
	
	private Map<String, Object> buildUpsertMap(Parameter parameter) {
		Map<String, Object> paramMap = new HashMap<>();
		paramMap.put("pid", parameter.getParameterId());
		paramMap.put("parameterName", parameter.getParameterName());
		paramMap.put("type", parameter.getType());
		paramMap.put("parameterLabel", parameter.getParameterLabel());
		paramMap.put("erklaerung", parameter.getErklaerung());
		paramMap.put("standardwert", parameter.getStandardwert());
		paramMap.put("listboxInhalt", parameter.getListboxInhalt());
		paramMap.put("regexMaske", parameter.getRegexMaske());
		paramMap.put("isPflichtfeld", parameter.isPflichtfeld());
		paramMap.put("fehlerText", parameter.getFehlertext());
		return paramMap;
	}


}
