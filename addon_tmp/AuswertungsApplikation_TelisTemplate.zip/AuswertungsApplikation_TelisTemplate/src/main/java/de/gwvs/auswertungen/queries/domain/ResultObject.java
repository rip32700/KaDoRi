package de.gwvs.auswertungen.queries.domain;

/**
 * object to represent the result of a query 
 * and to display it in the view
 * @author prieger
 * @version 1.0
 */
public class ResultObject {

	private Long queryId;
	private String columns;
	private String rows;
	
	/**
	 * returns the query ID
	 * @return
	 */
	public Long getQueryId() {
		return queryId;
	}
	
	/**
	 * sets the query ID
	 * @param queryId
	 */
	public void setQueryId(final Long queryId) {
		this.queryId = queryId;
	}
	
	/**
	 * returns all column names as a string value
	 * @return
	 */
	public String getColumns() {
		return columns;
	}
	
	/**
	 * sets column names with a string value
	 * @param columns
	 */
	public void setColumns(final String columns) {
		this.columns = columns;
	}
	
	/**
	 * returns all rows as a string value
	 * @return
	 */
	public String getRows() {
		return rows;
	}
	
	/**
	 * sets rows with a string value
	 * @param rows
	 */
	public void setRows(final String rows) {
		this.rows = rows;
	}
	
	/**
	 * prints object
	 */
	@Override
	public String toString() {
		return "ResultObject [awid=" + queryId + ", columns=" + columns + ", rows=" + rows + "]";
	}
	
}
