package de.gwvs.auswertungen.queries.exceptions;

public class DuplicateIdException extends RuntimeException {
	
	private static final long serialVersionUID = 4843986202366170857L;
	
	public DuplicateIdException(final String message) {
		super(message);
	}
}
