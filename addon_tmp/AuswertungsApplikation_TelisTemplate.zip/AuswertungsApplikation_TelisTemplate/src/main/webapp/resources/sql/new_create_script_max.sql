/* Formatted on 22.12.2015 09:29:32 (QP5 v5.277) */

drop table au_gruppenrechte;
drop table au_rechte;
drop table au_instanzen;
drop table au_favoriten;
drop table au_auswertungsparameter;
drop table au_parameter;
drop table au_auswertungen;
DROP SEQUENCE au_fav_seq;
DROP SEQUENCE au_instanzen_seq;
commit;


CREATE TABLE t20.au_auswertungen
(
  au_aid NUMBER, 
  au_art VARCHAR2(40), 
  au_vertriebskz VARCHAR2(8), 
  au_bereich VARCHAR2(50), 
  au_datum DATE,
  au_titel VARCHAR2(100), 
  au_beschreibung VARCHAR2(3000), 
  au_sql CLOB,
  au_gueltig_bis DATE,
  PRIMARY KEY (au_aid)
);
CREATE OR REPLACE PUBLIC SYNONYM au_auswertungen FOR t20.au_auswertungen;
GRANT SELECT ON t20.au_auswertungen TO gdv;
GRANT SELECT ON t20.au_auswertungen TO rl_bipro;
GRANT SELECT ON t20.au_auswertungen TO rl_lesen;
GRANT DELETE, INSERT, SELECT, UPDATE ON t20.au_auswertungen TO rl_schreiben;
GRANT SELECT ON t20.au_auswertungen TO tester;

INSERT INTO au_auswertungen
VALUES (1, 'Atomare Liste', 'TELIS', 'Mandanten', SYSDATE, 'Testauswertung', 'Eine Auswertung zum testen', 'SELECT * FROM Antraege WHERE AN_VERTRIEBSKZ = :vertriebskz and rownum < 20', NULL);
INSERT INTO au_auswertungen
VALUES (2, 'Atomare Liste', 'TELIS', 'Mandanten', SYSDATE, 'Testauswertung Nummer 2', 'Eine Auswertung zum testen', (select aw_sql from ausw_auswertungen where aw_awid = 7), NULL);
INSERT INTO au_auswertungen
VALUES (3, 'Atomare Liste', 'TELIS', 'Mandanten', SYSDATE, 'Testauswertung Nummer 3', 'Eine Auswertung zum testen', 'SELECT * FROM Antraege WHERE AN_VERTRIEBSKZ = :vertriebskz and rownum < 20', NULL);
INSERT INTO au_auswertungen
VALUES (4, 'Atomare Liste', 'TELIS', 'Mandanten', SYSDATE, 'Testauswertung Nummer 4', 'Eine Auswertung zum testen', (select aw_sql from ausw_auswertungen where aw_awid = 7), NULL);
INSERT INTO au_auswertungen
VALUES (5, 'Test', 'Test', 'Test', SYSDATE+1, 'TestTest', 'Eine Auswertung zum testen', 'select * from au_auswertungen where au_art = :art and au_bereich = :bereich and rownum < 20', NULL);




CREATE TABLE t20.au_rechte(au_rid NUMBER, au_beschreibung VARCHAR2(150), au_aid NUMBER, au_deaktiviert VARCHAR2(1), primary key(au_rid), CONSTRAINT aid_aid foreign key(au_aid) references au_auswertungen(au_aid));
CREATE OR REPLACE PUBLIC SYNONYM au_rechte for t20.au_rechte;
GRANT SELECT ON t20.au_rechte TO gdv;
GRANT SELECT ON t20.au_rechte TO rl_bipro;
GRANT SELECT ON t20.au_rechte TO rl_lesen;
GRANT SELECT, INSERT, UPDATE ON t20.au_rechte TO rl_schreiben;
GRANT SELECT ON t20.au_rechte TO tester;

INSERT INTO au_rechte VALUES(1, 'Testrecht', 1, 'N');
INSERT INTO au_rechte VALUES(2, 'Testrecht', 1, 'N');
INSERT INTO au_rechte VALUES(3, 'Testrecht', 1, 'N');
INSERT INTO au_rechte VALUES(4, 'Testrecht', 1, 'N');
INSERT INTO au_rechte VALUES(5, 'Testrecht', 1, 'N');




CREATE TABLE t20.au_gruppenrechte(au_gruppenrecht NUMBER, au_recht NUMBER, primary key(au_gruppenrecht, au_recht), CONSTRAINT gruppenrecht_rid foreign key(au_gruppenrecht) referencing au_rechte(au_rid), CONSTRAINT recht_rid foreign key(au_recht) referencing au_rechte(au_rid));
CREATE OR REPLACE PUBLIC SYNONYM au_gruppenrecht for t20.au_gruppenrecht;
GRANT SELECT ON t20.au_gruppenrechte TO gdv;
GRANT SELECT ON t20.au_gruppenrechte TO rl_bipro;
GRANT SELECT ON t20.au_gruppenrechte TO rl_lesen;
GRANT SELECT, INSERT, UPDATE ON t20.au_gruppenrechte TO rl_schreiben;
GRANT SELECT ON t20.au_gruppenrechte TO tester;

INSERT INTO au_gruppenrechte VALUES(1, 1);
INSERT INTO au_gruppenrechte VALUES(1, 2);
INSERT INTO au_gruppenrechte VALUES(1, 3);
INSERT INTO au_gruppenrechte VALUES(1, 4);
INSERT INTO au_gruppenrechte VALUES(1, 5);




CREATE TABLE t20.au_favoriten
(
	au_fid NUMBER,
	au_aid NUMBER, 
	au_user VARCHAR2(8),
	PRIMARY KEY(au_fid),
	CONSTRAINT fav_aid_ausw_aid FOREIGN KEY(au_aid) REFERENCES AU_AUSWERTUNGEN(AU_AID),
	CONSTRAINT fav_user_benutzer_user FOREIGN KEY(au_user) REFERENCES BENUTZER(BE_USER)
);
CREATE SEQUENCE au_fav_seq
 START WITH     1
 INCREMENT BY   1;
CREATE OR REPLACE PUBLIC SYNONYM au_favoriten FOR t20.au_favoriten;
GRANT SELECT ON t20.au_favoriten TO gdv;
GRANT SELECT ON t20.au_favoriten TO rl_bipro;
GRANT SELECT ON t20.au_favoriten TO rl_lesen;
GRANT DELETE, INSERT, SELECT, UPDATE ON t20.au_favoriten TO rl_schreiben;
GRANT SELECT ON t20.au_favoriten TO tester;

INSERT INTO au_favoriten
VALUES (au_fav_seq.NEXTVAL, 1, 'MLINDE');
INSERT INTO au_favoriten
VALUES (au_fav_seq.NEXTVAL, 1, 'PRIEGER');




CREATE TABLE t20.au_instanzen(au_iid NUMBER, au_aid NUMBER, au_datum DATE, au_user VARCHAR2(8), au_pfad VARCHAR2(1000),
                              au_dauer NUMBER, CONSTRAINT inst_aid_ausw_aid foreign key(au_aid) references au_auswertungen(au_aid));
ALTER TABLE t20.au_instanzen ADD (
  CONSTRAINT au_instanzen_pk
  PRIMARY KEY
  (au_iid)
  ENABLE VALIDATE);
CREATE OR REPLACE PUBLIC SYNONYM au_instanzen FOR t20.au_instanzen;
GRANT SELECT ON t20.au_instanzen TO gdv;
GRANT SELECT ON t20.au_instanzen TO rl_bipro;
GRANT SELECT ON t20.au_instanzen TO rl_lesen;
GRANT DELETE, INSERT, SELECT, UPDATE ON t20.au_instanzen TO rl_schreiben;
GRANT SELECT ON t20.au_instanzen TO tester;

CREATE SEQUENCE au_instanzen_seq
 START WITH     1
 INCREMENT BY   1;
INSERT INTO au_instanzen
VALUES (au_instanzen_seq.NEXTVAL, 1, SYSDATE, 'TEST', '--', -1);




CREATE TABLE t20.au_parameter(au_pid NUMBER,
                              au_parametername VARCHAR2(100),
                              au_typ VARCHAR2(20),
                              au_parameterlabel VARCHAR2(60),
                              au_erklaerung VARCHAR2(50),
                              au_standardwert VARCHAR2(100),
                              au_listbox_inhalt VARCHAR(1000),
                              au_maske_regex VARCHAR2(20),
                              au_pflichtfeld VARCHAR2(1),
                              au_fehlertext VARCHAR2(100));
ALTER TABLE t20.au_parameter ADD (
  CONSTRAINT au_parameter_pk
  PRIMARY KEY
  (au_pid)
  ENABLE VALIDATE);
CREATE OR REPLACE PUBLIC SYNONYM au_parameter FOR t20.au_parameter;
GRANT SELECT ON t20.au_parameter TO gdv;
GRANT SELECT ON t20.au_parameter TO rl_bipro;
GRANT SELECT ON t20.au_parameter TO rl_lesen;
GRANT DELETE, INSERT, SELECT, UPDATE ON t20.au_parameter TO rl_schreiben;
GRANT SELECT ON t20.au_parameter TO tester;

INSERT INTO au_parameter
VALUES (1, 'vertriebskz', 'Werteliste', 'VertriebsKZ', 'Vertriebskürzel', 'T', 'SELECT vt_vertriebskz, vt_vertriebsbez FROM vertriebe', '[a-zA-Z]', 'J', 'Vertriebskürzel eingeben!');
INSERT INTO au_parameter
VALUES (2, 'art', 'Text', 'Auswertungs-Art', 'Auswertungs-Art', 'Sonstiges', NULL, NULL, 'N', 'Ungültiger Text!');
INSERT INTO au_parameter
VALUES (3, 'bereich', 'Text', 'Auswertungs-Bereich', 'Auswertungs-Bereich', 'Sonstiges', NULL, NULL, 'N', 'Ungültiger Text!');




CREATE TABLE t20.au_auswertungsparameter(au_aid NUMBER, au_pid NUMBER, primary key(au_aid, au_pid), CONSTRAINT auspar_aid_ausw_aid foreign key(au_aid) references au_auswertungen(au_aid), CONSTRAINT auspar_pid_par_pid foreign key(au_pid) references au_parameter(au_pid));
CREATE OR REPLACE PUBLIC SYNONYM au_auswertungsparameter FOR t20.au_auswertungsparameter;
GRANT SELECT ON t20.au_auswertungsparameter TO gdv;
GRANT SELECT ON t20.au_auswertungsparameter TO rl_bipro;
GRANT SELECT ON t20.au_auswertungsparameter TO rl_lesen;
GRANT DELETE, INSERT, SELECT, UPDATE ON t20.au_auswertungsparameter TO rl_schreiben;
GRANT SELECT ON t20.au_auswertungsparameter TO tester;

INSERT INTO au_auswertungsparameter
VALUES (1, 1);




/*-- todo: add new recht into menurecht to reference to from query table
INSERT INTO menuerechte (mr_rechtenr, mr_rechtebez, mr_maskenname, mr_artkz, mr_deaktiviert, mr_tos)
VALUES (8888, 'Test Query Recht', 'EXL_Query_Recht', 'R', 'N', 'EXL_QUERY');
INSERT INTO menuerechte (mr_rechtenr, mr_rechtebez, mr_maskenname, mr_artkz, mr_deaktiviert, mr_tos)
VALUES (8889, 'Test Query Recht 2', 'EXL_Query_Recht2', 'R', 'N', 'EXL_QUERY2');
INSERT INTO menuerechte (mr_rechtenr, mr_rechtebez, mr_maskenname, mr_artkz, mr_deaktiviert, mr_tos)
VALUES (8890, 'Test Query Recht 3', 'EXL_Query_Recht2', 'R', 'N', 'EXL_QUERY3');

-- assign 8888 and 8889 to prieger
REM INSERTING into BENUTZERRECHTE
Insert into BENUTZERRECHTE (BR_USER,BR_RECHTENR,BR_INSERT,BR_UPDATE,BR_DELETE,BR_EXECUTE,BR_ZUSATZ,BR_ABLAUF,BR_AUFTRAGS_USER) values ('PRIEGER',8888,'J','J','J','J','J',null,'AAPPEL');
REM INSERTING into BENUTZERRECHTE_CACHE
Insert into BENUTZERRECHTE_CACHE (BC_USER,BC_RECHTENR,BC_INSERT,BC_UPDATE,BC_DELETE,BC_DIRTY,BC_DATUM,BC_EXECUTE,BC_ZUSATZ) values ('PRIEGER',8888,'J','J','J',null,to_timestamp('28.04.16','DD.MM.RR HH24:MI:SSXFF'),'J','J');

REM INSERTING into BENUTZERRECHTE
Insert into BENUTZERRECHTE (BR_USER,BR_RECHTENR,BR_INSERT,BR_UPDATE,BR_DELETE,BR_EXECUTE,BR_ZUSATZ,BR_ABLAUF,BR_AUFTRAGS_USER) values ('PRIEGER',8889,'J','J','J','J','J',null,'AAPPEL');
REM INSERTING into BENUTZERRECHTE_CACHE
Insert into BENUTZERRECHTE_CACHE (BC_USER,BC_RECHTENR,BC_INSERT,BC_UPDATE,BC_DELETE,BC_DIRTY,BC_DATUM,BC_EXECUTE,BC_ZUSATZ) values ('PRIEGER',8889,'J','J','J',null,to_timestamp('28.04.16','DD.MM.RR HH24:MI:SSXFF'),'J','J');
*/

COMMIT;